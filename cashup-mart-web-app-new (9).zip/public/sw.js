/**
 * CashUp Express service worker.
 * - App shell cached on install (works offline from the first completed load).
 * - Navigations: network-first, cache fallback (so pages open instantly offline).
 * - Catalog JSON: stale-while-revalidate (instant open + background refresh).
 * - Images & map tiles: cache-first with a size cap (offline product photos).
 * - Everything else: cache-first with background update.
 */
const VERSION = "cashup-express-v15-inlined-category-art";
const SHELL = `${VERSION}-shell`;
const IMAGES = `${VERSION}-images`;
const TILES = `${VERSION}-tiles`;
const DATA = `${VERSION}-data`;

const PRECACHE = [
  "/",
  "/categories",
  "/cart",
  "/orders",
  "/search",
  "/account",
  "/favorites",
  "/offers",
  "/help",
  "/about",
  "/terms",
  "/privacy",
  "/location",
  "/checkout",
  "/contact",
  "/icons.svg",
  "/manifest.webmanifest",
  "/cashup-logo.png",
  "/favicon.ico",
  "/images/placeholder.svg",
  "/images/banners/fresh-deals.jpg",
  "/images/banners/free-delivery.jpg",
  "/images/banners/weekly-essentials.jpg",
  "/images/banners/household.jpg",
  "/images/cats/fruits-vegetables.webp",
  "/images/cats/dairy-eggs.webp",
  "/images/cats/meat-frozen.webp",
  "/images/cats/staples.webp",
  "/images/cats/beverages.webp",
  "/images/cats/snacks.webp",
  "/images/cats/bakery.webp",
  "/images/cats/household.webp",
  "/images/cats/personal-care.webp",
  "/images/cats/baby.webp",
  "/images/cats/pet.webp",
  "/images/cats/stationery.webp",
];

const IMAGE_CACHE_LIMIT = 260;
const TILE_CACHE_LIMIT = 220;

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(SHELL)
      .then((cache) => Promise.allSettled(PRECACHE.map((u) => cache.add(u))))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

async function trim(cacheName, limit) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  if (keys.length <= limit) return;
  for (const key of keys.slice(0, keys.length - limit)) await cache.delete(key);
}

async function cacheFirst(request, cacheName, limit) {
  const cache = await caches.open(cacheName);
  const hit = await cache.match(request, { ignoreVary: true });
  if (hit) return hit;
  try {
    const res = await fetch(request);
    if (res && (res.ok || res.type === "opaque")) {
      cache.put(request, res.clone());
      if (limit) void trim(cacheName, limit);
    }
    return res;
  } catch {
    const fallback = await cache.match(request, { ignoreVary: true });
    return fallback || new Response("", { status: 504, statusText: "Offline" });
  }
}

async function staleWhileRevalidate(request, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request, { ignoreVary: true });
  const network = fetch(request)
    .then((res) => {
      if (res && res.ok) cache.put(request, res.clone());
      return res;
    })
    .catch(() => cached);
  return cached || network;
}

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);

  // Cross-origin map tiles and ImgLink CDN product photos are cache-first so
  // the live map/catalog photos remain available after the customer goes offline.
  if (url.hostname.endsWith("tile.openstreetmap.org")) {
    event.respondWith(cacheFirst(request, TILES, TILE_CACHE_LIMIT));
    return;
  }

  if (url.hostname === "imglink.cc" && url.pathname.startsWith("/cdn/")) {
    event.respondWith(cacheFirst(request, IMAGES, IMAGE_CACHE_LIMIT));
    return;
  }

  if (url.origin !== self.location.origin) return;

  // Navigations: try network, fall back to cache, then to the app shell.
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request)
        .then((res) => {
          const copy = res.clone();
          caches.open(SHELL).then((c) => c.put(request, copy));
          return res;
        })
        .catch(async () => {
          const cache = await caches.open(SHELL);
          return (await cache.match(request)) || (await cache.match("/")) || Response.error();
        }),
    );
    return;
  }

  if (url.pathname.startsWith("/api/catalog")) {
    event.respondWith(staleWhileRevalidate(request, DATA));
    return;
  }

  if (url.pathname.startsWith("/api/")) return; // never cache live order/OTP calls

  if (url.pathname.startsWith("/images/") || /\.(png|jpe?g|webp|avif|svg|ico)$/i.test(url.pathname)) {
    event.respondWith(cacheFirst(request, IMAGES, IMAGE_CACHE_LIMIT));
    return;
  }

  event.respondWith(staleWhileRevalidate(request, SHELL));
});

self.addEventListener("message", (event) => {
  if (event.data === "skipWaiting") self.skipWaiting();
});
