# Deploying CashUp Express to Edgio Pages

The customer app is **offline-first and fully static-capable**, so it can be dropped on
Edgio Pages without a Node server or a database.

## 1. Static drop (recommended)

```bash
node scripts/edgio-static-build.mjs      # writes ./out
```

Then drag & drop the `out/` folder into Edgio Pages (or `edgio deploy --token=$EDGIO_TOKEN`).

What the static build contains:

- Every screen (home, categories, product, search, cart, checkout, orders, account, offers, help).
- The full catalog (12 categories, 112 products) bundled as JSON, so the app renders with **no API**.
- The service worker (`/sw.js`) that caches the app shell, catalog and product images for offline use.
- The branded offline Karachi pin-drop map (no tile server needed).

Optional: point the static build at a hosted API (your own Node/Postgres service, Supabase, etc.):

```bash
NEXT_PUBLIC_API_BASE=https://api.your-domain.com node scripts/edgio-static-build.mjs
```

If `NEXT_PUBLIC_API_BASE` is unset or unreachable, every call falls back to the local adapter
(`src/lib/api.ts`): OTP uses the demo code, orders are queued in IndexedDB and re-sent when the
network returns.

## 2. Local fullstack (what this repo runs by default)

```bash
npx drizzle-kit push   # create tables
npm run build && npm start
```

PostgreSQL holds the catalog, customers, addresses, OTP codes and orders. Orders are printed to the
server log with a private `/ops/<token>` status link.

## Notes

- `@edgio/next` supports Next.js ≤ 14. This project uses Next 16, so use the static drop path.
- Catalog edits: `src/data/catalog.ts` (+ `src/data/CATALOG.md` for the field format), then rebuild.
