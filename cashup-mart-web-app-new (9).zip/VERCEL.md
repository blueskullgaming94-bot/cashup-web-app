# Vercel setup: OTP does not require PostgreSQL

The OTP send/verify endpoints are intentionally **database-independent**. They
use a five-minute signed challenge in an `HttpOnly`, `SameSite=Lax` cookie, so a
Vercel deployment without `DATABASE_URL` no longer fails with “Store database
unavailable” when a customer requests or verifies a code. Saving the optional
customer row to PostgreSQL is best-effort only.

## Send code by SMS

In Vercel → Project → Settings → Environment Variables, add:

- `OTP_KEY` — Branded SMS Pakistan API key (server-only; do not prefix with `NEXT_PUBLIC_`).
- `OTP_EMAIL` — email registered with the SMS provider.
- `OTP_MASK` — approved sender/masking name.
- `SESSION_SECRET` — a long random secret used to sign OTP challenge and login session cookies.

Then redeploy. Without SMS gateway variables, the endpoint issues the code through
the in-app top notification. To require SMS-only delivery (and hide the code from
the browser), set `OTP_REVEAL_CODE=false`; when the gateway is unavailable the
endpoint responds with a real error instead of issuing a challenge.

The code expires after five minutes; a new request is rate-limited, and each
challenge permits at most five verification attempts. The browser must accept
same-site cookies for verification.

## Database remains optional for OTP, not for order storage

Set `DATABASE_URL` when you want Vercel to persist the catalog, customers and
orders to PostgreSQL. OTP itself continues to work when it is absent. The
bundled catalog remains available without the database. Configure `SESSION_SECRET`
for production rather than relying on the development fallback.
