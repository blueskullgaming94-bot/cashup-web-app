import "dotenv/config";
import assert from "node:assert/strict";
import test from "node:test";
import { randomUUID } from "node:crypto";
import { and, eq } from "drizzle-orm";
import { db, pool } from "../src/db";
import { addresses, customers, orders } from "../src/db/schema";

/** Run against the local managed preview after drizzle-kit push. No SMS is sent. */
test("a valid order persists House Number, Block/Sector and Area in Postgres", async () => {
  const base = process.env.TEST_BASE_URL || "http://127.0.0.1:3000";
  const phone = "923009990001";
  const marker = `address-test-${randomUUID()}`;
  let orderId: string | null = null;
  let existed = true;
  try {
    const existing = await db.select().from(customers).where(eq(customers.phone, phone)).limit(1);
    existed = Boolean(existing[0]);
    const address = {
      label: marker, houseNumber: "TST-42", blockSector: "Block 4", area: "Clifton",
      street: "Street 12", details: "Do not trust this client summary", note: marker,
      lat: 24.8138, lng: 67.0329,
    };
    const res = await fetch(`${base}/api/orders`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: "Automated Address Test", phone, address, items: [{ productId: "p001", qty: 2 }], deliverySlot: "asap", note: marker }),
    });
    const payload = await res.json();
    assert.equal(res.status, 200, JSON.stringify(payload));
    orderId = payload.order.id;
    const [row] = await db.select().from(orders).where(eq(orders.id, orderId!));
    assert.ok(row);
    const storedAddress = row.address as Record<string, string>;
    assert.equal(storedAddress.houseNumber, "TST-42");
    assert.equal(storedAddress.blockSector, "Block 4");
    assert.equal(storedAddress.area, "Clifton");
    assert.equal(storedAddress.details, "TST-42, Street 12, Block 4, Clifton");
    const [saved] = await db.select().from(addresses).where(and(eq(addresses.phone, phone), eq(addresses.label, marker)));
    assert.equal(saved.houseNumber, "TST-42");
    assert.equal(saved.blockSector, "Block 4");
    assert.equal(saved.area, "Clifton");
    assert.equal(saved.street, "Street 12");
  } finally {
    if (orderId) await db.delete(orders).where(eq(orders.id, orderId));
    await db.delete(addresses).where(and(eq(addresses.phone, phone), eq(addresses.label, marker)));
    if (!existed) await db.delete(customers).where(and(eq(customers.phone, phone), eq(customers.name, "Automated Address Test")));
    await pool.end();
  }
});
