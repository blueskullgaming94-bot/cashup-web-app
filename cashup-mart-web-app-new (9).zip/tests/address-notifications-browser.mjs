import { chromium, expect } from "@playwright/test";

const base = process.env.TEST_BASE_URL || "http://127.0.0.1:3000";
const browser = await chromium.launch({ args: ["--no-sandbox"], headless: true });
const errors = [];
const pixel = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a6XkAAAAASUVORK5CYII=", "base64");
const fixture = {
  lat: 24.98, lng: 67.03, area: "North Karachi", areaIsApproximate: false,
  houseNumber: "L933", block: "", sector: "Sector 5A1", street: "Street 7",
  components: { house_number: "L933", sector: "5A1", suburb: "North Karachi" },
  hasHouseNumber: true, hasStreet: true, outside: false,
  details: "L933, Sector 5A1, North Karachi", displayName: "L933, Sector 5A1, North Karachi", attribution: "OpenStreetMap",
};

async function newPage(mode = "complete", viewport = { width: 390, height: 844 }) {
  const context = await browser.newContext({ viewport, serviceWorkers: "block", permissions: ["geolocation", "clipboard-read", "clipboard-write"], geolocation: { latitude: 24.98, longitude: 67.03, accuracy: 8 } });
  await context.route(/https:\/\/(.*tile\.openstreetmap\.org|imglink\.cc)\/.*/, (r) => r.fulfill({ body: pixel, contentType: "image/png" }));
  await context.route("**/api/geocode?*", async (r) => {
    if (mode === "failed") return r.fulfill({ status: 503, json: { error: "Lookup unavailable" } });
    const value = structuredClone(fixture);
    if (mode === "no-house" || mode === "none") {
      value.houseNumber = ""; value.components.house_number = ""; value.hasHouseNumber = false;
    }
    if (mode === "none") {
      value.sector = ""; value.block = ""; value.area = null; value.areaIsApproximate = true;
    }
    if (mode === "slow") await new Promise((resolve) => setTimeout(resolve, 900));
    return r.fulfill({ json: value });
  });
  const page = await context.newPage();
  page.on("pageerror", (e) => errors.push(e.message));
  return { context, page };
}
const dialogFor = (page) => page.getByRole("dialog", { name: /Where should we deliver|Update Delivery Location/ });
const input = (page, name) => dialogFor(page).getByLabel(name, { exact: true });

try {
  // All fields are compulsory, with per-field errors and safe dismissal.
  const complete = await newPage();
  await complete.page.goto(base);
  let dialog = dialogFor(complete.page);
  await expect(dialog).toBeVisible();
  await dialog.getByRole("button", { name: "Save & continue" }).click();
  for (const name of ["House Number", "Block/Sector", "Area"]) {
    await expect(input(complete.page, name)).toHaveAttribute("required", "");
    await expect(input(complete.page, name)).toHaveAttribute("aria-invalid", "true");
  }
  await expect(dialog).toBeVisible();
  await dialog.getByLabel("Full name", { exact: true }).fill("Address Test");
  await dialog.getByLabel("Mobile number", { exact: true }).fill("03001234567");
  await dialog.getByRole("button", { name: "Use my current location", exact: true }).click();
  await expect(input(complete.page, "House Number")).toHaveValue("L933");
  await expect(input(complete.page, "Block/Sector")).toHaveValue("Sector 5A1");
  await expect(input(complete.page, "Area")).toHaveValue("North Karachi");
  await dialog.getByRole("button", { name: "Save & continue", exact: true }).click();
  await expect(dialog).toHaveCount(0);
  const saved = await complete.page.evaluate(() => JSON.parse(localStorage.getItem("cashup-address")));
  expect(saved.houseNumber).toBe("L933"); expect(saved.blockSector).toBe("Sector 5A1"); expect(saved.area).toBe("North Karachi");
  await complete.page.reload();
  await expect(complete.page.getByRole("button", { name: "Change delivery address" })).toBeVisible();
  await expect(dialog).toHaveCount(0);
  await complete.page.getByRole("button", { name: "Change delivery address" }).click();
  for (const [label, value] of [["House Number", "L933"], ["Block/Sector", "Sector 5A1"], ["Area", "North Karachi"]]) await expect(input(complete.page, label)).toHaveValue(value);
  await dialog.getByRole("button", { name: "Browse first", exact: true }).click();
  console.log("PASS: compulsory fields validate, auto-fill separately, persist, and reload correctly");

  for (const mode of ["no-house", "none", "failed"]) {
    const scenario = await newPage(mode);
    await scenario.page.goto(base);
    dialog = dialogFor(scenario.page);
    await expect(dialog).toBeVisible();
    await dialog.getByLabel("Full name", { exact: true }).fill("Map Test");
    await dialog.getByLabel("Mobile number", { exact: true }).fill("03001234567");
    await dialog.getByRole("button", { name: "Use my current location", exact: true }).click();
    await expect(dialog.getByTestId("houseNumber-hint")).toContainText("Please enter it manually");
    await expect(input(scenario.page, "House Number")).toHaveValue("");
    if (mode === "no-house") {
      await expect(input(scenario.page, "Block/Sector")).toHaveValue("Sector 5A1");
      await expect(dialog.getByLabel("Street / landmark (optional)")).toHaveValue("Street 7");
    } else {
      await expect(dialog.getByTestId("blockSector-hint")).toContainText("Please enter it manually");
      await expect(dialog.getByTestId("area-hint")).toContainText("Please enter it manually");
    }
    await dialog.getByRole("button", { name: "Save & continue", exact: true }).click();
    await expect(dialog).toBeVisible();
    await input(scenario.page, "House Number").fill("Manual 12");
    await input(scenario.page, "Block/Sector").fill("Sector 5A1");
    await input(scenario.page, "Area").fill("North Karachi");
    await dialog.getByRole("button", { name: "Save & continue", exact: true }).click();
    await expect(dialog).toHaveCount(0);
    await scenario.context.close();
    console.log(`PASS: ${mode} map response shows field-level failures; manual completion is required and works`);
  }

  const slow = await newPage("slow");
  await slow.page.goto(base);
  dialog = dialogFor(slow.page);
  await expect(dialog).toBeVisible();
  const requested = slow.page.waitForRequest((req) => req.url().includes("/api/geocode?"));
  await dialog.getByRole("button", { name: "Use my current location", exact: true }).click();
  await requested;
  await input(slow.page, "House Number").fill("My manual number 55");
  await input(slow.page, "Block/Sector").fill("Sector 5A2");
  await expect(dialog.getByRole("button", { name: "Use mapped fields" })).toHaveCount(0);
  await expect(input(slow.page, "House Number")).toHaveValue("My manual number 55");
  await expect(input(slow.page, "Block/Sector")).toHaveValue("Sector 5A2");
  await expect(input(slow.page, "Area")).toHaveValue("North Karachi");
  await dialog.getByRole("button", { name: "Browse first", exact: true }).click();
  await slow.context.close();
  console.log("PASS: late responses preserve manual fields while auto-filling other blank fields");

  const offline = await newPage();
  await offline.page.goto(base);
  dialog = dialogFor(offline.page);
  await expect(dialog).toBeVisible();
  await offline.context.setOffline(true);
  await dialog.getByRole("button", { name: "Use my current location", exact: true }).click();
  await expect(dialog.getByText(/You are offline. Autofill is unavailable/)).toBeVisible();
  for (const name of ["House Number", "Block/Sector", "Area"]) await expect(input(offline.page, name)).toBeEditable();
  await offline.context.close();
  console.log("PASS: offline autofill reports failure without blocking manual fields");

  // OTP notification uses the latest layout on small phones and desktops.
  const otp = await newPage();
  await otp.context.addInitScript(({ saved }) => {
    localStorage.setItem("cashup-address", JSON.stringify(saved));
    localStorage.setItem("cashup-profile", JSON.stringify({ name: "OTP Test", phone: "923001234567", verified: false }));
    localStorage.setItem("cashup-delivery-prompt-seen", "true");
    localStorage.setItem("cashup-cart", JSON.stringify([{ productId: "p001", qty: 2 }]));
  }, { saved });
  let sendMode = "failure";
  await otp.context.route("**/api/otp/send", (r) => sendMode === "failure"
    ? r.fulfill({ status: 429, json: { error: "Please wait before requesting another code." } })
    : r.fulfill({ json: { ok: true, code: "482913", gatewayStatus: "sent" } }));
  for (const width of [320, 390, 1280]) {
    await otp.page.setViewportSize({ width, height: 900 });
    await otp.page.goto(`${base}/checkout`);
    const mini = otp.page.getByRole("status", { name: "Code sent confirmation" });
    const notice = otp.page.getByRole("alert", { name: "Verification code notification" });
    if (width === 320) {
      await otp.page.getByRole("button", { name: "Send OTP", exact: true }).click();
      await expect(otp.page.getByText("Please wait before requesting another code.").first()).toBeVisible();
      await expect(mini).toHaveCount(0); await expect(notice).toHaveCount(0);
    }
    sendMode = "success";
    await otp.page.getByRole("button", { name: "Send OTP", exact: true }).click();
    if (width < 768) {
      // Phones: no centered confirmation; the code banner slides down from the top.
      await expect(mini).toHaveCount(0);
      await expect.poll(async () => Math.round((await notice.boundingBox()).y)).toBeLessThan(40);
      await expect.poll(async () => {
        const b = await notice.boundingBox();
        return Math.round(b.x + b.width / 2);
      }).toBe(Math.round(width / 2));
    } else {
      await expect(mini).toHaveText("Code Sent!");
      const middle = await mini.boundingBox();
      expect(Math.abs(middle.x + middle.width / 2 - width / 2)).toBeLessThan(2);
      expect(Math.abs(middle.y + middle.height / 2 - 450)).toBeLessThan(2);
      await expect.poll(async () => { const b = await notice.boundingBox(); return Math.round(width - b.x - b.width); }).toBe(24);
      const box = await notice.boundingBox();
      expect(box.y).toBeGreaterThan(550); expect(box.x).toBeGreaterThanOrEqual(0);
    }
    await notice.getByRole("button", { name: "Copy", exact: true }).click();
    await expect(notice.getByRole("button", { name: "Copied", exact: true })).toBeVisible();
    expect(await otp.page.evaluate(() => navigator.clipboard.readText())).toBe("482913");
    await expect(notice).toBeVisible();
    await notice.getByRole("button", { name: "Dismiss notification" }).click();
    await expect(notice).toHaveCount(0);
    console.log(`PASS: code notification placed correctly with working Copy at ${width}px`);
  }
  // Verify promo shortfall item suggestions on checkout
  const promoPage = await newPage();
  await promoPage.context.addInitScript(({ saved }) => {
    localStorage.setItem("cashup-address", JSON.stringify(saved));
    localStorage.setItem("cashup-profile", JSON.stringify({ name: "Promo Test", phone: "923001234567", verified: true }));
    localStorage.setItem("cashup-delivery-prompt-seen", "true");
    // Subtotal around Rs. 440 (2x p001 Kinnow @ 220 = 440, below 500 for CASHUP50)
    localStorage.setItem("cashup-cart", JSON.stringify([{ productId: "p001", qty: 2 }]));
  }, { saved });
  await promoPage.page.goto(`${base}/checkout`);
  await promoPage.page.getByPlaceholder("Promo code (CASHUP50)").fill("CASHUP50");
  const suggestionsBox = promoPage.page.getByTestId("promo-shortfall-suggestions");
  await expect(suggestionsBox).toBeVisible();
  await expect(suggestionsBox).toContainText("Add Rs. 60 more to use CASHUP50");
  // Click "+ Add" on the first suggested item
  const addBtn = suggestionsBox.getByRole("button", { name: /Add / }).first();
  await addBtn.click();
  // Cart subtotal updates, reaching 500+, discount applies and suggestions hide!
  await expect(promoPage.page.getByText("Rs. 50 off applied")).toBeVisible();
  await expect(suggestionsBox).toHaveCount(0);
  console.log("PASS: promo shortfall item suggestions appear on low order amount and unlock discount on Add");
  await promoPage.context.close();

  await otp.context.close();
  await complete.context.close();
  expect(errors).toEqual([]);
  console.log("Required-address, promo suggestions and code-notification browser tests passed without runtime errors.");
} finally { await browser.close(); }
