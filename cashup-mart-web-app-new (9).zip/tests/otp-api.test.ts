import assert from "node:assert/strict";
import test from "node:test";

/**
 * Vercel regression: OTP send/verify must work without DATABASE_URL and without
 * relying on cookies (which proxies, serverless instances and cross-origin
 * setups can strip). Verification travels as a signed ticket in the body.
 */

const PHONE = "03001234567";

async function loadRoutes() {
  delete process.env.DATABASE_URL;
  delete process.env.OTP_KEY;
  delete process.env.OTP_EMAIL;
  delete process.env.OTP_MASK;
  process.env.OTP_REVEAL_CODE = "true";
  process.env.OTP_CHALLENGE_SECRET = "unit-test-only-otp-secret";
  const { POST: sendOtp } = await import("../src/app/api/otp/send/route");
  const { POST: verifyOtp } = await import("../src/app/api/otp/verify/route");
  return { sendOtp, verifyOtp };
}

const post = (url: string, body: unknown, cookie = "") =>
  new Request(url, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      ...(cookie ? { cookie } : {}),
    },
    body: JSON.stringify(body),
  });

test("OTP send and verify work with DATABASE_URL absent and no cookies", async () => {
  const { sendOtp, verifyOtp } = await loadRoutes();
  const sent = await sendOtp(post("https://cashup.test/api/otp/send", { phone: PHONE }));
  assert.equal(sent.status, 200);
  const payload = (await sent.json()) as { code?: string; ticket?: string; gatewayStatus?: string };
  assert.match(payload.code ?? "", /^\d{6}$/);
  assert.ok(payload.ticket?.includes("."), "send returns a signed ticket in the body");

  // No cookie header at all: the ticket alone must verify.
  const verified = await verifyOtp(
    post("https://cashup.test/api/otp/verify", { phone: PHONE, code: payload.code, name: "Vercel Test", ticket: payload.ticket }),
  );
  assert.equal(verified.status, 200);
  assert.deepEqual(await verified.json(), { ok: true, phone: "923001234567", name: "Vercel Test" });
});

test("wrong code is rejected and the rotated ticket keeps working", async () => {
  const { sendOtp, verifyOtp } = await loadRoutes();
  const sent = await sendOtp(post("https://cashup.test/api/otp/send", { phone: "03007654321" }));
  const { code, ticket } = (await sent.json()) as { code: string; ticket: string };

  const wrong = await verifyOtp(
    post("https://cashup.test/api/otp/verify", { phone: "03007654321", code: "000000", name: "T", ticket }),
  );
  assert.equal(wrong.status, 400);
  const wrongBody = (await wrong.json()) as { error: string; ticket?: string };
  assert.match(wrongBody.error, /incorrect/i);
  assert.ok(wrongBody.ticket, "a failed attempt returns a rotated ticket");

  const right = await verifyOtp(
    post("https://cashup.test/api/otp/verify", { phone: "03007654321", code, name: "T", ticket: wrongBody.ticket }),
  );
  assert.equal(right.status, 200);
});

test("missing or tampered tickets fail closed with the expired message", async () => {
  const { verifyOtp } = await loadRoutes();
  const none = await verifyOtp(post("https://cashup.test/api/otp/verify", { phone: PHONE, code: "123456", name: "T" }));
  assert.equal(none.status, 400);
  assert.match(((await none.json()) as { error: string }).error, /expired/i);

  const { sendOtp } = await loadRoutes();
  const sent = await sendOtp(post("https://cashup.test/api/otp/send", { phone: "03001112222" }));
  const { code, ticket } = (await sent.json()) as { code: string; ticket: string };
  const tampered = ticket.slice(0, -2) + (ticket.endsWith("aa") ? "bb" : "aa");
  const bad = await verifyOtp(
    post("https://cashup.test/api/otp/verify", { phone: "03001112222", code, name: "T", ticket: tampered }),
  );
  assert.equal(bad.status, 400);
  assert.match(((await bad.json()) as { error: string }).error, /expired/i);
});

test("legacy cookie-only clients still verify (backwards compatibility)", async () => {
  const { sendOtp, verifyOtp } = await loadRoutes();
  const sent = await sendOtp(post("https://cashup.test/api/otp/send", { phone: "03003334444" }));
  const payload = (await sent.json()) as { code: string };
  const setCookie = sent.headers.get("set-cookie") ?? "";
  const challengeCookie = setCookie.split(",").map((part) => part.trim()).find((part) => part.startsWith("zx_otp="))?.split(";")[0];
  assert.ok(challengeCookie, "send still sets the HttpOnly challenge cookie");
  const verified = await verifyOtp(
    post("https://cashup.test/api/otp/verify", { phone: "03003334444", code: payload.code, name: "Legacy" }, challengeCookie),
  );
  assert.equal(verified.status, 200);
});
