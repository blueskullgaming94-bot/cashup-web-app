import assert from "node:assert/strict";
import test from "node:test";
import { fieldsFromMap, fieldsFromSavedAddress, formatAddressDetails, hasRequiredAddressFields, missingMappedFields, normalizeSavedAddress, requiredAddressErrors, validateOrderAddress } from "../src/lib/address-fields";
import { formatMapAddress } from "../src/lib/geocode";
import { deliveryDetailsComplete } from "../src/lib/delivery-state";
import { priceOrder } from "../src/lib/api";
import { products } from "../src/data/catalog";

const fields = { houseNumber: "L933", blockSector: "Sector 5A1", area: "North Karachi", street: "" };
const address = { ...fields, label: "Home", details: "L933, Sector 5A1, North Karachi", note: "", lat: 24.98, lng: 67.03 };
const profile = { name: "Test Shopper", phone: "03001234567", verified: false };

test("all three address fields are required; whitespace and invalid types are rejected", () => {
  assert.equal(hasRequiredAddressFields(fields), true);
  for (const key of ["houseNumber", "blockSector", "area"] as const) {
    for (const value of [undefined, "", "  ", null, 12, {}, []]) {
      assert.equal(hasRequiredAddressFields({ ...fields, [key]: value }), false);
      assert.ok(requiredAddressErrors({ ...fields, [key]: value })[key]);
    }
    assert.equal(deliveryDetailsComplete({ ...address, [key]: "" }, profile), false);
    assert.equal(validateOrderAddress({ ...address, [key]: "" }).ok, false);
  }
  assert.equal(deliveryDetailsComplete(address, profile), true);
});

test("complete map components fill the corresponding required fields", () => {
  const result = formatMapAddress({ address: { house_number: "L933", sector: "5A1", suburb: "North Karachi", country_code: "pk" } }, address.lat, address.lng);
  assert.deepEqual(fieldsFromMap(result), fields);
  assert.deepEqual(missingMappedFields(fieldsFromMap(result)), []);
});

test("a mapped street or building name must not replace the compulsory house number", () => {
  const result = formatMapAddress({ address: { house_name: "Test Building", road: "Street 12", suburb: "Clifton", block: "4" } }, 24.8138, 67.0329);
  const parsed = fieldsFromMap(result);
  assert.equal(parsed.houseNumber, "");
  assert.equal(parsed.street, "Street 12");
  assert.equal(parsed.blockSector, "Block 4");
  assert.deepEqual(missingMappedFields(parsed), ["houseNumber"]);
});

test("missing sector and approximate-only areas are reported as incomplete", () => {
  const result = formatMapAddress({ address: { house_number: "12" } }, address.lat, address.lng);
  const parsed = fieldsFromMap(result);
  assert.equal(parsed.houseNumber, "12");
  assert.equal(parsed.blockSector, "");
  assert.equal(parsed.area, "");
  assert.deepEqual(missingMappedFields(parsed), ["blockSector", "area"]);
  const none = fieldsFromMap(formatMapAddress({}, address.lat, address.lng));
  assert.deepEqual(missingMappedFields(none), ["houseNumber", "blockSector", "area"]);
});

test("old saved text is restored only when the components are recognizable", () => {
  const old = { label: "Home", area: "North Karachi", details: "L933, Sector 5A1, North Karachi", lat: address.lat, lng: address.lng, note: "" };
  assert.deepEqual(fieldsFromSavedAddress(old), fields);
  assert.equal(hasRequiredAddressFields(normalizeSavedAddress(old)), true);
  const streetOnly = { ...old, details: "Street 12, Sector 5A1, North Karachi" };
  assert.equal(fieldsFromSavedAddress(streetOnly).houseNumber, "");
  assert.equal(hasRequiredAddressFields(normalizeSavedAddress(streetOnly)), false);
  assert.equal(fieldsFromSavedAddress({ ...old, houseNumber: "" }).houseNumber, "");
});

test("the server derives display text from structured fields and ignores a forged summary", () => {
  const result = validateOrderAddress({ ...address, houseNumber: "  L933  ", details: "some other address" });
  assert.equal(result.ok, true);
  if (!result.ok) return;
  assert.equal(result.address.houseNumber, "L933");
  assert.equal(result.address.details, "L933, Sector 5A1, North Karachi");
  assert.equal(formatAddressDetails({ ...fields, street: "Street 12" }), "L933, Street 12, Sector 5A1, North Karachi");
});

test("offline checkout pricing also blocks any incomplete address", () => {
  const input = { name: profile.name, phone: profile.phone, address, items: [{ productId: "p001", qty: 2 }], deliverySlot: "asap", note: "" };
  assert.equal(priceOrder(products, input).error, null);
  assert.match(priceOrder(products, { ...input, address: { ...address, blockSector: "" } }).error || "", /all required/);
});

test("orders API rejects each missing required component before touching a database", async () => {
  const { POST } = await import("../src/app/api/orders/route");
  for (const key of ["houseNumber", "blockSector", "area"] as const) {
    const res = await POST(new Request("https://shop.example/api/orders", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: profile.name, phone: profile.phone, address: { ...address, [key]: " " }, items: [{ productId: "p001", qty: 2 }] }),
    }));
    assert.equal(res.status, 400);
    const data = await res.json();
    assert.ok(data.fieldErrors[key]);
    assert.match(data.error, /all required/);
  }
});
