import assert from "node:assert/strict";
import test from "node:test";
import { deliveryDetailsComplete, readDeviceValue, shouldPromptForDelivery, writeDeviceValue } from "../src/lib/delivery-state";
import { compactPreviouslyMappedAddress, formatMapAddress, reverseLookupUrl } from "../src/lib/geocode";
import { detectCurrentLocation } from "../src/lib/geolocation";

const address = { label: "Home", houseNumber: "Flat 4B", blockSector: "Block 4", area: "Clifton", details: "Flat 4B, Block 4, Clifton", note: "", lat: 24.8138, lng: 67.0329 };
const profile = { name: "Test shopper", phone: "03001234567", verified: false };

test("intro is once only, cart and checkout ask only for missing details", () => {
  assert.equal(shouldPromptForDelivery("first-visit", false, false), true);
  assert.equal(shouldPromptForDelivery("first-visit", false, true), false);
  for (const reason of ["first-visit", "cart", "checkout"] as const) {
    assert.equal(shouldPromptForDelivery(reason, true, true), false);
  }
  assert.equal(shouldPromptForDelivery("cart", false, true), true);
  assert.equal(shouldPromptForDelivery("checkout", false, true), true);
  assert.equal(shouldPromptForDelivery("edit", true, true), true);
});

test("complete delivery details are validated independently of checkout OTP", () => {
  assert.equal(deliveryDetailsComplete(address, profile), true);
  assert.equal(deliveryDetailsComplete(null, profile), false);
  assert.equal(deliveryDetailsComplete(address, null), false);
  assert.equal(deliveryDetailsComplete({ ...address, details: " " }, profile), false);
  assert.equal(deliveryDetailsComplete({ ...address, lat: 31.52, lng: 74.35 }, profile), false);
  assert.equal(deliveryDetailsComplete(address, { ...profile, phone: "bad" }), false);
});

test("corrupt or blocked storage cannot discard unrelated saved details", () => {
  const values = new Map<string, string>();
  const session = new Map<string, string>();
  Object.defineProperty(globalThis, "window", {
    configurable: true,
    value: {
      localStorage: { getItem: (key: string) => key === "corrupt" ? "{" : values.get(key) ?? null, setItem: (key: string, value: string) => values.set(key, value) },
      sessionStorage: { getItem: (key: string) => session.get(key) ?? null, setItem: (key: string, value: string) => session.set(key, value) },
    },
  });
  try {
    writeDeviceValue("test.address", address);
    writeDeviceValue("test.profile", profile);
    assert.equal(readDeviceValue("corrupt", null), null);
    assert.deepEqual(readDeviceValue("test.address", null), address);
    Object.defineProperty(window, "localStorage", { get() { throw new Error("Blocked"); } });
    assert.deepEqual(readDeviceValue("test.profile", null), profile);
    writeDeviceValue("test.seen", true);
    assert.equal(readDeviceValue("test.seen", false), true);
  } finally { Reflect.deleteProperty(globalThis, "window"); }
});

test("formatter keeps delivery details concise and ignores misleading road/district matches", () => {
  const result = formatMapAddress({
    display_name: "L933, Shahrah-e-Usman, North Karachi Sector 5, Nazimabad District, Karachi Division, Karachi, Pakistan",
    address: {
      house_number: "L933",
      road: "Shahrah-e-Usman",
      suburb: "North Karachi Sector 5",
      city_district: "Nazimabad District",
      city: "Karachi",
      country: "Pakistan",
      country_code: "pk",
    },
  }, 24.981234, 67.031234);
  assert.equal(result.area, "North Karachi");
  assert.equal(result.details, "L933, Sector 5, North Karachi");
  assert.doesNotMatch(result.details, /Shahrah|Nazimabad District|Karachi Division|Pakistan/i);
  assert.equal(result.lat, 24.981234);
  assert.equal(result.lng, 67.031234);
  assert.equal(result.hasHouseNumber, true);
  assert.equal(result.hasStreet, true);
  assert.equal(result.outside, false);
});

test("a deliberate shopper-selected Karachi area takes priority over noisy OSM district text", () => {
  const result = formatMapAddress({
    display_name: "L933, Shahrah-e-Usman, North Karachi Sector 5, Nazimabad District, Karachi, Pakistan",
    address: { house_number: "L933", road: "Shahrah-e-Usman", suburb: "North Karachi Sector 5", city_district: "Nazimabad District", country_code: "pk" },
  }, 24.981234, 67.031234, "North Karachi");
  assert.equal(result.area, "North Karachi");
  assert.equal(result.details, "L933, Sector 5, North Karachi");
});

test("no house number at the pin: street name/number is filled instead, never a fake house", () => {
  const result = formatMapAddress({ address: { road: "Street 12", suburb: "Clifton", city: "Karachi", country: "Pakistan" } }, 24.8138, 67.0329);
  assert.equal(result.details, "Street 12, Clifton");
  assert.equal(result.hasHouseNumber, false);
  assert.equal(result.street, "Street 12");
  const viaTag = formatMapAddress({ address: { suburb: "Clifton" }, extratags: { "addr:street": "Khayaban-e-Seher" } }, 24.8138, 67.0329);
  assert.equal(viaTag.details, "Khayaban-e-Seher, Clifton");
  assert.equal(formatMapAddress({}, 31.52, 74.35).outside, true);
});

test("house number present: street is omitted to keep the address short", () => {
  const result = formatMapAddress({ address: { house_number: "B-14", road: "Street 12", suburb: "Clifton" } }, 24.8138, 67.0329);
  assert.equal(result.details, "B-14, Clifton");
});

test("map locality is used as the area so a sector is never paired with the wrong neighbourhood", () => {
  const raw = { address: { neighbourhood: "Sector 1", suburb: "Sultanabad", town: "Manghopir Town", city_district: "Orangi District", city: "Karachi Division", country_code: "pk" } };
  assert.equal(formatMapAddress(raw, 24.981234, 67.031234).details, "Sector 1, Sultanabad");
  const withStreet = formatMapAddress({ address: { ...raw.address, road: "Street 4" } }, 24.981234, 67.031234);
  assert.equal(withStreet.details, "Street 4, Sector 1, Sultanabad");
  assert.doesNotMatch(withStreet.details, /Manghopir|Orangi|Division/);
  // A shopper-chosen area that doesn't match the mapped locality drops the foreign sector.
  assert.equal(formatMapAddress(raw, 24.981234, 67.031234, "North Karachi").details, "North Karachi");
});

test("legacy verbose reverse-geocode text is compacted to delivery fields", () => {
  assert.equal(
    compactPreviouslyMappedAddress("L933, Shahrah-e-Usman, North Karachi Sector 5, Nazimabad District, Karachi Division, Sindh, Pakistan", "North Karachi"),
    "L933, Sector 5, North Karachi",
  );
});

test("reverse lookup requests full building-level address details", () => {
  const url = reverseLookupUrl("https://example.test/reverse", 24.981234, 67.031234);
  assert.equal(url.searchParams.get("addressdetails"), "1");
  assert.equal(url.searchParams.get("zoom"), "18");
  assert.equal(url.searchParams.get("layer"), "address");
  assert.equal(url.searchParams.get("lon"), "67.031234");
});

function fakeGeo(fixes: Array<{ after: number; accuracy: number }>) {
  const timers: ReturnType<typeof setTimeout>[] = [];
  let cleared = 0;
  const api = {
    watchPosition(success: PositionCallback, _error: PositionErrorCallback, options: PositionOptions) {
      assert.equal(options.enableHighAccuracy, true);
      assert.equal(options.maximumAge, 0);
      for (const fix of fixes) timers.push(setTimeout(() => success({
        coords: { latitude: 24.981234, longitude: 67.031234, accuracy: fix.accuracy }, timestamp: Date.now(),
      } as GeolocationPosition), fix.after));
      return 7;
    },
    clearWatch(id: number) { assert.equal(id, 7); cleared++; timers.forEach(clearTimeout); },
  } as unknown as Geolocation;
  return { api, cleared: () => cleared };
}

test("high accuracy watch chooses the improved GPS fix and stops tracking", async () => {
  const fake = fakeGeo([{ after: 1, accuracy: 240 }, { after: 6, accuracy: 9 }]);
  const result = await detectCurrentLocation({ signal: new AbortController().signal, geolocation: fake.api, maxWait: 100 });
  assert.equal(result.accuracy, 9);
  assert.equal(fake.cleared(), 1);
});

test("a timeout with a usable fix returns honest approximate accuracy", async () => {
  const fake = fakeGeo([{ after: 1, accuracy: 220 }]);
  const result = await detectCurrentLocation({ signal: new AbortController().signal, geolocation: fake.api, maxWait: 20 });
  assert.equal(result.accuracy, 220);
  assert.equal(fake.cleared(), 1);
});

test("closing the modal cancels the GPS watch", async () => {
  const fake = fakeGeo([]);
  const controller = new AbortController();
  const lookup = detectCurrentLocation({ signal: controller.signal, geolocation: fake.api, maxWait: 100 });
  controller.abort();
  await assert.rejects(lookup, { name: "AbortError" });
  assert.equal(fake.cleared(), 1);
});

test("order page shows an arrival estimate instead of a tracking timeline", async () => {
  const { orderEtaText } = await import("../src/lib/eta");
  const base = { status: "placed", deliverySlot: "asap", createdAt: "2026-10-10T10:00:00.000Z", updatedAt: "2026-10-10T10:00:00.000Z" };
  assert.match(orderEtaText(base), /Arriving by about/);
  assert.match(orderEtaText({ ...base, pendingSync: true }), /once the order reaches the store/);
  assert.match(orderEtaText({ ...base, deliverySlot: "today-eve" }), /Scheduled · Today, 6:00–8:00 pm/);
  assert.match(orderEtaText({ ...base, status: "delivered" }), /^Delivered ·/);
  assert.match(orderEtaText({ ...base, status: "cancelled" }), /cancelled/);
});
