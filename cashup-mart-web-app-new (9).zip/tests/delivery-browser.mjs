import { chromium, expect } from "@playwright/test";

const base = process.env.TEST_BASE_URL || "http://127.0.0.1:3000";
const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
const pixel = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a6XkAAAAASUVORK5CYII=", "base64");
const errors = [];
let geocodeDelay = 40;
const lookups = [];

async function setup(context) {
  await context.route(/https:\/\/(.*tile\.openstreetmap\.org|imglink\.cc)\/.*/, (route) => route.fulfill({ contentType: "image/png", body: pixel }));
  await context.route("**/api/geocode?*", async (route) => {
    const url = new URL(route.request().url());
    lookups.push(url);
    const lat = Number(url.searchParams.get("lat"));
    const lng = Number(url.searchParams.get("lng"));
    await new Promise((resolve) => setTimeout(resolve, geocodeDelay));
    await route.fulfill({ json: {
      lat, lng, area: "North Karachi", areaIsApproximate: false, outside: false,
      details: "L 691 5A2, Block 5, Sector 11-A, North Karachi",
      displayName: "L 691 5A2, Block 5, Sector 11-A, North Karachi",
      components: { house_number: "L 691 5A2", road: "Street 7", block: "5", sector: "11-A", suburb: "North Karachi", city: "Karachi", country_code: "pk" },
      houseNumber: "L 691 5A2", block: "Block 5", sector: "Sector 11-A", street: "Street 7",
      hasHouseNumber: true, hasStreet: true, attribution: "© OpenStreetMap contributors",
    } });
  });
}
const dialogFor = (page) => page.getByRole("dialog", { name: /Where should we deliver|Update Delivery Location/ });

try {
  const context = await browser.newContext({ viewport: { width: 390, height: 844 }, serviceWorkers: "block", permissions: ["geolocation"], geolocation: { latitude: 24.981234, longitude: 67.031234, accuracy: 9 } });
  await setup(context);
  const page = await context.newPage();
  page.on("pageerror", (error) => errors.push(error.message));
  await page.goto(base);
  const dialog = dialogFor(page);
  await expect(dialog).toBeVisible();
  await dialog.getByRole("button", { name: "Browse first", exact: true }).click();
  await expect(dialog).toHaveCount(0);
  await expect.poll(() => page.evaluate(() => localStorage.getItem("cashup-delivery-prompt-seen"))).toBe("true");

  // Real client navigation, followed by a reload and hard navigation.
  await page.locator('nav[aria-label="Mobile Navigation"] a[href="/categories"]').click();
  await page.waitForURL("**/categories");
  await expect(dialog).toHaveCount(0);
  await page.reload();
  await expect(page.getByRole("heading", { name: "Categories", exact: true })).toBeVisible();
  await expect(dialog).toHaveCount(0);
  await page.goto(`${base}/product/kinnow-1kg`);
  await expect(page.getByRole("heading", { name: "Kinnow", exact: true }).last()).toBeVisible();
  await expect(dialog).toHaveCount(0);
  console.log("PASS: dismiss persists through client navigation, reload and full navigation");

  await page.getByRole("button", { name: "Add", exact: true }).first().click();
  await expect(dialog).toBeVisible();
  await dialog.getByRole("button", { name: "Browse first", exact: true }).click();
  await page.goto(`${base}/cart`);
  await page.getByRole("button", { name: "Increase Kinnow", exact: true }).click();
  await expect(dialog).toBeVisible();
  await dialog.getByRole("button", { name: "Browse first", exact: true }).click();
  await page.getByRole("button", { name: "Register to order", exact: true }).click();
  await expect(dialog).toBeVisible();
  await dialog.getByRole("button", { name: "Browse first", exact: true }).click();
  await page.goto(`${base}/checkout`);
  await expect(dialog).toBeVisible();
  console.log("PASS: missing details requested on Add and checkout, including direct checkout");

  await dialog.getByLabel("Full name", { exact: true }).fill("Test Shopper");
  await dialog.getByLabel("Mobile number", { exact: true }).fill("03001234567");
  await dialog.getByRole("button", { name: "Use my current location", exact: true }).click();
  await expect(dialog.getByLabel("House Number", { exact: true })).toHaveValue("L 691 5A2");
  await expect(dialog.getByLabel("Block/Sector", { exact: true })).toHaveValue("Block 5, Sector 11-A");
  await expect(dialog.getByLabel("Area", { exact: true })).toHaveValue("North Karachi");
  await expect(dialog.getByTestId("delivery-live-map")).toHaveAttribute("data-lat", "24.981234");
  await expect(dialog.getByTestId("delivery-live-map")).toHaveAttribute("data-lng", "67.031234");
  await expect(dialog.getByText(/accuracy ±9 m/)).toBeVisible();
  await dialog.getByRole("button", { name: "Save & continue", exact: true }).click();
  await expect(dialog).toHaveCount(0);
  await expect(page.getByPlaceholder("Full name", { exact: true })).toHaveValue("Test Shopper");
  const saved = await page.evaluate(() => JSON.parse(localStorage.getItem("cashup-address")));
  expect(saved.lat).toBe(24.981234);
  expect(saved.lng).toBe(67.031234);
  expect(saved.details).toContain("Sector 11-A");
  expect(saved.accuracyMeters).toBe(9);
  console.log("PASS: mocked GPS/structured lookup fills full address, moves pin, saves exact coordinates");

  await page.goto(`${base}/categories`);
  await page.reload();
  await expect(dialog).toHaveCount(0);
  await page.goto(`${base}/product/kinnow-1kg`);
  await page.getByRole("button", { name: "Increase Kinnow", exact: true }).first().click();
  await expect(dialog).toHaveCount(0);
  await page.goto(`${base}/checkout`);
  await expect(page.getByPlaceholder("Full name", { exact: true })).toHaveValue("Test Shopper");
  await expect(dialog).toHaveCount(0);
  console.log("PASS: saved details suppress redundant Add/checkout prompts and stay prefilled");

  await page.getByRole("button", { name: "Change", exact: true }).click();
  await expect(dialog).toBeVisible();
  await dialog.getByLabel("Area", { exact: true }).fill("Clifton");
  await dialog.getByRole("button", { name: "Clifton", exact: true }).click();
  await expect(dialog.getByTestId("delivery-live-map")).toHaveAttribute("data-lat", "24.8138");
  await expect(dialog.getByTestId("delivery-live-map")).toHaveAttribute("data-lng", "67.0329");

  // A late result cannot overwrite what the shopper types while lookup runs.
  await context.setGeolocation({ latitude: 24.94, longitude: 67.04, accuracy: 8 });
  geocodeDelay = 1000;
  const requested = page.waitForRequest((r) => r.url().includes("/api/geocode?"));
  await dialog.getByRole("button", { name: "Use my current location", exact: true }).click();
  await requested;
  await dialog.getByLabel("House Number", { exact: true }).fill("Flat 9, my own entrance instructions");
  await expect(dialog.getByRole("button", { name: "Use mapped fields", exact: true })).toHaveCount(0);
  await expect(dialog.getByLabel("House Number", { exact: true })).toHaveValue("Flat 9, my own entrance instructions");
  await dialog.getByRole("button", { name: "Browse first", exact: true }).click();
  console.log("PASS: area selection recentres pin; late map data preserves manually entered details");

  // An IndexedDB failure must not prevent localStorage contact restoration.
  const backup = await browser.newContext({ viewport: { width: 1280, height: 850 }, serviceWorkers: "block" });
  await setup(backup);
  await backup.addInitScript(({ address }) => {
    localStorage.setItem("cashup-profile", JSON.stringify({ name: "Saved Shopper", phone: "923001234567", verified: false }));
    localStorage.setItem("cashup-address", JSON.stringify(address));
    Object.defineProperty(window, "indexedDB", { configurable: true, get() { throw new Error("Storage blocked for test"); } });
  }, { address: saved });
  const other = await backup.newPage();
  other.on("pageerror", (error) => errors.push(error.message));
  await other.goto(`${base}/categories`);
  await expect(other.getByRole("heading", { name: "Categories", exact: true })).toBeVisible();
  await expect(dialogFor(other)).toHaveCount(0);
  console.log("PASS: saved contact/address restored even when IndexedDB is unavailable");

  const denied = await browser.newContext({ viewport: { width: 390, height: 844 }, serviceWorkers: "block" });
  await setup(denied);
  const deniedPage = await denied.newPage();
  deniedPage.on("pageerror", (error) => errors.push(error.message));
  await deniedPage.goto(base);
  const deniedDialog = dialogFor(deniedPage);
  await expect(deniedDialog).toBeVisible();
  await deniedDialog.getByRole("button", { name: "Use my current location", exact: true }).click();
  await expect(deniedDialog.getByText(/Location permission is blocked/)).toBeVisible();
  await expect(deniedDialog.getByLabel("House Number", { exact: true })).toBeEditable();
  await deniedDialog.getByRole("button", { name: "Browse first", exact: true }).click();
  await expect(deniedDialog).toHaveCount(0);
  console.log("PASS: denied GPS permission gives a clear message and preserves manual entry / dismissal");

  const pwa = await browser.newContext({ viewport: { width: 390, height: 844 } });
  await setup(pwa);
  const pwaPage = await pwa.newPage();
  pwaPage.on("pageerror", (error) => errors.push(error.message));
  await pwaPage.goto(base);
  await expect(dialogFor(pwaPage)).toBeVisible();
  await dialogFor(pwaPage).getByRole("button", { name: "Browse first", exact: true }).click();
  await pwaPage.evaluate(() => Promise.race([
    navigator.serviceWorker.ready,
    new Promise((_, reject) => setTimeout(() => reject(new Error("Service worker not ready")), 20000)),
  ]));
  await pwaPage.reload();
  await expect(pwaPage.getByRole("heading", { name: "Explore Categories", exact: true })).toBeVisible();
  await expect(dialogFor(pwaPage)).toHaveCount(0);
  await pwaPage.locator('nav[aria-label="Mobile Navigation"] a[href="/categories"]').click();
  await expect(pwaPage.getByRole("heading", { name: "Categories", exact: true })).toBeVisible();
  await expect(dialogFor(pwaPage)).toHaveCount(0);
  console.log("PASS: prompt stays dismissed with the installed service worker controlling navigation");

  expect(errors).toEqual([]);
  console.log(`Browser checks passed; ${lookups.length} user-triggered reverse lookup requests, no runtime errors.`);
  await pwa.close();
  await denied.close();
  await backup.close();
  await context.close();
} finally { await browser.close(); }
