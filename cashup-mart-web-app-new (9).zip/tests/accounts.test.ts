import assert from "node:assert/strict";
import test, { beforeEach } from "node:test";
import * as accounts from "../src/lib/accounts";

const store = new Map<string, string>();
Object.defineProperty(globalThis, "window", {
  configurable: true,
  value: {
    localStorage: {
      getItem: (k: string) => store.get(k) ?? null,
      setItem: (k: string, v: string) => { store.set(k, v); },
      removeItem: (k: string) => { store.delete(k); },
    },
  },
});

beforeEach(() => store.clear());

const base = { name: "Ayesha Khan", phone: "0300 1234567", email: "Ayesha@Example.com", password: "groceries123" };

test("register hashes the password, normalises contact data and starts a session", async () => {
  const res = await accounts.registerAccount(base);
  assert.equal(res.ok, true);
  const raw = store.get("cashup-accounts")!;
  assert.doesNotMatch(raw, /groceries123/, "plain-text password must never be stored");
  const [saved] = JSON.parse(raw);
  assert.equal(saved.phone, "923001234567");
  assert.equal(saved.email, "ayesha@example.com");
  assert.ok(saved.passwordHash.length >= 40 && saved.salt.length >= 20);
  assert.equal(accounts.getSessionAccount()?.name, "Ayesha Khan");
  assert.equal("passwordHash" in (accounts.getSessionAccount() as object), false, "public account hides hash");
});

test("weak passwords, bad phones/emails and duplicates are rejected", async () => {
  assert.match((await accounts.registerAccount({ ...base, password: "short1" }) as { error: string }).error, /at least 8/);
  assert.match((await accounts.registerAccount({ ...base, password: "onlyletters" }) as { error: string }).error, /letter and one number/);
  assert.match((await accounts.registerAccount({ ...base, phone: "12345" }) as { error: string }).error, /valid Pakistani/);
  assert.match((await accounts.registerAccount({ ...base, email: "nope" }) as { error: string }).error, /valid email/);
  assert.equal((await accounts.registerAccount(base)).ok, true);
  assert.match((await accounts.registerAccount({ ...base, email: "" }) as { error: string }).error, /mobile number already exists/);
  assert.match((await accounts.registerAccount({ ...base, phone: "03111111111" }) as { error: string }).error, /email already exists/);
});

test("log out, then log back in with phone or email; wrong password fails generically", async () => {
  await accounts.registerAccount(base);
  accounts.clearSession();
  assert.equal(accounts.getSessionAccount(), null);
  const wrong = await accounts.loginAccount("03001234567", "wrongpass1");
  assert.deepEqual(wrong, { ok: false, error: "Incorrect mobile number/email or password." });
  const unknown = await accounts.loginAccount("nobody@example.com", "groceries123");
  assert.equal(unknown.ok, false);
  assert.equal((await accounts.loginAccount("+92 300 1234567", "groceries123")).ok, true);
  accounts.clearSession();
  assert.equal((await accounts.loginAccount("AYESHA@example.com", "groceries123")).ok, true);
});

test("repeated wrong passwords lock that identifier temporarily", async () => {
  await accounts.registerAccount(base);
  for (let i = 0; i < 5; i++) await accounts.loginAccount("03001234567", `wrong${i}xyz1`);
  const locked = await accounts.loginAccount("03001234567", "groceries123");
  assert.equal(locked.ok, false);
  assert.match((locked as { error: string }).error, /Too many attempts/);
});

test("profile updates validate uniqueness and password change requires the current password", async () => {
  const a = await accounts.registerAccount(base);
  const b = await accounts.registerAccount({ name: "Bilal", phone: "03111111111", password: "basket2024" });
  assert.ok(a.ok && b.ok);
  if (!a.ok || !b.ok) return;
  assert.match((accounts.updateAccount(b.account.id, { phone: "03001234567" }) as { error: string }).error, /already exists/);
  const updated = accounts.updateAccount(a.account.id, { email: "new@mail.com", avatar: "data:image/jpeg;base64,AAAA" });
  assert.ok(updated.ok && updated.account.avatar?.startsWith("data:image"));
  assert.equal((await accounts.changePassword(a.account.id, "nottheone1", "newpass2025")).ok, false);
  assert.equal((await accounts.changePassword(a.account.id, "groceries123", "newpass2025")).ok, true);
  accounts.clearSession();
  assert.equal((await accounts.loginAccount("new@mail.com", "groceries123")).ok, false);
  assert.equal((await accounts.loginAccount("new@mail.com", "newpass2025")).ok, true);
});
