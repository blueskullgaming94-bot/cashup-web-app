import { chromium, expect } from "@playwright/test";

const base = process.env.TEST_BASE_URL || "http://127.0.0.1:3000";
const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
const pixel = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+a6XkAAAAASUVORK5CYII=", "base64");
// 2x2 red PNG used as the "gallery" photo.
const photo = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAIAAAACCAIAAAD91JpzAAAAFklEQVR4nGP8z8DAwMDAxMDAwMDAAAANHQEDasKb6QAAAABJRU5ErkJggg==", "base64");
const errors = [];

try {
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 }, serviceWorkers: "block",
    permissions: ["geolocation", "clipboard-read", "clipboard-write"],
    geolocation: { latitude: 24.8138, longitude: 67.0329, accuracy: 12 },
  });
  await context.route(/https:\/\/(.*tile\.openstreetmap\.org|imglink\.cc)\/.*/, (r) => r.fulfill({ contentType: "image/png", body: pixel }));
  // A pin with no house number: the street must be filled instead.
  await context.route("**/api/geocode?*", (r) => {
    const u = new URL(r.request().url());
    return r.fulfill({ json: {
      lat: Number(u.searchParams.get("lat")), lng: Number(u.searchParams.get("lng")),
      area: "Clifton", areaIsApproximate: false, outside: false,
      details: "Street 12, Block 4, Clifton", displayName: "Street 12, Block 4, Clifton",
      components: { road: "Street 12", suburb: "Clifton Block 4" },
      houseNumber: "", street: "Street 12", block: "Block 4", sector: "",
      hasHouseNumber: false, hasStreet: true, attribution: "© OpenStreetMap contributors",
    } });
  });
  const page = await context.newPage();
  page.on("pageerror", (e) => errors.push(e.message));
  const dialog = page.getByRole("dialog", { name: /Where should we deliver|Update Delivery Location/ });
  const houseField = () => dialog.getByLabel("House Number", { exact: true });

  // ---- First-visit delivery details with street fallback --------------------
  await page.goto(base);
  await expect(dialog).toBeVisible();
  await dialog.getByLabel("Full name", { exact: true }).fill("Sana Ali");
  await dialog.getByLabel("Mobile number", { exact: true }).fill("03211234567");
  await dialog.getByRole("button", { name: "Use my current location", exact: true }).click();
  await expect(houseField()).toHaveValue("");
  await expect(dialog.getByLabel("Street / landmark (optional)")).toHaveValue("Street 12");
  await expect(dialog.getByTestId("houseNumber-hint")).toContainText("Please enter it manually");
  await houseField().fill("House 21");
  await dialog.getByRole("button", { name: "Save & continue", exact: true }).click();
  await expect(dialog).toHaveCount(0);
  console.log("PASS: pin without house number fills the street name; shopper can add the house number");

  // ---- Floating search bar --------------------------------------------------
  const bar = page.locator('[data-floating]');
  // The floating search bar belongs to the product-listing pages only.
  await page.goto(`${base}/account`);
  await expect(page.getByRole("heading", { name: "Log in or create an account" })).toBeVisible();
  await expect(bar).toHaveCount(0);
  await expect(page.getByPlaceholder("Search groceries & daily essentials...")).toHaveCount(0);
  // Nothing sticky on these pages, so the header cannot "scroll weirdly".
  await expect.poll(() => page.evaluate(() => {
    // Only visible headers count (the desktop bar is display:none on phones).
    const visible = [...document.querySelectorAll("header")].filter((el) => el.getClientRects().length > 0);
    return visible.some((el) => ["sticky", "fixed"].includes(getComputedStyle(el).position)) ? "sticky" : "static";
  })).toBe("static");
  console.log("PASS: non-listing pages (Account) have no floating search and no sticky header");
  await page.goto(base);
  const logo = bar.getByRole("link", { name: "CashUp Express home", includeHidden: true });
  await expect(bar).toHaveAttribute("data-floating", "false");
  await expect(logo).toHaveAttribute("aria-hidden", "true");
  await expect(page.getByRole("heading", { name: /CashUp|Shop by category|Delivering to/ }).first()).toBeVisible();
  await page.mouse.wheel(0, 900);
  await expect(bar).toHaveAttribute("data-floating", "true");
  await expect(logo).toHaveAttribute("aria-hidden", "false");
  // The floating bar sits on a purple tray whose bottom corners curve (300ms transition).
  await expect.poll(() => bar.evaluate((el) => getComputedStyle(el).borderBottomLeftRadius)).toBe("28px");
  await expect.poll(() => logo.evaluate((el) => Math.round(el.getBoundingClientRect().width))).toBe(44);
  const floatingState = await bar.evaluate((el) => ({
    top: Math.round(el.getBoundingClientRect().top),
    bg: getComputedStyle(el).backgroundColor,
    radiusL: getComputedStyle(el).borderBottomLeftRadius,
    radiusR: getComputedStyle(el).borderBottomRightRadius,
    shadow: getComputedStyle(el).boxShadow,
    logoX: Math.round(el.querySelector('a').getBoundingClientRect().left),
    searchX: Math.round(el.querySelector('form').getBoundingClientRect().left),
  }));
  expect(floatingState.top).toBe(0);
  expect(floatingState.bg).toBe("rgb(42, 75, 155)");
  expect(floatingState.radiusL).toBe("28px");
  expect(floatingState.radiusR).toBe("28px");
  expect(floatingState.shadow).not.toBe("none");
  expect(floatingState.logoX).toBeLessThan(floatingState.searchX);
  await expect(page.getByPlaceholder("Search groceries & daily essentials...")).toBeVisible();
  await page.evaluate(() => window.scrollTo(0, 0));
  await expect(bar).toHaveAttribute("data-floating", "false");

  // Typo-tolerant suggestions from the floating search bar.
  const input = page.getByPlaceholder("Search groceries & daily essentials...");
  await input.click();
  await input.fill("aple");
  const list = page.getByRole("listbox", { name: "Product suggestions" });
  await expect(list).toBeVisible();
  await expect(list.getByText("Red Apple")).toBeVisible();
  await input.fill("onoin");
  await expect(list.getByText("Onion")).toBeVisible();
  await input.fill("milkk");
  await expect(list.getByText("Milkpak Full Cream")).toBeVisible();
  await input.fill("chickn breest");
  await expect(list.getByText("Chicken Breast")).toBeVisible();
  await list.getByText("Chicken Breast").click();
  await page.waitForURL("**/product/chicken-breast-1kg");
  const addButton = page.getByRole("button", { name: "Add", exact: true }).first();
  const addBox = await addButton.boundingBox();
  expect(Math.abs(addBox.x + addBox.width / 2 - 195)).toBeLessThanOrEqual(2);
  expect(addBox.width).toBeGreaterThan(240);
  console.log("PASS: typo-tolerant suggestion opens PDP; mobile Add button is centered and full-width");
  await page.goto(base);
  await expect(bar).toHaveAttribute("data-floating", "false");
  await expect(logo).toHaveAttribute("aria-hidden", "true");
  await expect.poll(() => bar.evaluate((el) => getComputedStyle(el).borderBottomLeftRadius)).toBe("0px");
  console.log("PASS: logo + search float on a curved brand tray on scroll (logo on the left); flat again at top");

  // Categories also gets the floating bar, and its title header scrolls normally.
  await page.goto(`${base}/categories`);
  await expect(page.getByRole("heading", { name: "Categories", exact: true })).toBeVisible();
  await expect(page.locator('[data-floating]')).toHaveCount(1);
  await expect.poll(async () => {
    await page.evaluate(() => window.scrollTo(0, 1200));
    return page.locator('[data-floating]').getAttribute("data-floating");
  }).toBe("true");
  const title = page.locator("header", { hasText: "Categories" }).last();
  await title.scrollIntoViewIfNeeded();
  await expect(title).toBeInViewport();
  console.log("PASS: Categories floats its search bar too; its title header scrolls normally");

  // ---- Light / dark theme switch ------------------------------------------
  await page.goto(base);
  const themeOf = () => page.evaluate(() => document.documentElement.dataset.theme || "light");
  const bodyBg = () => page.evaluate(() => getComputedStyle(document.body).backgroundColor);
  await expect.poll(themeOf).toBe("light");
  const lightBg = await bodyBg();
  await page.getByRole("button", { name: "Switch to dark theme" }).click();
  await expect.poll(themeOf).toBe("dark");
  expect(await bodyBg()).not.toBe(lightBg);
  await expect(page.evaluate(() => localStorage.getItem("cashup-theme"))).resolves.toBe("dark");
  await page.reload();
  await expect.poll(themeOf).toBe("dark");
  await page.getByRole("button", { name: "Switch to light theme" }).click();
  await expect.poll(themeOf).toBe("light");
  expect(await bodyBg()).toBe(lightBg);
  // Desktop top bar carries a toggle too.
  await page.setViewportSize({ width: 1280, height: 900 });
  await expect(page.getByRole("button", { name: "Switch to dark theme" })).toBeVisible();
  await page.setViewportSize({ width: 390, height: 844 });
  console.log("PASS: theme switch toggles light/dark, persists across reload, exists on mobile and desktop");

  // ---- Create account with gallery photo ------------------------------------
  await page.goto(`${base}/account`);
  await page.getByRole("tab", { name: "Create account" }).click();
  const form = page.getByRole("form", { name: "Create account" });
  await expect(form.getByLabel("Full name", { exact: true })).toHaveValue("Sana Ali");
  await form.locator('input[type="file"]').setInputFiles({ name: "me.png", mimeType: "image/png", buffer: photo });
  await expect(form.getByRole("img", { name: "Profile photo" })).toHaveAttribute("src", /^data:image\/jpeg;base64,/);
  await form.getByLabel("Email (optional)").fill("sana@example.com");
  await form.getByLabel("Password", { exact: true }).fill("mart2024pk");
  await form.getByLabel("Confirm password", { exact: true }).fill("mart2024pk");
  await form.getByRole("button", { name: "Create account" }).click();
  await expect(page.getByRole("heading", { name: "Your profile" })).toBeVisible();
  await expect(page.getByRole("img", { name: "Profile photo" })).toHaveAttribute("src", /^data:image\/jpeg/);
  const stored = await page.evaluate(() => localStorage.getItem("cashup-accounts"));
  expect(stored).not.toContain("mart2024pk");
  expect(JSON.parse(stored)[0].address.details).toBe("House 21, Street 12, Block 4, Clifton");
  await page.reload();
  await expect(page.getByRole("heading", { name: "Your profile" })).toBeVisible();
  console.log("PASS: account created with gallery photo + email, password hashed, stays logged in after reload");

  // ---- Swipe a saved address right to delete it -----------------------------
  await page.getByRole("button", { name: "Add new" }).click();
  const section = page.locator("#addresses");
  await section.getByLabel("Area", { exact: true }).fill("Gulshan-e-Iqbal");
  await section.getByRole("button", { name: "Gulshan-e-Iqbal", exact: true }).click();
  await section.getByLabel("House Number", { exact: true }).fill("Flat 7");
  await section.getByLabel("Block/Sector", { exact: true }).fill("Block 13-D");
  await section.getByRole("button", { name: "Save location", exact: true }).click();
  const savedCount = () => page.evaluate(() => JSON.parse(localStorage.getItem("cashup-saved-addresses") || "[]").length);
  await expect.poll(savedCount).toBe(2);
  const row = page.getByRole("group", { name: "Home, Clifton" });
  await expect(row).toBeVisible();
  const deleteBtn = page.getByRole("button", { name: /Delete address Home, Clifton/ });
  await expect(deleteBtn).toHaveCount(0); // hidden until the row is swiped
  const swipe = async (distance) => {
    const box = await row.boundingBox();
    const y = box.y + box.height / 2;
    await page.mouse.move(box.x + 30, y);
    await page.mouse.down();
    for (let i = 1; i <= 8; i++) await page.mouse.move(box.x + 30 + (distance * i) / 8, y);
    await page.mouse.up();
  };
  await swipe(30); // too short: snaps back, nothing revealed
  await expect(deleteBtn).toHaveCount(0);
  await swipe(140);
  await expect(deleteBtn).toBeVisible();
  expect(await savedCount()).toBe(2); // swiping alone never deletes
  await row.click({ position: { x: 150, y: 20 } }); // tapping an open row closes it
  await expect(deleteBtn).toHaveCount(0);
  expect(await savedCount()).toBe(2);
  await row.focus();
  await page.keyboard.press("ArrowRight"); // keyboard alternative
  await expect(deleteBtn).toBeVisible();
  await deleteBtn.click();
  await expect(page.getByRole("group", { name: "Home, Clifton" })).toHaveCount(0);
  await expect.poll(savedCount).toBe(1);
  // The default (current) address has no delete control.
  await expect(page.getByText("DEFAULT")).toBeVisible();
  await expect(page.getByRole("button", { name: /Delete address Gulshan/ })).toHaveCount(0);
  console.log("PASS: swipe right reveals Delete; only tapping it removes the address; default address is protected");

  // ---- Log out, then log in from the delivery popup -------------------------
  await page.getByRole("button", { name: "Log out" }).click();
  await expect(page.getByRole("heading", { name: "Log in or create an account" })).toBeVisible();
  expect(await page.evaluate(() => localStorage.getItem("cashup-address"))).toBe("null");
  await page.goto(`${base}/product/kinnow-1kg`);
  await page.getByRole("button", { name: "Add", exact: true }).first().click();
  await expect(dialog).toBeVisible();
  await dialog.getByRole("button", { name: "Log in", exact: true }).click();
  await dialog.getByLabel("Mobile number or email").fill("sana@example.com");
  await dialog.getByLabel("Password", { exact: true }).fill("wrongpass9");
  await dialog.getByRole("button", { name: "Log in", exact: true }).click();
  await expect(dialog.getByText("Incorrect mobile number/email or password.")).toBeVisible();
  await dialog.getByLabel("Password", { exact: true }).fill("mart2024pk");
  await dialog.getByRole("button", { name: "Log in", exact: true }).click();
  await expect(dialog).toHaveCount(0);
  await expect(page.getByRole("button", { name: "Change delivery address" })).toContainText("Gulshan-e-Iqbal");
  console.log("PASS: logged out clears details; logging in from the popup restores saved address (no re-registering)");

  // Menu shows the account photo and a log-out option.
  await page.getByRole("button", { name: "Open menu" }).click();
  await expect(page.getByRole("dialog", { name: /Hi, Sana/ })).toBeVisible();
  await expect(page.getByRole("button", { name: "Log out" })).toBeVisible();
  console.log("PASS: menu shows signed-in profile and log out");

  await context.close();

  // ---- Verification code arrives as a phone-style notification --------------
  const otpCtx = await browser.newContext({
    viewport: { width: 390, height: 844 }, serviceWorkers: "block",
    permissions: ["clipboard-read", "clipboard-write"],
  });
  await otpCtx.addInitScript(() => {
    localStorage.setItem("cashup-delivery-prompt-seen", "true");
    localStorage.setItem("cashup-profile", JSON.stringify({ name: "Sana Ali", phone: "923211234567", verified: false }));
    localStorage.setItem("cashup-address", JSON.stringify({ label: "Home", houseNumber: "House 21", blockSector: "Block 4", area: "Clifton", details: "House 21, Block 4, Clifton", note: "", lat: 24.8138, lng: 67.0329 }));
    localStorage.setItem("cashup-cart", JSON.stringify([{ productId: "p001", qty: 2 }]));
  });
  let sendMode = "limited";
  await otpCtx.route("**/api/otp/send", (r) => sendMode === "limited"
    ? r.fulfill({ status: 429, json: { error: "Please wait before requesting another code" } })
    : r.fulfill({ json: { ok: true, code: "482913", ticket: "mock-ticket.signature", gatewayStatus: "sent", message: "Verification code sent." } }));
  await otpCtx.route("**/api/otp/verify", async (r) => {
    const body = JSON.parse(r.request().postData() || "{}");
    // Like the real stateless API, verification requires the ticket from /send.
    return body.code === "482913" && body.ticket === "mock-ticket.signature"
      ? r.fulfill({ json: { ok: true, phone: body.phone, name: body.name } })
      : r.fulfill({ status: 400, json: { error: "Your code has expired. Request a new verification code." } });
  });
  const op = await otpCtx.newPage();
  op.on("pageerror", (e) => errors.push(e.message));
  await op.goto(`${base}/checkout`);
  const notice = op.getByRole("alert", { name: "Verification code notification" });
  await op.getByRole("button", { name: "Send OTP", exact: true }).click();
  await expect(op.getByText("Please wait before requesting another code").first()).toBeVisible();
  await expect(notice).toHaveCount(0); // a rate-limited request never reveals a code
  await expect(op.getByLabel("Verification code", { exact: true })).toHaveCount(0);

  sendMode = "ok";
  await op.getByRole("button", { name: "Send OTP", exact: true }).click();
  await expect(notice).toBeVisible();
  await expect(op.getByTestId("code-notice-value")).toHaveText("482913");
  // Mobile: top banner, centred; the centered confirmation is desktop-only.
  await expect.poll(async () => Math.round((await notice.boundingBox()).y)).toBeLessThan(40);
  await expect.poll(async () => {
    const b = await notice.boundingBox();
    return Math.round(b.x + b.width / 2);
  }).toBe(195);
  await expect(op.getByRole("status", { name: "Code sent confirmation" })).toHaveCount(0);
  // Desktop: bottom-right panel plus the centered "Code Sent!" confirmation.
  await op.setViewportSize({ width: 1280, height: 900 });
  await expect.poll(async () => Math.round((await notice.boundingBox()).x)).toBeGreaterThan(750);
  await expect.poll(async () => { const b = await notice.boundingBox(); return Math.round(900 - b.y - b.height); }).toBe(24);
  await expect(notice.getByText(/Enter this code at checkout/)).toBeVisible();
  const confirmation = op.getByRole("status", { name: "Code sent confirmation" });
  await expect(confirmation).toBeVisible();
  await expect(confirmation).toHaveText("Code Sent!");
  const middle = await confirmation.boundingBox();
  expect(Math.abs(middle.x + middle.width / 2 - 640)).toBeLessThan(2);
  expect(Math.abs(middle.y + middle.height / 2 - 450)).toBeLessThan(2);
  await op.setViewportSize({ width: 390, height: 844 });
  await expect.poll(async () => Math.round((await notice.boundingBox()).y)).toBeLessThan(40);
  await expect(confirmation).toHaveCount(0);
  const body = op.locator("body");
  await expect(body).not.toContainText(/demo/i);
  await expect(body).not.toContainText(/always works/i);
  await expect(op.getByLabel("Verification code", { exact: true })).toBeVisible();
  await expect(op.getByRole("button", { name: /Resend code in \d+s/ })).toBeDisabled();
  await notice.getByRole("button", { name: "Copy" }).click();
  await expect(notice.getByRole("button", { name: "Copied" })).toBeVisible();
  expect(await op.evaluate(() => navigator.clipboard.readText())).toBe("482913");
  await notice.getByRole("button", { name: "Dismiss notification" }).click();
  await expect(notice).toHaveCount(0);

  await op.getByLabel("Verification code", { exact: true }).fill(await op.evaluate(() => navigator.clipboard.readText()));
  await op.getByRole("button", { name: "Verify phone", exact: true }).click();
  await expect(op.getByText(/Verified 0321/)).toBeVisible();
  console.log("PASS: code banner is top-centred on phones, bottom-right on desktop (+centered confirmation); Copy works; rate limits reveal no code");
  await otpCtx.close();

  expect(errors).toEqual([]);
  console.log("Account/header browser checks passed with no runtime errors.");
} finally {
  await browser.close();
}
