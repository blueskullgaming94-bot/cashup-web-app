# Delivery details and location behavior

**Latest requirements:** see [ADDRESS-FIELDS.md](./ADDRESS-FIELDS.md). House Number, Block/Sector and Area are now separate compulsory fields. A mapped street remains optional and never satisfies House Number. Missing auto-filled values show per-field manual-entry warnings. “Code Sent!” appears briefly in the centre; the copyable code card is bottom-right on phones and desktops. These requirements supersede the older combined-field and top-banner notes below.

## Prompt policy

- First visit on this browser: ask once for contact and a Karachi delivery address.
- Closing with **Browse first**, X, backdrop, or Escape records `cashup-delivery-prompt-seen` in localStorage (with session/in-memory fallback).
- Browsing pages, filters, search, and reloading do not reopen the initial prompt.
- **Add / increase quantity** and **checkout** request details only if the saved name, valid Pakistani mobile, Karachi pin or address text is missing.
- Saved details are reused; OTP verification at checkout is separate and unchanged.
- A manual **Deliver to / Change** click can always reopen the form.
- The global dialog is mounted at root level, including checkout. Closed dialogs unmount the map and cancel any GPS/address requests.
- Local profile/address keys are read independently of catalog/IndexedDB reads. Corrupt catalog data or blocked IndexedDB cannot erase contact information. Clearing browser storage resets first-visit behavior.

## GPS and address autofill

The **Use my current location** button starts a user-permission-based high-accuracy GPS watch (`maximumAge: 0`). It takes the best fix within 12 seconds, finishes early at reported accuracy <=25m, and clears the watch on completion, cancellation, or unmount.

The marker uses the device's actual coordinates, not an approximate area centre or the geocoder's nearest building. Accuracy is shown in metres and, on the live map, as a circle. A phone/location service cannot guarantee an exact doorstep or flat.

Once GPS settles, `/api/geocode` reverse-geocodes the pin at building detail (`zoom=18`, `addressdetails=1`, `layer=address`, `format=jsonv2`). The customer-facing field is deliberately concise: **house/building number, mapped block/sector, selected or nearby Karachi area only**. Roads/highways, administrative districts, divisions, city and country are omitted, since the nearest mapped road/district may not be the customer's own. The pin keeps the device's exact coordinates; it is never snapped to an OSM object. Missing house/sub-sector information is not guessed; manual text is preserved and the customer confirms it before saving.

For example, a noisy provider response `L933, Shahrah-e-Usman, North Karachi Sector 5, Nazimabad District, Karachi Division, …` is reduced to `L933, Sector 5, North Karachi`. If the provider only has `Sector 5`, it cannot infer `Sector 5A1`; that exact sub-sector can be entered/edited by the customer and is preserved.

Dragging/clicking the pin performs a debounced lookup. Selecting a broad area only moves the pin to the area's centre; it does not fabricate a house there. **Fill from pin** is an explicit retry. New results only auto-fill a blank or previously auto-generated field; manual edits are preserved, with a **Use mapped address** suggestion instead. Older/aborted results cannot overwrite a newer pin.

## Hosting / provider

The fullstack endpoint needs no database or API key. It uses the existing Nominatim-compatible service, caches repeated coordinates in-process, identifies the application, and serializes requests at >=1.1s intervals. It is limited to user-triggered Karachi delivery lookups, not autocomplete or background location tracking. API responses use `private, no-store`; coordinates are not written to shared CDN/service-worker caches.

- `GEOCODER_BASE_URL`: optional server-side Nominatim-compatible `/reverse` endpoint.
- `GEOCODER_USER_AGENT`: optional app-specific identification/contact for that service.
- `NEXT_PUBLIC_API_BASE`: hosted backend URL for static/Capacitor builds.
- `NEXT_PUBLIC_GEOCODER_URL`: optional public CORS-compatible endpoint for static builds without API routes.

Static drops with no `/api/geocode` route use the documented public CORS endpoint as a fallback. They throttle/cache locally. For a high-traffic or multi-instance production app, use a contracted or self-hosted geocoder and a shared rate limiter; the public Nominatim service has an application-wide limit of 1 request/second. See https://operations.osmfoundation.org/policies/nominatim/ and https://nominatim.org/release-docs/latest/api/Reverse/.

The UI attributes OpenStreetMap and states that only coordinates, not contact details, go to the lookup provider. Lookup failure or offline mode leaves manual address entry usable.

## Regression tests

- `node --import tsx --test tests/delivery.test.ts`
- `npx playwright install chromium` (one-time browser install)
- With the production preview running: `node tests/delivery-browser.mjs`
- Optional: `TEST_BASE_URL=https://your-preview.example node tests/delivery-browser.mjs`

Browser tests use mocked GPS/address responses (no real customer locations, SMS or orders).

## Street fallback

If the map has no house number at the dropped pin, the field is filled with the **street name/number** instead (e.g. `Street 12, Block 4, Clifton`) and the customer is asked to add their house/flat number. When a house number *is* mapped, the street is omitted to keep the address short. The area comes from the map's own neighbourhood (e.g. `Sultanabad`), never from administrative towns/districts, so a sector is never paired with the wrong area.

## Device accounts (log in / log out)

Account → **Create account** saves name, mobile, optional email, a profile photo chosen from the gallery (resized to a small 256px JPEG) and a password to this browser's localStorage. The password is never stored in plain text: it is hashed with PBKDF2-SHA-256 (random salt, 150,000 iterations, Web Crypto). Five wrong passwords lock that phone/email for 60 seconds.

- **Log in** works with mobile number or email, on the Account page or straight from the delivery popup ("Already have an account? Log in"), restoring saved contact details and addresses — no re-registering.
- **Log out** (Account page or menu) clears the active name/phone/address from the app; they remain in the account for the next login. The cart is kept.
- Accounts are **device-local**: they don't sync to another phone/browser, and clearing site data deletes them. Hashing requires HTTPS (or localhost); the Capacitor APK uses an https scheme.
- Tests: `node --import tsx --test tests/accounts.test.ts` and, with the preview running, `node tests/account-browser.mjs`.

## Verification-code notification

At checkout, **Send OTP** shows the code as a phone-style notification that slides down from the top (code in large digits, **Copy** button, **Dismiss**, swipe up to close, auto-hides after 45 s). There is no explanatory text under the fields; a resend button appears with a 45 s countdown.

- A real server answer (rate limit, database down) is shown as an error and **never** reveals a code.
- `OTP_REVEAL_CODE=false` stops the server returning the code, so it is delivered by SMS only. Because the notification shows the code on the same device, it does not prove the phone number is the shopper's — switch this off once the SMS gateway is live and trusted.

## Deleting saved addresses

Account → Saved addresses: swipe a non-default address **to the right** to reveal **Delete**; nothing is removed until that button is tapped. Tapping the row or swiping back hides it. Keyboard: focus the row and press Right Arrow, Left Arrow/Escape to hide. The default address can't be deleted (change the default instead). Deleting also updates the logged-in account's saved addresses.

## Floating header

On scroll the logo and search pill sit on a purple tray with curved bottom corners and a soft shadow; at the top it is flat and blends into the header.

## Header and search

- Page title bars (Cart, Orders, Account, Checkout, product pages…) are **not sticky** — they scroll with the page, so nothing slides oddly under them.
- The floating search bar (logo + search pill on a curved purple tray) exists **only on Home and Categories**, the pages where products are listed. Other pages have no search bar and nothing sticky.
- While typing, the bar drops product suggestions with photo, unit and brand, and **tolerates mistyped keywords** ("aple" → Apple, "onoin" → Onion, "milkk" → Milkpak, "chickn breest" → Chicken Breast). Arrow keys move through the list, Enter opens the highlighted item, and a final row opens full results. Matching runs on-device, so it works offline.

## Notification placement

Verification-code notification: **top banner on phones** (swipe up to dismiss), **bottom-right panel on desktop** — wider, with a larger code and a short explanation. Clipboard uses the async API with a hidden-textarea fallback for older WebViews; animations respect `prefers-reduced-motion`; `role="alert"` announces it for screen readers.
