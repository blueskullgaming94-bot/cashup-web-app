#!/usr/bin/env node
/**
 * Build a fully static site (./out) that can be dropped onto Edgio Pages.
 *
 * The customer app is offline-first: with no API reachable it renders the bundled
 * catalog and queues orders in IndexedDB. This script temporarily moves
 * `src/app/api` aside (route handlers cannot be statically exported), runs
 * `next build` with NEXT_STATIC=1 (output: "export"), then restores the folder.
 *
 * Usage:
 *   node scripts/edgio-static-build.mjs
 *   NEXT_PUBLIC_API_BASE=https://api.example.com node scripts/edgio-static-build.mjs
 */
import { spawnSync } from "node:child_process";
import { existsSync, renameSync, rmSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const apiDir = resolve(root, "src/app/api");
const backupDir = resolve(root, ".edgio-api-backup");

let moved = false;
try {
  if (existsSync(apiDir)) {
    rmSync(backupDir, { recursive: true, force: true });
    renameSync(apiDir, backupDir);
    moved = true;
    console.log("[edgio] moved src/app/api aside for static export");
  }
  rmSync(resolve(root, "out"), { recursive: true, force: true });

  const result = spawnSync("npx", ["next", "build"], {
    stdio: "inherit",
    cwd: root,
    env: { ...process.env, NEXT_STATIC: "1", NEXT_TELEMETRY_DISABLED: "1" },
    shell: process.platform === "win32",
  });
  if (result.status !== 0) {
    console.error("[edgio] static build failed");
    process.exitCode = result.status ?? 1;
  } else {
    console.log("[edgio] static site written to ./out — drop this folder into Edgio Pages");
  }
} finally {
  if (moved) {
    rmSync(apiDir, { recursive: true, force: true });
    renameSync(backupDir, apiDir);
    console.log("[edgio] restored src/app/api");
  }
}
