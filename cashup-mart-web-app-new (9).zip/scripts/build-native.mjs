#!/usr/bin/env node
/**
 * Build the static web bundle used by both the Edgio/EdgeOne drop AND the
 * Capacitor Android (APK) wrapper.
 *
 * It temporarily moves `src/app/api` aside (route handlers cannot be statically
 * exported), runs `next build` with NEXT_STATIC=1 (output: "export"), then
 * restores the folder. The result is ./out with a real index.html entry point.
 *
 * Usage:
 *   node scripts/build-native.mjs
 *   NEXT_PUBLIC_API_BASE=https://api.example.com node scripts/build-native.mjs
 */
import { spawnSync } from "node:child_process";
import { existsSync, renameSync, rmSync, statSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const apiDir = resolve(root, "src/app/api");
const backupDir = resolve(root, ".native-api-backup");
const outDir = resolve(root, "out");

let moved = false;
try {
  if (existsSync(apiDir)) {
    rmSync(backupDir, { recursive: true, force: true });
    renameSync(apiDir, backupDir);
    moved = true;
    console.log("[native] moved src/app/api aside for static export");
  }
  rmSync(outDir, { recursive: true, force: true });

  const result = spawnSync("npx", ["next", "build"], {
    stdio: "inherit",
    cwd: root,
    env: { ...process.env, NEXT_STATIC: "1", NEXT_TELEMETRY_DISABLED: "1" },
    shell: process.platform === "win32",
  });

  if (result.status !== 0) {
    console.error("[native] static build failed");
    process.exitCode = result.status ?? 1;
  } else if (!existsSync(resolve(outDir, "index.html"))) {
    console.error("[native] out/index.html missing after build");
    process.exitCode = 1;
  } else {
    const size = statSync(resolve(outDir, "index.html")).size;
    console.log(`[native] static web app ready in ./out (index.html ${size} bytes)`);
    console.log("[native] next: npx cap sync android  (see ANDROID.md to produce the APK)");
  }
} finally {
  if (moved) {
    rmSync(apiDir, { recursive: true, force: true });
    renameSync(backupDir, apiDir);
    console.log("[native] restored src/app/api");
  }
}
