"use client";

import { useStore } from "@/components/store";
import { STORE } from "@/lib/config";
import { PageTransition } from "./PageTransition";
import { Sheet, useToast } from "./ui";
import { ThemeIcon, ThemeToggle, useTheme } from "./Theme";
import { displayPhone } from "@/lib/phone";
import { MobileHeader } from "./MobileHeader";
import { MobileNavBar } from "./MobileNavBar";
import { Icon } from "./Icon";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";

const RAIL_NAV = [
  { href: "/", icon: "home", label: "Home" },
  { href: "/categories", icon: "categories", label: "Categories" },
  { href: "/search", icon: "search", label: "Search" },
  { href: "/offers", icon: "offers", label: "Offers" },
  { href: "/favorites", icon: "heart", label: "Favorites" },
  { href: "/cart", icon: "cart", label: "Cart" },
  { href: "/orders", icon: "orders", label: "Orders" },
  { href: "/account", icon: "user", label: "Account" },
  { href: "/help", icon: "help", label: "Help" },
] as const;

export function OfflineBanner() {
  const { online } = useStore();
  if (online) return null;

  return (
    <div className="flex items-center justify-center gap-2 bg-zx px-3 py-1.5 text-xs font-semibold text-white">
      <Icon name="offline" size={15} />
      <span>You are offline · showing saved catalog</span>
    </div>
  );
}

export function InstallPrompt() {
  const [event, setEvent] = useState<{ prompt: () => Promise<void> } | null>(null);
  const [hidden, setHidden] = useState(true);

  useEffect(() => {
    const on = (e: Event) => {
      e.preventDefault();
      setEvent(e as unknown as { prompt: () => Promise<void> });
      setHidden(false);
    };
    window.addEventListener("beforeinstallprompt", on);
    return () => window.removeEventListener("beforeinstallprompt", on);
  }, []);

  if (hidden || !event) return null;

  return (
    <div className="mx-3 sm:mx-4 mb-3 flex items-center justify-between gap-3 rounded-2xl bg-zx px-3.5 py-2.5 text-xs text-white shadow-sm">
      <span className="flex items-center gap-2 font-medium">
        <Icon name="delivery" className="text-zx-line" size={18} />
        Install CashUp Express for 1-tap offline shopping
      </span>
      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          className="rounded-xl bg-zx-yellow px-3 py-1 font-bold text-white text-xs hover:brightness-110 active:scale-95 transition"
          onClick={() => event.prompt()}
        >
          Install
        </button>
        <button
          type="button"
          className="text-white/60 hover:text-white p-1"
          onClick={() => setHidden(true)}
          aria-label="Dismiss"
        >
          <Icon name="close" size={14} />
        </button>
      </div>
    </div>
  );
}

function MenuSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { profile, account, logout } = useStore();
  const { theme, toggle } = useTheme();
  const toast = useToast();
  const wa = `https://wa.me/${STORE.supportWhatsApp}`;
  const name = account?.name || profile?.name || "";
  const items = [
    { href: "/account", icon: "user", label: account ? "My Profile" : "Log in / Create account" },
    { href: "/account#addresses", icon: "location", label: "Saved Delivery Addresses" },
    { href: "/favorites", icon: "heart", label: "My Favorites" },
    { href: "/offers", icon: "offers", label: "Deals & Promotions" },
    { href: "/help", icon: "help", label: "Help & FAQ" },
    { href: "/about", icon: "info", label: "About CashUp Express" },
    { href: "/terms", icon: "orders", label: "Terms of Service" },
    { href: "/privacy", icon: "info", label: "Privacy Policy" },
  ];

  return (
    <Sheet open={open} onClose={onClose} title={name ? `Hi, ${name.split(" ")[0]}` : "CashUp Express Menu"}>
      <Link href="/account" onClick={onClose} className="mb-4 flex items-center gap-3 rounded-2xl bg-zx-bg p-3">
        <span className="grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-full bg-zx-yellow text-lg font-bold text-white">
          {account?.avatar ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={account.avatar} alt="" className="h-full w-full object-cover" />
          ) : (name.charAt(0).toUpperCase() || <Icon name="user" size={20} />)}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-sm font-bold text-zx-ink">{account ? account.name : "Guest"}</span>
          <span className="block truncate text-xs text-zx-muted">
            {account ? (account.email || displayPhone(account.phone)) : "Log in to use your saved details"}
          </span>
        </span>
        <Icon name="chevron-right" size={16} className="text-zx-muted" />
      </Link>
      <button
        type="button"
        onClick={toggle}
        aria-label={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
        className="mb-3 flex min-h-11 w-full items-center gap-3 rounded-xl bg-zx-bg px-2.5 text-sm font-semibold text-zx-ink transition-all active:scale-[0.98]"
      >
        <span className="grid h-8 w-8 place-items-center rounded-lg bg-zx-card text-zx-ink">
          <ThemeIcon dark={theme === "dark"} />
        </span>
        <span className="flex-1 text-left">Appearance</span>
        <span className="rounded-full bg-zx-yellow/15 px-2.5 py-1 text-[11px] font-bold text-zx-ink">
          {theme === "dark" ? "Dark" : "Light"}
        </span>
      </button>
      <ul className="space-y-1">
        {items.map((item) => (
          <li key={item.label}>
            <Link
              href={item.href}
              onClick={onClose}
              className="flex min-h-11 items-center gap-3 rounded-xl px-2.5 text-sm font-medium text-zx-ink transition-all hover:bg-zx-bg active:scale-[0.98]"
            >
              <div className="grid h-8 w-8 place-items-center rounded-lg bg-zx-bg text-zx-ink">
                <Icon name={item.icon} size={18} />
              </div>
              <span className="flex-1 font-semibold">{item.label}</span>
              <Icon name="chevron-right" size={16} className="text-zx-muted" />
            </Link>
          </li>
        ))}
        <li className="pt-2">
          <a
            href={wa}
            target="_blank"
            rel="noopener noreferrer"
            className="flex min-h-11 items-center gap-3 rounded-xl bg-zx-yellow/20 px-3 py-2 text-sm font-bold text-zx-ink transition-colors hover:bg-zx-yellow/30"
          >
            <Icon name="whatsapp" size={20} className="text-emerald-600" />
            <span className="flex-1">WhatsApp Store Support</span>
            <Icon name="chevron-right" size={16} />
          </a>
        </li>
        {account && (
          <li>
            <button
              type="button"
              onClick={() => { logout(); onClose(); toast({ kind: "info", title: "Logged out" }); }}
              className="flex min-h-11 w-full items-center gap-3 rounded-xl px-2.5 text-left text-sm font-semibold text-zx-error hover:bg-zx-error/10"
            >
              <div className="grid h-8 w-8 place-items-center rounded-lg bg-zx-error/10"><Icon name="close" size={18} /></div>
              Log out
            </button>
          </li>
        )}
      </ul>
      <button
        type="button"
        className="mt-5 w-full rounded-xl bg-zx py-3 text-sm font-bold text-white transition-transform active:scale-98"
        onClick={onClose}
      >
        Close Menu
      </button>
    </Sheet>
  );
}

function DesktopRail({
  onMenu,
  cartCount,
  railState,
  onStateChange,
}: {
  onMenu: () => void;
  cartCount: number;
  railState: "expanded" | "collapsed" | "hidden";
  onStateChange: (s: "expanded" | "collapsed" | "hidden") => void;
}) {
  const pathname = usePathname();
  const collapsed = railState === "collapsed";
  const hideCompletely = railState === "hidden";

  return (
    <aside
      className={`zx-rail ${collapsed ? "collapsed" : ""} ${hideCompletely ? "hidden-completely" : ""}`}
      aria-hidden={hideCompletely}
    >
      <div className={`flex items-center gap-2 px-1 shrink-0 ${collapsed ? "justify-center" : "justify-between mb-4"}`}>
        <Link href="/" className="min-w-0" aria-label="CashUp Express home">
          {collapsed ? (
            /* eslint-disable-next-line @next/next/no-img-element */
            <img
              src="https://imglink.cc/cdn/iidohuM4Z3.png"
              onError={(e) => {
                if (!e.currentTarget.src.endsWith("/cashup-logo.png")) {
                  e.currentTarget.src = "/cashup-logo.png";
                }
              }}
              alt="CashUp"
              className="h-10 w-10 rounded-xl object-contain"
            />
          ) : (
            /* eslint-disable-next-line @next/next/no-img-element */
            <div className="flex items-center gap-2">
              <img
                src="https://imglink.cc/cdn/iidohuM4Z3.png"
                onError={(e) => {
                  if (!e.currentTarget.src.endsWith("/cashup-logo.png")) {
                    e.currentTarget.src = "/cashup-logo.png";
                  }
                }}
                alt="CashUp Express"
                className="h-10 w-10 rounded-xl object-contain shrink-0"
              />
              <span className="font-heading font-extrabold text-base tracking-tight text-white leading-tight">
                CashUp<span className="text-zx-yellow">.</span>
              </span>
            </div>
          )}
        </Link>
        {!collapsed && (
          <div className="flex justify-end zx-rail-extra">
            {/* Desktop: only the minimize (collapse) control. It sits exactly where the
                removed X (hide) button used to be — far right of the rail header. */}
            <button
              type="button"
              onClick={() => onStateChange("collapsed")}
              className="grid h-8 w-8 place-items-center rounded-lg hover:bg-zx-card/10 text-zx-yellow"
              title="Collapse menu"
              aria-label="Collapse menu"
            >
              <Icon name="chevron-left" size={16} />
            </button>
          </div>
        )}
      </div>

      <div className="zx-rail-nav">
        {RAIL_NAV.map((item) => {
          const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`${active ? "active" : ""} relative group shrink-0`}
              title={collapsed ? item.label : undefined}
            >
              <Icon name={item.icon} size={20} />
              <span className="zx-rail-label truncate">{item.label}</span>
              {item.href === "/cart" && cartCount > 0 && (
                <span
                  className={`rounded-full bg-zx px-2 py-0.5 text-[11px] font-bold text-white ${
                    collapsed ? "absolute -top-1.5 -right-1.5" : "ml-auto"
                  }`}
                >
                  {cartCount}
                </span>
              )}
            </Link>
          );
        })}

        <button type="button" onClick={onMenu} title={collapsed ? "More" : undefined} className="relative group">
          <Icon name="menu" size={20} />
          <span className="zx-rail-label">More</span>
        </button>
      </div>

      <div className="shrink-0 space-y-2 px-1 pt-4 border-t border-white/10 mt-2">
        {collapsed ? (
          <a
            href={`https://wa.me/${STORE.supportWhatsApp}`}
            className="grid h-11 w-11 place-items-center rounded-xl bg-zx-yellow text-white mx-auto"
            title="WhatsApp Support"
          >
            <Icon name="whatsapp" size={18} />
          </a>
        ) : (
          <div className="zx-rail-extra space-y-2">
            <a
              href={`https://wa.me/${STORE.supportWhatsApp}`}
              className="flex items-center gap-2 rounded-xl bg-zx-yellow px-3 py-2.5 text-sm font-bold text-white justify-center"
            >
              <Icon name="whatsapp" size={18} /> WhatsApp Support
            </a>
            <p className="text-[10px] leading-tight text-white/55 text-center">
              Cash on Delivery only
              <br />
              Karachi · {STORE.tagline}
            </p>
          </div>
        )}
        {collapsed && (
          <button
            type="button"
            onClick={() => onStateChange("expanded")}
            className="grid h-10 w-10 place-items-center rounded-xl hover:bg-zx-card/10 text-zx-yellow mx-auto"
            title="Expand menu"
          >
            <Icon name="chevron-right" size={16} />
          </button>
        )}
      </div>
    </aside>
  );
}

function DesktopTopBar({
  railState,
  onStateChange,
}: {
  railState: "expanded" | "collapsed" | "hidden";
  onStateChange: (s: "expanded" | "collapsed" | "hidden") => void;
}) {
  const { address, online, setLocationModalOpen, cartCount } = useStore();
  const router = useRouter();
  const [q, setQ] = useState("");
  const hidden = railState === "hidden";
  return (
    <header className="sticky top-0 z-40 hidden h-16 items-center justify-between gap-4 border-b border-zx-line/40 bg-zx-card px-6 md:flex shadow-xs">
      {/* Left section: menu toggle + brand (when rail hidden) + Deliver To pill */}
      <div className="flex items-center gap-3 shrink-0">
        {hidden && (
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => onStateChange("expanded")}
              className="grid h-10 w-10 place-items-center rounded-xl bg-zx-bg hover:bg-zx-line/20 text-zx-ink transition-transform active:scale-95 shrink-0"
              title="Open menu"
            >
              <Icon name="menu" size={20} />
            </button>
            <Link href="/" className="flex items-center gap-2 mr-1">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="https://imglink.cc/cdn/iidohuM4Z3.png"
                onError={(e) => {
                  if (!e.currentTarget.src.endsWith("/cashup-logo.png")) {
                    e.currentTarget.src = "/cashup-logo.png";
                  }
                }}
                alt="CashUp Express"
                className="h-8 w-8 rounded-lg object-contain"
              />
              <span className="font-heading font-extrabold text-sm tracking-tight text-zx-ink">
                CashUp<span className="text-zx-yellow">.</span>
              </span>
            </Link>
          </div>
        )}

        <button
          type="button"
          onClick={() => setLocationModalOpen(true)}
          className="flex items-center gap-2.5 rounded-full bg-zx-bg border border-zx-line/40 hover:border-zx-yellow px-3.5 py-1.5 transition text-left cursor-pointer active:scale-98"
        >
          <div className="grid h-7 w-7 place-items-center rounded-full bg-zx-yellow text-white shrink-0">
            <Icon name="location" size={15} />
          </div>
          <div className="min-w-0">
            <span className="block text-[10px] uppercase tracking-wider text-zx-muted font-extrabold leading-none">Deliver to</span>
            <span className="flex items-center gap-1 font-bold text-xs text-zx-ink mt-0.5">
              <span className="max-w-[130px] truncate">{address ? `${address.area}` : "Choose location"}</span>
              <Icon name="chevron-right" size={12} className="opacity-70" />
            </span>
          </div>
        </button>
      </div>

      {/* Center section: Search Bar with clean alignment and focus states */}
      <div className="flex-1 max-w-xl mx-2">
        <form
          className="relative flex h-11 items-center gap-2.5 rounded-full bg-zx-bg border border-zx-line/40 px-4 focus-within:border-zx-yellow focus-within:ring-2 focus-within:ring-zx-yellow/20 transition-all"
          onSubmit={(e) => {
            e.preventDefault();
            if (q.trim()) router.push(`/search?q=${encodeURIComponent(q.trim())}`);
          }}
        >
          <Icon name="search" size={18} className="text-zx-muted shrink-0" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search 110+ grocery items in Karachi..."
            className="w-full bg-transparent text-sm outline-none font-medium placeholder:text-zx-muted text-zx-ink"
            aria-label="Search products"
          />
          {q && (
            <button
              type="button"
              onClick={() => setQ("")}
              className="p-1 text-zx-muted hover:text-zx-ink"
              aria-label="Clear search"
            >
              <Icon name="close" size={14} />
            </button>
          )}
        </form>
      </div>

      {/* Right section: Online status, Theme toggle, Phone Support, and Quick Cart */}
      <div className="flex items-center gap-2.5 shrink-0">
        <span className="flex items-center gap-1.5 rounded-full bg-zx-bg border border-zx-line/30 px-3 py-2 text-xs font-semibold text-zx-muted">
          <span className={`h-2 w-2 rounded-full zx-pulse ${online ? "bg-zx-success" : "bg-zx-error"}`} />
          <span>{online ? "Online" : "Offline"}</span>
        </span>

        <ThemeToggle className="bg-zx-bg border border-zx-line/30 hover:border-zx-yellow text-zx-ink" />

        <a
          href={`tel:${STORE.supportPhone}`}
          className="flex items-center gap-1.5 h-10 px-3.5 rounded-full bg-zx-bg border border-zx-line/30 hover:border-zx-yellow text-xs font-bold text-zx-ink transition"
        >
          <Icon name="phone" size={15} />
          <span>{STORE.supportPhone}</span>
        </a>

        <Link
          href="/cart"
          className="relative flex items-center justify-center gap-1.5 h-10 px-4 rounded-full bg-zx-yellow text-white font-bold text-xs shadow-xs hover:brightness-105 active:scale-95 transition-transform"
          aria-label={`Cart, ${cartCount} items`}
        >
          <Icon name="cart" size={17} />
          <span>Cart</span>
          {cartCount > 0 && (
            <span className="ml-0.5 grid h-5 min-w-5 place-items-center rounded-full bg-zx px-1 text-[10px] font-extrabold text-white ring-1 ring-white/50">
              {cartCount}
            </span>
          )}
        </Link>

        {railState === "collapsed" && (
          <button
            type="button"
            onClick={() => onStateChange("expanded")}
            className="flex items-center justify-center h-10 w-10 rounded-full border border-zx-line/30 bg-zx-bg hover:border-zx-yellow text-zx-ink transition active:scale-95"
            title="Expand menu"
          >
            <Icon name="chevron-right" size={16} />
          </button>
        )}
      </div>
    </header>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const { hydrated, cartCount, promptForDelivery } = useStore();
  const pathname = usePathname();
  const router = useRouter();
  const [menu, setMenu] = useState(false);
  const bare = pathname.startsWith("/checkout") || pathname.startsWith("/ops") || pathname.startsWith("/location");
  const orderNowExcluded = ["/cart", "/checkout", "/ops", "/location", "/order", "/orders"];
  const showOrderNow = cartCount > 0 && !orderNowExcluded.some((path) => pathname.startsWith(path));

  const [railState, setRailState] = useState<"expanded" | "collapsed" | "hidden">("expanded");

  useEffect(() => {
    if (typeof window !== "undefined") {
      const cached = localStorage.getItem("cashup-rail-state");
      // The desktop X (hide) control was removed — migrate any stored "hidden"
      // state to "collapsed" so the rail never gets stuck invisible.
      if (cached === "hidden") {
        setRailState("collapsed");
        localStorage.setItem("cashup-rail-state", "collapsed");
      } else if (cached === "collapsed" || cached === "expanded") {
        setRailState(cached);
      }
    }
  }, []);

  const handleStateChange = (state: "expanded" | "collapsed" | "hidden") => {
    // "hidden" is no longer reachable from the desktop UI (X removed), but the
    // type + top-bar recovery path are kept for older cached states.
    const next = state === "hidden" ? "collapsed" : state;
    setRailState(next);
    localStorage.setItem("cashup-rail-state", next);
  };

  useEffect(() => {
    if ("serviceWorker" in navigator) {
      // Query version forces static hosts and browsers to fetch the updated
      // worker even when an old service worker cached /sw.js too aggressively.
      navigator.serviceWorker.register("/sw.js?build=inlined-art-v15").catch(() => undefined);
    }
  }, []);

  useEffect(() => {
    if (hydrated && !bare) promptForDelivery("first-visit");
  }, [hydrated, bare, promptForDelivery]);

  if (!hydrated) {
    return (
      <div className="min-h-dvh bg-zx-bg">
        <div className="zx-skel h-16 w-full rounded-none" />
        <div className="grid grid-cols-2 gap-3 p-4 md:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="zx-skel h-48 rounded-2xl" />
          ))}
        </div>
      </div>
    );
  }

  if (bare) {
    return (
      <div className="min-h-dvh bg-zx-bg">
        <OfflineBanner />
        <PageTransition>{children}</PageTransition>
      </div>
    );
  }

  const railWidth = railState === "expanded" ? "232px" : railState === "collapsed" ? "76px" : "0px";

  return (
    <div
      className="flex min-h-dvh bg-zx-bg"
      style={{ ["--zx-rail-w" as string]: railWidth }}
    >
      {/* Desktop Persistent Left Rail Navigation */}
      <DesktopRail
        onMenu={() => setMenu(true)}
        cartCount={cartCount}
        railState={railState}
        onStateChange={handleStateChange}
      />

      <div className="zx-main flex flex-col min-w-0 w-full overflow-x-clip">
        <OfflineBanner />

        {/* Desktop Top Header Bar */}
        <DesktopTopBar railState={railState} onStateChange={handleStateChange} />

        {/* Mobile Header (Foodpanda style top bar: Location + Favorites + Search) */}
        <MobileHeader />

        <main className="w-full max-w-6xl mx-auto pb-24 md:pb-10">
          <PageTransition>{children}</PageTransition>
        </main>

        {/* Mobile Bottom Hamburger Navigation Bar */}
        <MobileNavBar onMenu={() => setMenu(true)} />
      </div>

      {showOrderNow && (
        <div className="pointer-events-none fixed inset-x-4 bottom-[calc(5.5rem+env(safe-area-inset-bottom))] z-40 flex justify-center md:inset-x-auto md:bottom-6 md:right-6">
          <button
            type="button"
            onClick={() => {
              if (promptForDelivery("checkout")) router.push("/checkout");
            }}
            className="pointer-events-auto flex min-h-12 w-full max-w-sm items-center justify-center gap-2.5 rounded-2xl bg-zx-yellow px-5 text-sm font-extrabold text-white shadow-[0_10px_28px_rgba(26,31,44,0.3)] ring-1 ring-white/30 transition hover:brightness-105 active:scale-[0.98] md:w-auto"
            aria-label={`Order now, ${cartCount} items in cart`}
          >
            <Icon name="cart" size={18} />
            <span>Order Now!</span>
            <span className="grid h-6 min-w-6 place-items-center rounded-full bg-zx px-1.5 text-[11px] font-extrabold text-white">
              {cartCount}
            </span>
            <Icon name="chevron-right" size={16} />
          </button>
        </div>
      )}

      {/* Hamburger Menu Bottom Sheet */}
      <MenuSheet open={menu} onClose={() => setMenu(false)} />


    </div>
  );
}
