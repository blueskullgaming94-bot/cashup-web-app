"use client";

import { CategoryIcon3D, ProductGrid } from "@/components/catalog-ui";
import { useStore } from "@/components/store";
import { PageHeader } from "@/components/ui";
import { unitPrice } from "@/lib/money";
import { useParams, useRouter } from "next/navigation";
import { useMemo, useState } from "react";

export function CategoryBody() {
  const { slug } = useParams<{ slug: string }>();
  const router = useRouter();
  const { catalog } = useStore();
  const category = catalog.categories.find((c) => c.slug === slug);
  
  const [sub, setSub] = useState("All");
  const [brand, setBrand] = useState("all");
  const [offersOnly, setOffersOnly] = useState(false);
  const [sort, setSort] = useState("popular");
  const [maxPrice, setMaxPrice] = useState(3000);

  // Filter products by this category first
  const categoryProducts = useMemo(() => {
    return catalog.products.filter((p) => p.active && p.category === slug);
  }, [catalog.products, slug]);

  // Extract all unique brands dynamically according to this category's products
  const categoryBrands = useMemo(() => {
    return Array.from(new Set(categoryProducts.map((p) => p.brand))).sort();
  }, [categoryProducts]);

  // Find the highest regular or sale price in this category to set range dynamic bounds
  const highestPrice = useMemo(() => {
    if (!categoryProducts.length) return 2000;
    return Math.max(...categoryProducts.map((p) => unitPrice(p.price, p.salePrice)));
  }, [categoryProducts]);

  // Apply all search filters
  const filteredItems = useMemo(() => {
    let list = [...categoryProducts];
    if (sub !== "All") {
      list = list.filter((p) => p.subcategory === sub);
    }
    if (brand !== "all") {
      list = list.filter((p) => p.brand === brand);
    }
    if (offersOnly) {
      list = list.filter((p) => p.salePrice && p.salePrice < p.price);
    }
    list = list.filter((p) => unitPrice(p.price, p.salePrice) <= maxPrice);

    // Apply sorting
    if (sort === "price-asc") {
      list.sort((a, b) => unitPrice(a.price, a.salePrice) - unitPrice(b.price, b.salePrice));
    } else if (sort === "price-desc") {
      list.sort((a, b) => unitPrice(b.price, b.salePrice) - unitPrice(a.price, a.salePrice));
    } else if (sort === "popular") {
      list.sort((a, b) => Number(b.tags.includes("popular")) - Number(a.tags.includes("popular")));
    } else if (sort === "new") {
      list.sort((a, b) => Number(b.tags.includes("new")) - Number(a.tags.includes("new")));
    }
    return list;
  }, [categoryProducts, sub, brand, offersOnly, maxPrice, sort]);

  // Set the slider's initial default max price on load
  useState(() => {
    if (highestPrice > 0) setMaxPrice(highestPrice);
  });

  if (!category) {
    return (
      <div>
        <PageHeader title="Category" back="" onClose={() => router.push("/categories")} />
        <p className="p-6 text-sm text-zx-muted">Category not found.</p>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title={category.name} back="" onClose={() => router.push("/categories")} />
      <div className="pt-3">
        {/* Category Header Card */}
        <div className="mb-3 flex items-center gap-3 px-4">
          <span className="zx-cat3d-cell grid h-12 w-12 shrink-0 place-items-center rounded-[16px] bg-gradient-to-b from-white to-zx-bg shadow-[0_8px_18px_rgba(26,31,44,0.14)] ring-1 ring-zx-line/30">
            <CategoryIcon3D slug={category.slug} size={40} />
          </span>
          <div className="min-w-0">
            <p className="text-sm text-zx-muted font-medium">{category.blurb}</p>
            <p className="text-xs font-bold text-zx-muted">{filteredItems.length} products found</p>
          </div>
        </div>

        {/* Subcategory Chips Row */}
        <div className="no-scrollbar mb-3 flex gap-2 overflow-x-auto px-4">
          {["All", ...category.subcategories].map((c) => (
            <button key={c} type="button" onClick={() => setSub(c)} className={`zx-chip ${sub === c ? "on" : ""}`}>
              {c}
            </button>
          ))}
        </div>

        {/* Category Specific Filters & Sorters */}
        <div className="no-scrollbar mb-4 flex items-center gap-2 overflow-x-auto px-4 py-1">
          {/* Dynamic Brands Filter */}
          <select
            value={brand}
            onChange={(e) => setBrand(e.target.value)}
            className="zx-chip appearance-none pr-6 font-semibold cursor-pointer border-1.5 border-zx-line/40 hover:border-zx-yellow transition-colors"
            aria-label="Brand Filter"
          >
            <option value="all">All brands ({categoryBrands.length})</option>
            {categoryBrands.map((b) => (
              <option key={b} value={b}>
                {b}
              </option>
            ))}
          </select>

          {/* Sorter Dropdown */}
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="zx-chip appearance-none pr-6 font-semibold cursor-pointer border-1.5 border-zx-line/40 hover:border-zx-yellow transition-colors"
            aria-label="Sort products"
          >
            <option value="popular">Popular first</option>
            <option value="price-asc">Price: low to high</option>
            <option value="price-desc">Price: high to low</option>
            <option value="new">New arrivals</option>
          </select>

          {/* Regular vs Sale discount only */}
          <button
            type="button"
            onClick={() => setOffersOnly((v) => !v)}
            className={`zx-chip border-1.5 border-zx-line/40 ${offersOnly ? "on" : ""}`}
            aria-pressed={offersOnly}
          >
            Offers Only
          </button>

          {/* Max Price Range Filter Slider */}
          <label className="flex h-10 shrink-0 items-center gap-2 rounded-full bg-zx-card px-3 text-xs font-bold border-1.5 border-zx-line/40 shadow-sm">
            Max Rs. {maxPrice}
            <input
              type="range"
              min={50}
              max={highestPrice || 3000}
              step={10}
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="accent-zx-yellow cursor-pointer"
            />
          </label>
        </div>

        {/* Products Grid output */}
        <ProductGrid key={`${slug}-${sub}-${brand}-${offersOnly}-${maxPrice}-${sort}`} products={filteredItems} />
      </div>
    </div>
  );
}
