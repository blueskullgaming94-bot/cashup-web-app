"use client";

import { AREA_COORDS, KARACHI_CENTER, OUTSIDE_CITY_MESSAGE, isInsideKarachi, searchAreas } from "@/lib/karachi";
import { displayPhone, formatPkPhone, isValidPkMobile, normalizePkPhone } from "@/lib/phone";
import { reverseGeocode } from "@/lib/reverse-geocode";
import { ADDRESS_LABELS, ADDRESS_LIMITS, REQUIRED_ADDRESS_FIELDS, addressText, fieldsFromMap, fieldsFromSavedAddress, formatAddressDetails, hasRequiredAddressFields, missingMappedFields, requiredAddressErrors, type AddressFieldErrors, type DeliveryFields, type RequiredAddressField } from "@/lib/address-fields";
import type { MapAddress } from "@/lib/geocode";
import { useEffect, useId, useMemo, useRef, useState } from "react";
import { Icon } from "./Icon";
import { KarachiMap, type PinSelection } from "./karachi-map";
import { useStore } from "./store";
import { PageHeader, useToast } from "./ui";
import { LoginForm } from "./AuthForms";

type Variant = "page" | "embed" | "modal";
type EditableField = keyof DeliveryFields;
const FIELD_KEYS: EditableField[] = ["houseNumber", "blockSector", "area", "street"];
const PLACEHOLDERS: Record<RequiredAddressField, string> = {
  houseNumber: "e.g. L933 or Flat 4B", blockSector: "e.g. Sector 5A1 or Block 4", area: "e.g. North Karachi",
};

export function LocationPicker({ onDone, onClose, variant = "page", showContact = true }: {
  onDone?: () => void;
  onClose?: () => void;
  variant?: Variant;
  showContact?: boolean;
}) {
  const toast = useToast();
  const { address, saveAddress, profile, setProfile, online, account } = useStore();
  const id = useId();
  const [showLogin, setShowLogin] = useState(false);
  const [name, setName] = useState(profile?.name ?? "");
  const [phone, setPhone] = useState(profile?.phone ?? "");
  const [fields, setFields] = useState<DeliveryFields>(() => fieldsFromSavedAddress(address));
  const [note, setNote] = useState(address?.note ?? "");
  const [label, setLabel] = useState(address?.label ?? "Home");
  const [lat, setLat] = useState(address?.lat ?? KARACHI_CENTER.lat);
  const [lng, setLng] = useState(address?.lng ?? KARACHI_CENTER.lng);
  const [accuracy, setAccuracy] = useState<number | undefined>(address?.accuracyMeters);
  const [pinSelected, setPinSelected] = useState(Boolean(address));
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState<AddressFieldErrors>({});
  const [saved, setSaved] = useState(false);
  const [lookupBusy, setLookupBusy] = useState(false);
  const [lookupMessage, setLookupMessage] = useState("");
  const [autofillMissing, setAutofillMissing] = useState<RequiredAddressField[]>([]);
  const [suggestion, setSuggestion] = useState<MapAddress | null>(null);
  const fieldsRef = useRef(fields);
  fieldsRef.current = fields;
  // Manual edits and previously saved details are protected from late responses.
  const manual = useRef<Record<EditableField, boolean>>({
    houseNumber: Boolean(fields.houseNumber), blockSector: Boolean(fields.blockSector),
    area: Boolean(fields.area), street: Boolean(fields.street),
  });
  const request = useRef<AbortController | null>(null);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);
  const explicitlyChosenArea = useRef(false);
  const inputRefs = useRef<Partial<Record<RequiredAddressField, HTMLInputElement | null>>>({});
  const inside = isInsideKarachi(lat, lng);
  const matches = useMemo(() => searchAreas(fields.area).slice(0, 6), [fields.area]);

  useEffect(() => () => {
    request.current?.abort();
    if (debounce.current) clearTimeout(debounce.current);
  }, []);

  function cancelLookup() {
    request.current?.abort();
    request.current = null;
    if (debounce.current) clearTimeout(debounce.current);
    debounce.current = null;
    setLookupBusy(false);
  }

  function updateFields(next: DeliveryFields) {
    fieldsRef.current = next;
    setFields(next);
    setSaved(false);
  }

  function changeField(key: EditableField, value: string) {
    manual.current[key] = true;
    updateFields({ ...fieldsRef.current, [key]: value });
    if (key !== "street") setFieldErrors((prev) => ({ ...prev, [key]: undefined }));
    setError("");
  }

  function applyMappedFields(result: MapAddress) {
    const available = fieldsFromMap(result);
    const next = { ...fieldsRef.current };

    // Directly autofill the fields with values detected from the map
    if (available.houseNumber) next.houseNumber = available.houseNumber;
    if (available.blockSector) next.blockSector = available.blockSector;
    if (available.area) next.area = available.area;
    if (available.street) next.street = available.street;

    updateFields(next);
    const missing = missingMappedFields(available);
    setAutofillMissing(missing);
    setFieldErrors({});
    setSuggestion(result);

    if (missing.length > 0) {
      setLookupMessage(
        `Autofill failed to detect ${missing.map((key) => ADDRESS_LABELS[key]).join(", ")} from map. Please enter manually.`
      );
    } else {
      setLookupMessage("All 3 required fields autofilled from map.");
    }
  }

  async function lookup(la: number, lo: number, preferredArea?: string) {
    cancelLookup();
    if (!isInsideKarachi(la, lo)) return;
    const controller = new AbortController();
    request.current = controller;
    setLookupBusy(true);
    setLookupMessage("Detecting House Number, Block/Sector and Area…");
    try {
      const result = await reverseGeocode(la, lo, preferredArea, controller.signal);
      if (controller.signal.aborted) return;
      if (result.outside) {
        setError(OUTSIDE_CITY_MESSAGE);
        setAutofillMissing([...REQUIRED_ADDRESS_FIELDS]);
        setLookupMessage(OUTSIDE_CITY_MESSAGE);
        return;
      }
      applyMappedFields(result);
    } catch (err) {
      if (controller.signal.aborted) return;
      setAutofillMissing([...REQUIRED_ADDRESS_FIELDS]);
      setLookupMessage("Address autofill failed. Please enter House Number, Block/Sector and Area manually. Your selected pin and typed values are kept.");
      if (err instanceof Error && !online) setLookupMessage("You are offline. Autofill is unavailable; enter House Number, Block/Sector and Area manually.");
    } finally {
      if (request.current === controller) { request.current = null; setLookupBusy(false); }
    }
  }

  function clearAutoFields() {
    const next = { ...fieldsRef.current };
    for (const key of FIELD_KEYS) if (!manual.current[key]) next[key] = "";
    updateFields(next);
    setSuggestion(null);
    setAutofillMissing([]);
    setFieldErrors({});
  }

  function pickArea(selected: string) {
    cancelLookup();
    const coords = AREA_COORDS[selected];
    if (!coords) return;
    clearAutoFields();
    changeField("area", selected);
    setLat(coords.lat); setLng(coords.lng); setAccuracy(undefined); setPinSelected(true);
    explicitlyChosenArea.current = true;
    setLookupMessage("Area selected. Move the pin to your entrance or use your current location, then complete all three required fields.");
  }

  function selectPin(la: number, lo: number, selection?: PinSelection) {
    cancelLookup();
    clearAutoFields();
    setLat(la); setLng(lo); setAccuracy(selection?.accuracy); setPinSelected(true);
    explicitlyChosenArea.current = false;
    const valid = isInsideKarachi(la, lo);
    setError(valid ? "" : OUTSIDE_CITY_MESSAGE);
    if (!valid) { setLookupMessage(OUTSIDE_CITY_MESSAGE); return; }
    if (!online) {
      setAutofillMissing([...REQUIRED_ADDRESS_FIELDS]);
      setLookupMessage("You are offline. Autofill is unavailable; enter House Number, Block/Sector and Area manually.");
      return;
    }
    setLookupMessage("Detecting House Number, Block/Sector and Area…");
    debounce.current = setTimeout(() => { void lookup(la, lo); }, selection?.source === "gps" ? 0 : 650);
  }

  function handleSave() {
    setError("");
    const requiredErrors = requiredAddressErrors(fieldsRef.current);
    setFieldErrors(requiredErrors);
    const first = REQUIRED_ADDRESS_FIELDS.find((key) => requiredErrors[key]);
    if (first) {
      setError("House Number, Block/Sector and Area are all compulsory. Please enter manually.");
      inputRefs.current[first]?.focus();
      return;
    }
    if (showContact && !name.trim()) return setError("Enter your full name");
    if (showContact && !isValidPkMobile(phone)) return setError("Enter a valid Pakistani mobile number (03xx…)");
    if (!pinSelected) return setError("Select an Area suggestion, use your location, or drop a pin before saving.");
    if (!inside) return setError(OUTSIDE_CITY_MESSAGE);
    cancelLookup();
    const next: DeliveryFields = {
      houseNumber: addressText(fieldsRef.current.houseNumber), blockSector: addressText(fieldsRef.current.blockSector),
      area: addressText(fieldsRef.current.area), street: addressText(fieldsRef.current.street),
    };
    if (showContact) setProfile({
      name: name.trim(), phone: normalizePkPhone(phone),
      verified: Boolean(profile?.verified && normalizePkPhone(profile.phone) === normalizePkPhone(phone)),
    });
    saveAddress({
      ...next, label: label.trim() || "Home", details: formatAddressDetails(next),
      note: note.trim(), lat, lng, accuracyMeters: accuracy,
      mapAddress: suggestion?.details || undefined,
    });
    setSaved(true);
    toast({ kind: "success", title: "Delivery details saved", body: "House Number, Block/Sector and Area are ready." });
    onDone?.();
  }

  const body = (
    <div className="space-y-4 pb-1">
      {showContact && !account && (
        <div className="rounded-2xl border border-zx-yellow/50 bg-zx-yellow/10 p-3">
          {showLogin ? (
            <>
              <div className="mb-2 flex items-center justify-between">
                <p className="font-heading text-sm font-bold">Log in to your account</p>
                <button type="button" className="min-h-9 text-xs font-semibold underline" onClick={() => setShowLogin(false)}>Cancel</button>
              </div>
              <LoginForm onSuccess={(acc) => {
                setShowLogin(false);
                setName(acc.name); setPhone(displayPhone(acc.phone));
                if (acc.address) {
                  const restored = fieldsFromSavedAddress(acc.address);
                  updateFields(restored);
                  for (const key of FIELD_KEYS) manual.current[key] = Boolean(restored[key]);
                  setLat(acc.address.lat); setLng(acc.address.lng); setPinSelected(true);
                  setLabel(acc.address.label); setNote(acc.address.note);
                  if (hasRequiredAddressFields(restored)) onDone?.();
                  else setLookupMessage("Please complete the missing required fields in your saved address.");
                }
              }} />
            </>
          ) : (
            <p className="flex flex-wrap items-center justify-between gap-2 text-sm">
              <span>Already have an account?</span>
              <button type="button" className="zx-btn h-9 min-h-9 px-4 text-sm" onClick={() => setShowLogin(true)}>Log in</button>
            </p>
          )}
        </div>
      )}
      {showContact && (
        <section>
          <p className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-zx-muted"><Icon name="user" size={14} /> Contact details</p>
          <div className="grid gap-2 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs font-semibold text-zx-muted" htmlFor={`${id}-name`}>Full name</label>
              <input id={`${id}-name`} value={name} onChange={(e) => { setName(e.target.value); setError(""); }} placeholder="e.g. Ayesha Khan" autoComplete="name" className="zx-input" />
            </div>
            <div>
              <label className="mb-1 block text-xs font-semibold text-zx-muted" htmlFor={`${id}-phone`}>Mobile number</label>
              <input id={`${id}-phone`} value={phone} onChange={(e) => { setPhone(e.target.value); setError(""); }} placeholder="03xx xxxxxxx" inputMode="tel" autoComplete="tel" className="zx-input" />
            </div>
          </div>
        </section>
      )}

      <section>
        <KarachiMap lat={lat} lng={lng} areaLabel={fields.area} accuracy={accuracy} online={online} onChange={selectPin} onSelectArea={pickArea} />
        {!inside && <p className="mt-2 text-sm font-semibold text-zx-error">{OUTSIDE_CITY_MESSAGE}</p>}
        <p className="mt-1 text-[11px] text-zx-muted">Address lookup shares only pin coordinates with <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer" className="underline">OpenStreetMap</a>, not your contact details.</p>
      </section>

      <section aria-label="Required delivery address" data-testid="address-fields" className="rounded-2xl border border-zx-line/40 bg-zx-card p-3">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="font-heading text-sm font-bold">Delivery address</h2>
            <p className="text-[11px] text-zx-muted">All three fields are required.</p>
          </div>
          {pinSelected && inside && <button type="button" className="min-h-10 text-xs font-semibold underline" disabled={lookupBusy} onClick={() => void lookup(lat, lng, explicitlyChosenArea.current ? fields.area : undefined)}>{lookupBusy ? "Detecting…" : "Autofill from pin"}</button>}
        </div>
        {lookupMessage && <p role="status" className={`mb-3 rounded-xl px-3 py-2 text-xs leading-relaxed ${autofillMissing.length ? "bg-zx-yellow/15 text-zx-ink" : "bg-zx-yellow/15 text-zx-muted"}`}>{lookupMessage}</p>}
        <div className="grid gap-3 sm:grid-cols-2">
          {REQUIRED_ADDRESS_FIELDS.map((key) => {
            const missing = autofillMissing.includes(key);
            const empty = !addressText(fields[key]);
            const fieldError = fieldErrors[key] || (missing && empty ? `Autofill couldn’t detect ${ADDRESS_LABELS[key]}. Please enter it manually.` : "");
            const help = fieldError || (missing ? "Not found on the map; your entered value is kept." : suggestion && fields[key] && !manual.current[key] ? "Filled from map — please check." : "");
            return (
              <div key={key} className={key === "area" ? "sm:col-span-2" : "min-w-0"}>
                <label className="mb-1 block text-xs font-semibold text-zx-ink" htmlFor={`${id}-${key}`}>{ADDRESS_LABELS[key]} <span aria-hidden="true" className="text-zx-error">*</span></label>
                <input
                  ref={(node) => { inputRefs.current[key] = node; }}
                  id={`${id}-${key}`} aria-label={ADDRESS_LABELS[key]} required aria-required="true"
                  value={fields[key]} onChange={(e) => changeField(key, e.target.value)}
                  placeholder={PLACEHOLDERS[key]} maxLength={ADDRESS_LIMITS[key]}
                  aria-invalid={Boolean(fieldError)} aria-describedby={help ? `${id}-${key}-hint` : undefined}
                  autoComplete={key === "houseNumber" ? "address-line1" : key === "blockSector" ? "address-line2" : "address-level3"}
                  className="zx-input zx-address-input"
                />
                {help && <p id={`${id}-${key}-hint`} data-testid={`${key}-hint`} className={`mt-1 text-[11px] leading-relaxed ${fieldError ? "text-zx-error" : "text-zx-muted"}`}>{help}</p>}
                {key === "area" && matches.length > 0 && <div className="mt-2 flex flex-wrap gap-1.5">{matches.map((a) => (
                  <button key={a} type="button" className={`zx-chip ${fields.area === a ? "on" : ""}`} onClick={() => pickArea(a)}>{a}</button>
                ))}</div>}
              </div>
            );
          })}
        </div>
      </section>

      <div>
        <label className="mb-1 block text-xs font-semibold text-zx-muted" htmlFor={`${id}-street`}>Street / landmark (optional)</label>
        <input id={`${id}-street`} value={fields.street} onChange={(e) => changeField("street", e.target.value)} placeholder="Street name, number or landmark" maxLength={180} className="zx-input" />
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-xs font-semibold text-zx-muted" htmlFor={`${id}-label`}>Label</label>
          <input id={`${id}-label`} value={label} onChange={(e) => setLabel(e.target.value)} placeholder="Home / Office" maxLength={80} className="zx-input" />
        </div>
        <div>
          <label className="mb-1 block text-xs font-semibold text-zx-muted" htmlFor={`${id}-note`}>Delivery note</label>
          <input id={`${id}-note`} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Gate code, landmark" maxLength={500} className="zx-input" />
        </div>
      </div>
      {error && <p role="alert" className="rounded-xl bg-zx-error/10 px-3 py-2 text-sm font-semibold text-zx-error">{error}</p>}
      {saved && !error && <p role="status" className="rounded-xl bg-zx-success/10 px-3 py-2 text-sm font-semibold text-zx-success">All required address fields saved. Phone verification is required at checkout.</p>}
      <div className="flex flex-wrap gap-2">
        <button type="button" className="zx-btn min-w-0 flex-1" onClick={handleSave}><Icon name="check" size={18} /> {showContact ? "Save & continue" : "Save location"}</button>
        {onClose && <button type="button" className="zx-btn zx-btn-ghost" onClick={onClose}>{variant === "modal" ? "Browse first" : "Close"}</button>}
      </div>
      <p className="text-xs text-zx-muted">Karachi only · Cash on Delivery. Saved details are reused; you won’t be asked again while browsing.</p>
    </div>
  );

  if (variant !== "page") return body;
  return <div className="min-h-dvh bg-zx-bg"><PageHeader title="Set your delivery details" back="" onClose={() => onClose ? onClose() : history.back()} /><div className="mx-auto max-w-xl p-4">{body}</div></div>;
}

export function ContactSummary() {
  const { profile, address } = useStore();
  return <p className="text-sm"><b>{profile?.name || "Guest"}</b>{profile?.phone ? ` · ${formatPkPhone(profile.phone)}` : ""}<br />{address ? `${address.label} · ${address.area}` : "No address set"}</p>;
}
