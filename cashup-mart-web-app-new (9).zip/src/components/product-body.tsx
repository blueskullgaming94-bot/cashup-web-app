"use client";

import { Icon } from "@/components/Icon";
import { ProductGrid, QuantityStepper } from "@/components/catalog-ui";
import { useStore } from "@/components/store";
import { PageHeader, SmartImage, useToast } from "@/components/ui";
import { STORE } from "@/lib/config";
import { formatPkr, unitPrice } from "@/lib/money";
import { useParams, useRouter } from "next/navigation";
import { useMemo } from "react";

export function ProductBody() {
  const { slug } = useParams<{ slug: string }>();
  const router = useRouter();
  const toast = useToast();
  const { catalog, favorites, toggleFav, online } = useStore();
  const product = catalog.products.find((p) => p.slug === slug);
  const related = useMemo(
    () => (product ? catalog.products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 8) : []),
    [catalog.products, product],
  );

  if (!product) {
    return (
      <div>
        <PageHeader title="Item" back="" onClose={() => router.push("/")} />
        <p className="p-6 text-sm text-zx-muted">We could not find that item.</p>
      </div>
    );
  }

  const price = unitPrice(product.price, product.salePrice);
  const fav = favorites.includes(product.id);
  const off =
    product.salePrice && product.salePrice < product.price
      ? Math.round(((product.price - product.salePrice) / product.price) * 100)
      : 0;
  const category = catalog.categories.find((c) => c.slug === product.category);

  return (
    <div>
      <PageHeader
        title={product.name}
        back=""
        onClose={() => router.push(category ? `/categories/${category.slug}` : "/")}
        right={
          <button
            type="button"
            className="grid h-11 w-11 shrink-0 place-items-center rounded-full active:scale-95 transition-transform"
            onClick={() => {
              toggleFav(product.id);
              toast(
                fav
                  ? { kind: "info", title: "Removed from favorites" }
                  : { kind: "heart", title: "Saved to favorites", body: product.name },
              );
            }}
            aria-label={fav ? "Remove favourite" : "Save favourite"}
          >
            <Icon name="heart" className={fav ? "fill-zx-error stroke-zx-error" : ""} />
          </button>
        }
      />
      <div className="mx-auto grid max-w-5xl gap-6 px-4 py-4 md:grid-cols-[minmax(0,420px)_1fr] md:px-6">
        <div className="relative">
          <div className="zx-card overflow-hidden">
            <SmartImage src={product.image} alt={product.name} ratio="1 / 1" eager className="zx-pdp-media !rounded-[16px]" />
          </div>
          {off > 0 && (
            <span className="zx-pop absolute left-3 top-3 rounded-full bg-zx-yellow px-3 py-1 text-xs font-bold text-white">
              {off}% off
            </span>
          )}
        </div>

        <div className="zx-stagger space-y-3">
          <div style={{ ["--i" as string]: 0 }}>
            <p className="text-xs font-semibold uppercase tracking-wide text-zx-muted">
              {product.brand} · {product.unit}
            </p>
            <h1 className="font-heading mt-1 text-2xl font-bold md:text-3xl">{product.name}</h1>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="font-heading text-2xl font-bold md:text-3xl">{formatPkr(price)}</span>
              {off > 0 && <span className="text-zx-muted line-through">{formatPkr(product.price)}</span>}
            </div>
          </div>

          <p
            className={`flex items-center gap-2 text-sm font-semibold ${
              product.inStock ? "text-zx-success" : "text-zx-error"
            }`}
            style={{ ["--i" as string]: 1 }}
          >
            <Icon name={product.inStock ? "check" : "info"} size={16} />
            {product.inStock ? "In stock" : "Out of stock"}
            {!online && <span className="font-normal text-zx-muted">· last known value (offline)</span>}
          </p>

          <p className="text-sm leading-relaxed text-zx-muted" style={{ ["--i" as string]: 2 }}>
            {product.description}
          </p>

          <div className="zx-card flex flex-wrap gap-2 p-3 text-xs" style={{ ["--i" as string]: 3 }}>
            <Tag icon="delivery" text={`Delivery in ~${STORE.asapMinutes} min`} />
            <Tag icon="offers" text="Cash on Delivery only" />
            <Tag icon="location" text="Karachi only" />
            <Tag icon="categories" text={product.subcategory} />
          </div>

          <div className="mx-auto w-full max-w-xs md:mx-0" style={{ ["--i" as string]: 4 }}>
            {product.inStock ? (
              <QuantityStepper productId={product.id} />
            ) : (
              <div className="grid h-11 place-items-center rounded-xl bg-zx-bg text-sm font-semibold text-zx-muted">
                Currently unavailable
              </div>
            )}
          </div>

          {related.length > 0 && (
            <div className="pt-2" style={{ ["--i" as string]: 5 }}>
              <p className="font-heading mb-2 font-bold">More in {category?.name ?? "this category"}</p>
              <ProductGrid products={related.slice(0, 4)} cols={2} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Tag({ icon, text }: { icon: string; text: string }) {
  return (
    <span className="flex items-center gap-1.5 rounded-full bg-zx-bg px-3 py-1.5 font-medium text-zx-muted">
      <Icon name={icon} size={14} /> {text}
    </span>
  );
}
