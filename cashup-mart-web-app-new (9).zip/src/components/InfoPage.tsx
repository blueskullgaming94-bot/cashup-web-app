"use client";

import { STORE } from "@/lib/config";
import { useRouter } from "next/navigation";
import type { ReactNode } from "react";
import { PageHeader } from "./ui";

export function InfoPage({ title, children }: { title: string; children: ReactNode }) {
  const router = useRouter();
  return (
    <div>
      <PageHeader title={title} back="" onClose={() => router.push("/")} />
      <article className="zx-stagger mx-auto max-w-2xl space-y-3 p-4 text-sm leading-relaxed">
        {children}
      </article>
    </div>
  );
}

export function HelpBody() {
  const wa = `https://wa.me/${STORE.supportWhatsApp}`;
  return (
    <>
      <p className="text-zx-muted" style={{ ["--i" as string]: 0 }}>
        CashUp Express is a Karachi grocery mart. We deliver groceries, fresh produce, dairy, packaged and frozen items,
        household, personal care and similar essentials. We do not sell cooked or restaurant food.
      </p>
      <div className="grid gap-2 sm:grid-cols-2" style={{ ["--i" as string]: 1 }}>
        <a href={`tel:${STORE.supportPhone}`} className="zx-btn">
          Call {STORE.supportPhone}
        </a>
        <a href={wa} className="zx-btn zx-btn-dark">
          WhatsApp support
        </a>
      </div>
      <ul className="zx-card list-disc space-y-1.5 p-4 pl-9 text-zx-muted" style={{ ["--i" as string]: 2 }}>
        <li>
          Minimum order Rs. {STORE.minOrderPkr}. Delivery Rs. {STORE.deliveryFeePkr}, free over Rs.{" "}
          {STORE.freeDeliveryPkr}.
        </li>
        <li>Cash on Delivery only — keep exact change ready.</li>
        <li>You can cancel until packing starts.</li>
        <li>Offline: browse, search and fill your cart. Orders wait on the phone until you are back online.</li>
        <li>Deliveries are Karachi only for now.</li>
      </ul>
    </>
  );
}
