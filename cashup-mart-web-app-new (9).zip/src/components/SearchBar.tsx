"use client";

import { rankProducts, type RankedProduct } from "@/lib/search";
import { useStore } from "@/components/store";
import { Icon } from "@/components/Icon";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";

/**
 * The floating search bar: shown only on the pages where shoppers browse
 * products (home + categories). While typing it drops a small list of product
 * suggestions, tolerating mistyped keywords (e.g. "aple" → Apple).
 */
export function SearchBar({ floating }: { floating: boolean }) {
  const router = useRouter();
  const { catalog } = useStore();
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const boxRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const suggestions = useMemo<RankedProduct[]>(
    () => rankProducts(catalog.products, query, 6),
    [catalog.products, query],
  );
  const showList = open && query.trim().length >= 2;

  // Close on outside tap / focus leaving the control.
  useEffect(() => {
    if (!showList) return;
    const onDown = (event: PointerEvent) => {
      if (!boxRef.current?.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener("pointerdown", onDown, true);
    return () => document.removeEventListener("pointerdown", onDown, true);
  }, [showList]);

  useEffect(() => setActive(-1), [query]);

  function go(product: RankedProduct) {
    setOpen(false);
    setQuery("");
    inputRef.current?.blur();
    router.push(`/product/${product.product.slug}`);
  }

  function submit(event: React.FormEvent) {
    event.preventDefault();
    const term = query.trim();
    if (!term) return;
    if (active >= 0 && suggestions[active]) return go(suggestions[active]);
    setOpen(false);
    inputRef.current?.blur();
    router.push(`/search?q=${encodeURIComponent(term)}`);
  }

  return (
    <div ref={boxRef} className="relative">
      <div className="flex items-center">
        <Link
          href="/"
          aria-label="CashUp Express home"
          tabIndex={floating ? 0 : -1}
          aria-hidden={!floating}
          className={`shrink-0 overflow-hidden transition-all duration-300 ease-out ${
            floating ? "mr-2 w-11 opacity-100" : "mr-0 w-0 opacity-0"
          }`}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="https://imglink.cc/cdn/iidohuM4Z3.png"
            onError={(e) => {
              if (!e.currentTarget.src.endsWith("/cashup-logo.png")) {
                e.currentTarget.src = "/cashup-logo.png";
              }
            }}
            alt="CashUp"
            className="h-11 w-11 rounded-xl shadow-[0_8px_20px_rgba(26,31,44,0.25)] object-contain"
          />
        </Link>
        <form
          role="search"
          onSubmit={submit}
          className={`flex h-11 min-w-0 flex-1 items-center gap-2.5 rounded-full bg-zx-card px-3.5 text-zx-ink transition-shadow duration-200 ${
            floating ? "border border-zx-line/40 shadow-[0_8px_24px_rgba(26,31,44,0.18)]" : "shadow-inner"
          }`}
        >
          <Icon name="search" size={18} className="shrink-0 text-zx-muted" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
            onFocus={() => setOpen(true)}
            onKeyDown={(e) => {
              if (!showList || !suggestions.length) return;
              if (e.key === "ArrowDown") { e.preventDefault(); setActive((i) => (i + 1) % suggestions.length); }
              else if (e.key === "ArrowUp") { e.preventDefault(); setActive((i) => (i <= 0 ? suggestions.length - 1 : i - 1)); }
              else if (e.key === "Escape") { setOpen(false); setActive(-1); }
              else if (e.key === "Enter" && active >= 0) { e.preventDefault(); go(suggestions[active]); }
            }}
            placeholder="Search groceries & daily essentials..."
            className="w-full min-w-0 bg-transparent text-xs font-medium outline-none placeholder:text-[#5B6B8C] sm:text-sm"
            aria-label="Search products"
            role="combobox"
            aria-expanded={showList}
            aria-controls="zx-search-suggestions"
            aria-autocomplete="list"
            autoComplete="off"
          />
          {query ? (
            <button
              type="button"
              onClick={() => { setQuery(""); inputRef.current?.focus(); }}
              className="shrink-0 p-1 text-zx-muted"
              aria-label="Clear search"
            >
              <Icon name="close" size={14} />
            </button>
          ) : null}
        </form>
      </div>

      {showList && (
        <div
          id="zx-search-suggestions"
          role="listbox"
          aria-label="Product suggestions"
          className="zx-suggestions zx-fade"
        >
          {suggestions.length ? (
            <>
              {suggestions.map((item, index) => (
                <button
                  key={item.product.id}
                  type="button"
                  role="option"
                  aria-selected={index === active}
                  onMouseEnter={() => setActive(index)}
                  onClick={() => go(item)}
                  className={`flex w-full items-center gap-2.5 px-3 py-2 text-left transition-colors ${
                    index === active ? "bg-zx-yellow/25" : "bg-zx-card"
                  } ${index ? "border-t border-zx-line/40" : ""}`}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={item.product.image}
                    alt=""
                    className="h-9 w-9 shrink-0 rounded-lg bg-zx-bg object-cover"
                    loading="lazy"
                    decoding="async"
                  />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[13px] font-semibold leading-tight text-zx-ink">
                      {item.product.name}
                    </span>
                    <span className="block truncate text-[11px] text-zx-muted">
                      {item.product.unit} · {item.product.brand}
                    </span>
                  </span>
                  {!item.product.inStock && (
                    <span className="shrink-0 rounded-full bg-zx-bg px-2 py-0.5 text-[9px] font-bold text-zx-muted">
                      Out
                    </span>
                  )}
                  <Icon name="chevron-right" size={14} className="shrink-0 text-zx-muted" />
                </button>
              ))}
              <button
                type="button"
                onClick={() => {
                  setOpen(false);
                  router.push(`/search?q=${encodeURIComponent(query.trim())}`);
                }}
                className="flex w-full items-center justify-center gap-1 border-t border-zx-line/40 py-2 text-[11px] font-bold text-zx-muted"
              >
                See all results for “{query.trim()}”
              </button>
            </>
          ) : (
            <p className="px-3 py-3 text-[12px] text-zx-muted">
              No item matches “{query.trim()}”. Try a shorter word, or check the spelling.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
