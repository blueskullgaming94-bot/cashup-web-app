"use client";

/**
 * CashUp Express brand logo.
 * Bundled local file, so the logo appears immediately in the intro and works
 * offline, on static hosts, and inside the APK build.
 */
export const BRAND_LOGO_SRC = "/cashup-logo.png";

export function BrandLogo({ className = "h-8 w-8 rounded-lg", alt = "CashUp Express" }: { className?: string; alt?: string }) {
  // eslint-disable-next-line @next/next/no-img-element
  return (
    <img
      src={BRAND_LOGO_SRC}
      onError={(e) => {
        if (!e.currentTarget.src.endsWith("/cashup-logo.png")) {
          e.currentTarget.src = "/cashup-logo.png";
        }
      }}
      alt={alt}
      className={className}
      width={256}
      height={256}
    />
  );
}

/**
 * Animated logo for loading states: the tile bobs gently, an ice-blue ring
 * pulses around it, the floor shadow breathes, and red/blue speed dashes sweep
 * past. Pure CSS, respects prefers-reduced-motion via the global rule.
 */
export function AnimatedBrandLogo({ size = 168, label = "CashUp Express loading" }: { size?: number; label?: string }) {
  return (
    <div className="zx-brand-loader" style={{ width: size, height: size + 34 }} role="img" aria-label={label}>
      <div className="zx-brand-ring" aria-hidden />
      <div className="zx-brand-dashes" aria-hidden>
        <span />
        <span />
        <span />
      </div>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={BRAND_LOGO_SRC}
        onError={(e) => {
          if (!e.currentTarget.src.endsWith("/cashup-logo.png")) {
            e.currentTarget.src = "/cashup-logo.png";
          }
        }}
        alt=""
        className="zx-brand-tile"
        width={256}
        height={256}
        draggable={false}
      />
      <div className="zx-brand-shadow" aria-hidden />
    </div>
  );
}
