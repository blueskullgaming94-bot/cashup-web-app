"use client";

import { MIN_PASSWORD, type PublicAccount } from "@/lib/accounts";
import { imageFileToAvatar } from "@/lib/avatar";
import { useId, useRef, useState } from "react";
import { Icon } from "./Icon";
import { useStore } from "./store";
import { useToast } from "./ui";

/** Round profile photo that opens the phone's gallery / file picker. */
export function AvatarPicker({
  value,
  onChange,
  size = 88,
  name,
}: {
  value: string | null;
  onChange: (avatar: string | null) => void;
  size?: number;
  name?: string;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const initial = (name || "?").trim().charAt(0).toUpperCase() || "?";

  async function pick(file: File | undefined) {
    if (!file) return;
    setBusy(true);
    setError("");
    try {
      onChange(await imageFileToAvatar(file));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't use that photo.");
    } finally {
      setBusy(false);
      if (input.current) input.current.value = "";
    }
  }

  return (
    <div className="flex items-center gap-3">
      <button
        type="button"
        onClick={() => input.current?.click()}
        className="relative shrink-0 overflow-hidden rounded-full bg-zx-yellow text-white ring-4 ring-zx-yellow/30 transition-transform active:scale-95"
        style={{ width: size, height: size }}
        aria-label={value ? "Change profile photo" : "Add profile photo"}
      >
        {value ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={value} alt="Profile photo" className="h-full w-full object-cover" />
        ) : (
          <span className="font-heading grid h-full w-full place-items-center text-3xl font-bold">{initial}</span>
        )}
        <span className="absolute bottom-0 inset-x-0 bg-zx/75 py-0.5 text-center text-[10px] font-semibold text-white">
          {busy ? "…" : "Edit"}
        </span>
      </button>
      <div className="min-w-0 space-y-1">
        <button type="button" className="min-h-9 text-sm font-semibold underline" onClick={() => input.current?.click()} disabled={busy}>
          {busy ? "Processing photo…" : value ? "Change photo" : "Choose from gallery"}
        </button>
        {value && (
          <button type="button" className="block min-h-9 text-xs font-semibold text-zx-error" onClick={() => onChange(null)}>
            Remove photo
          </button>
        )}
        {error && <p role="alert" className="text-xs text-zx-error">{error}</p>}
      </div>
      <input ref={input} type="file" accept="image/*" className="hidden" onChange={(e) => void pick(e.target.files?.[0])} />
    </div>
  );
}

function PasswordInput({ id, label, value, onChange, autoComplete }: {
  id: string; label: string; value: string; onChange: (v: string) => void; autoComplete: string;
}) {
  const [show, setShow] = useState(false);
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-xs font-semibold text-zx-muted">{label}</label>
      <div className="relative">
        <input
          id={id}
          type={show ? "text" : "password"}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          autoComplete={autoComplete}
          className="zx-input bg-zx-bg pr-16"
        />
        <button
          type="button"
          onClick={() => setShow((v) => !v)}
          className="absolute right-2 top-1/2 min-h-9 -translate-y-1/2 px-2 text-xs font-semibold text-zx-muted"
          aria-label={show ? `Hide ${label.toLowerCase()}` : `Show ${label.toLowerCase()}`}
        >
          {show ? "Hide" : "Show"}
        </button>
      </div>
    </div>
  );
}

export function LoginForm({ onSuccess, onSwitch }: { onSuccess?: (account: PublicAccount) => void; onSwitch?: () => void }) {
  const { loginAccount } = useStore();
  const toast = useToast();
  const id = useId();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const result = await loginAccount(identifier, password);
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setPassword("");
    toast({ kind: "success", title: `Welcome back, ${result.account.name.split(" ")[0]}`, body: "Your saved details are ready." });
    onSuccess?.(result.account);
  }

  return (
    <form onSubmit={submit} className="space-y-3" aria-label="Log in">
      <div>
        <label htmlFor={`${id}-who`} className="mb-1 block text-xs font-semibold text-zx-muted">Mobile number or email</label>
        <input
          id={`${id}-who`}
          value={identifier}
          onChange={(e) => setIdentifier(e.target.value)}
          placeholder="03xx xxxxxxx or you@email.com"
          autoComplete="username"
          className="zx-input bg-zx-bg"
        />
      </div>
      <PasswordInput id={`${id}-pw`} label="Password" value={password} onChange={setPassword} autoComplete="current-password" />
      {error && <p role="alert" className="rounded-xl bg-zx-error/10 px-3 py-2 text-sm font-semibold text-zx-error">{error}</p>}
      <button type="submit" className="zx-btn w-full" disabled={busy}>
        <Icon name="user" size={18} /> {busy ? "Logging in…" : "Log in"}
      </button>
      {onSwitch && (
        <p className="text-center text-xs text-zx-muted">
          New here?{" "}
          <button type="button" onClick={onSwitch} className="min-h-9 font-semibold text-zx-ink underline">Create an account</button>
        </p>
      )}
    </form>
  );
}

export function RegisterForm({ onSuccess, onSwitch }: { onSuccess?: () => void; onSwitch?: () => void }) {
  const { registerAccount, profile } = useStore();
  const toast = useToast();
  const id = useId();
  const [avatar, setAvatar] = useState<string | null>(null);
  const [name, setName] = useState(profile?.name ?? "");
  const [phone, setPhone] = useState(profile?.phone ?? "");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (password !== confirm) {
      setError("Passwords don't match.");
      return;
    }
    setBusy(true);
    const result = await registerAccount({ name, phone, email, password, avatar });
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      return;
    }
    setPassword("");
    setConfirm("");
    toast({ kind: "success", title: "Account created", body: "You can log in on this device anytime." });
    onSuccess?.();
  }

  return (
    <form onSubmit={submit} className="space-y-3" aria-label="Create account">
      <AvatarPicker value={avatar} onChange={setAvatar} name={name} size={72} />
      <div className="grid gap-2 sm:grid-cols-2">
        <div>
          <label htmlFor={`${id}-name`} className="mb-1 block text-xs font-semibold text-zx-muted">Full name</label>
          <input id={`${id}-name`} value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" className="zx-input bg-zx-bg" />
        </div>
        <div>
          <label htmlFor={`${id}-phone`} className="mb-1 block text-xs font-semibold text-zx-muted">Mobile number</label>
          <input id={`${id}-phone`} value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" autoComplete="tel" placeholder="03xx xxxxxxx" className="zx-input bg-zx-bg" />
        </div>
      </div>
      <div>
        <label htmlFor={`${id}-email`} className="mb-1 block text-xs font-semibold text-zx-muted">Email <span className="font-normal">(optional)</span></label>
        <input id={`${id}-email`} type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" placeholder="you@email.com" className="zx-input bg-zx-bg" />
      </div>
      <div className="grid gap-2 sm:grid-cols-2">
        <PasswordInput id={`${id}-pw`} label="Password" value={password} onChange={setPassword} autoComplete="new-password" />
        <PasswordInput id={`${id}-pw2`} label="Confirm password" value={confirm} onChange={setConfirm} autoComplete="new-password" />
      </div>
      <p className="text-[11px] text-zx-muted">At least {MIN_PASSWORD} characters with a letter and a number.</p>
      {error && <p role="alert" className="rounded-xl bg-zx-error/10 px-3 py-2 text-sm font-semibold text-zx-error">{error}</p>}
      <button type="submit" className="zx-btn w-full" disabled={busy}>
        <Icon name="check" size={18} /> {busy ? "Creating account…" : "Create account"}
      </button>
      {onSwitch && (
        <p className="text-center text-xs text-zx-muted">
          Already have an account?{" "}
          <button type="button" onClick={onSwitch} className="min-h-9 font-semibold text-zx-ink underline">Log in</button>
        </p>
      )}
    </form>
  );
}

/** Tabbed log-in / create-account card. */
export function AuthPanel({ onSuccess, initial = "login" }: { onSuccess?: () => void; initial?: "login" | "register" }) {
  const [tab, setTab] = useState<"login" | "register">(initial);
  return (
    <div>
      <div role="tablist" className="mb-4 grid grid-cols-2 gap-1 rounded-full bg-zx-bg p-1">
        {(["login", "register"] as const).map((t) => (
          <button
            key={t}
            role="tab"
            type="button"
            aria-selected={tab === t}
            onClick={() => setTab(t)}
            className={`min-h-10 rounded-full text-sm font-semibold transition-colors ${tab === t ? "bg-zx-yellow text-white" : "text-zx-muted"}`}
          >
            {t === "login" ? "Log in" : "Create account"}
          </button>
        ))}
      </div>
      {tab === "login"
        ? <LoginForm onSuccess={onSuccess} onSwitch={() => setTab("register")} />
        : <RegisterForm onSuccess={onSuccess} onSwitch={() => setTab("login")} />}
    </div>
  );
}
