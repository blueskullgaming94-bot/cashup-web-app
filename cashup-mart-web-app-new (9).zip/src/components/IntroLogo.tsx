"use client";

import { useEffect, useRef, useState } from "react";
import { WordmarkIntro } from "./WordmarkIntro";

/** Exact logo requested for the loading intro. */
const REMOTE_LOGO_SRC = "https://imglink.cc/cdn/iidohuM4Z3.png";
/** Bundled fallbacks if the remote file is unreachable. */
const FALLBACK_LOGO_SRC = "/cashup-logo.png";
const LAST_RESORT_LOGO_SRC = "/icon.png";

// Version this key so the fixed logo intro replays once after deploy.
const SEEN_KEY = "cashup-intro-shown-v4";
/** Wordmark motion runs about 4.05s; hold + fade totals 4.75s. */
const HOLD_MS = 4300;
const FADE_MS = 450;

/**
 * Foodpanda-style launch splash: full-bleed brand colour, the CashUp logo on a
 * white tile, and the animated wordmark beneath it. Plays once per browser
 * session, is skipped instantly on later loads (via the inline script in
 * layout.tsx so there is no flash), and never blocks interaction.
 */
export function IntroLogo() {
  const [state, setState] = useState<"playing" | "closing" | "done">("playing");
  const [logoSrc, setLogoSrc] = useState(REMOTE_LOGO_SRC);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => {
    const root = document.documentElement;
    // layout.tsx marks the session as already introduced before first paint.
    if (root.dataset.intro === "off") {
      setState("done");
      return;
    }

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const hold = reduce ? 900 : HOLD_MS;

    timers.current.push(
      setTimeout(() => {
        setState("closing");
        try {
          sessionStorage.setItem(SEEN_KEY, "1");
        } catch {
          /* private mode: intro simply replays next launch */
        }
        root.dataset.intro = "off";
      }, hold),
    );
    timers.current.push(setTimeout(() => setState("done"), hold + FADE_MS));

    return () => timers.current.forEach(clearTimeout);
  }, []);

  if (state === "done") return null;

  return (
    <div
      className={`zx-intro ${state === "closing" ? "closing" : ""}`}
      role="dialog"
      aria-label="CashUp Express"
      aria-hidden={state === "closing"}
    >
      {/* Soft brand glow so the logo reads clearly on the flat colour */}
      <span className="zx-intro-glow" aria-hidden />

      <div className="zx-intro-stage">
        {/* Plain HTML image (not SVG <image>) so the logo always renders. */}
        <span className="zx-intro-logo-tile" aria-hidden={false}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={logoSrc}
            alt="CashUp Express logo"
            className="zx-intro-logo-img"
            width={256}
            height={256}
            draggable={false}
            fetchPriority="high"
            onError={() => {
              if (logoSrc === REMOTE_LOGO_SRC) setLogoSrc(FALLBACK_LOGO_SRC);
              else if (logoSrc === FALLBACK_LOGO_SRC) setLogoSrc(LAST_RESORT_LOGO_SRC);
            }}
          />
        </span>
        <WordmarkIntro className="zx-intro-wordmark" />
      </div>

      <span className="zx-intro-tagline" aria-hidden>
        Ghar ka Rashan, Dehleez Tak
      </span>
    </div>
  );
}
