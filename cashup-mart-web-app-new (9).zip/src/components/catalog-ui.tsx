"use client";

import { formatPkr, unitPrice } from "@/lib/money";
import { CATEGORY_ICON_SRC } from "@/data/category-icons";
import { CATEGORY_3D_DATA_URIS } from "@/data/category-3d-data";
import type { Banner, Product } from "@/lib/types";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { Icon } from "./Icon";
import { useStore } from "./store";
import { SkeletonCard, SmartImage, useToast } from "./ui";

export function QuantityStepper({ productId, compact = false }: { productId: string; compact?: boolean }) {
  const { cart, addToCart, setQty, productById } = useStore();
  const toast = useToast();
  const product = productById(productId);
  const qty = cart.find((c) => c.productId === productId)?.qty ?? 0;
  if (!product?.inStock) return null;

  if (qty === 0) {
    return (
      <button
        type="button"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          addToCart(productId, 1);
          toast({ kind: "cart", title: "Added to cart", body: product.name });
        }}
        className={`zx-btn w-full font-bold shadow-sm ${
          compact ? "h-8 min-h-8 text-xs rounded-xl px-2" : "h-9 min-h-9 text-xs sm:text-sm rounded-xl px-3"
        }`}
      >
        <Icon name="plus" size={14} /> Add
      </button>
    );
  }

  return (
    <div
      className={`zx-pop flex items-center justify-between rounded-xl bg-zx text-white ${
        compact ? "h-8 w-full" : "h-9 w-full"
      }`}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
      }}
    >
      <button
        type="button"
        className="grid h-full w-8 place-items-center active:scale-90 transition-transform"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setQty(productId, qty - 1);
          if (qty - 1 === 0) toast({ kind: "info", title: "Removed from cart", body: product.name });
        }}
        aria-label={`Decrease ${product.name}`}
      >
        <Icon name="minus" size={14} />
      </button>
      <span className="min-w-4 text-center text-xs sm:text-sm font-bold text-white">{qty}</span>
      <button
        type="button"
        className="grid h-full w-8 place-items-center active:scale-90 transition-transform"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setQty(productId, qty + 1);
        }}
        aria-label={`Increase ${product.name}`}
      >
        <Icon name="plus" size={14} />
      </button>
    </div>
  );
}

export function ProductCard({ product }: { product: Product }) {
  const { favorites, toggleFav } = useStore();
  const toast = useToast();
  const price = unitPrice(product.price, product.salePrice);
  const off =
    product.salePrice && product.salePrice < product.price
      ? Math.round(((product.price - product.salePrice) / product.price) * 100)
      : 0;
  const fav = favorites.includes(product.id);

  return (
    <article
      className={`zx-card relative flex h-full flex-col overflow-hidden bg-zx-card border border-zx-line/40 rounded-2xl shadow-sm hover:shadow-md transition-all ${
        product.inStock ? "" : "opacity-60"
      }`}
    >
      <Link href={`/product/${product.slug}`} className="flex flex-1 flex-col">
        {/* Responsive Image Container: 4/3 aspect ratio on all mobile cards */}
        <div className="relative w-full aspect-[4/3] bg-zx-bg overflow-hidden">
          <SmartImage
            src={product.image}
            alt={product.name}
            ratio="auto"
            className="w-full h-full object-cover"
          />
          {off > 0 && (
            <span className="absolute left-2 top-2 rounded-full bg-zx-yellow px-1.5 py-0.5 text-[9px] font-extrabold text-white shadow-sm">
              {off}% OFF
            </span>
          )}
          {!product.inStock && (
            <span className="absolute inset-x-2 bottom-2 rounded-full bg-zx/85 py-0.5 text-center text-[9px] font-bold text-white backdrop-blur-xs">
              Out of stock
            </span>
          )}
        </div>

        {/* Details area */}
        <div className="flex flex-1 flex-col p-2.5 sm:p-3">
          <h4 className="line-clamp-2 text-xs sm:text-sm font-bold text-zx-ink leading-tight min-h-[2.2rem]">
            {product.name}
          </h4>
          <p className="text-[10px] sm:text-xs text-zx-muted mt-0.5 truncate">{product.unit}</p>

          <div className="mt-auto pt-2 flex items-baseline gap-1.5 flex-wrap">
            <span className="font-heading text-xs sm:text-sm font-extrabold text-zx-ink">
              {formatPkr(price)}
            </span>
            {off > 0 && (
              <span className="text-[10px] text-zx-muted line-through">
                {formatPkr(product.price)}
              </span>
            )}
          </div>
        </div>
      </Link>

      {/* Favorite Heart Button */}
      <button
        type="button"
        className="absolute right-2 top-2 grid h-7 w-7 place-items-center rounded-full bg-zx-card/90 text-zx-ink shadow-sm transition-transform active:scale-90"
        onClick={() => {
          toggleFav(product.id);
          toast(
            fav
              ? { kind: "info", title: "Removed from favorites", body: product.name }
              : { kind: "heart", title: "Saved to favorites", body: product.name },
          );
        }}
        aria-label={fav ? "Remove favourite" : "Save favourite"}
      >
        <Icon name="heart" size={14} className={fav ? "fill-zx-error stroke-zx-error" : ""} />
      </button>

      {/* Bottom Cart Action button */}
      <div className="p-2 pt-0 sm:p-2.5 sm:pt-0">
        {product.inStock ? (
          <QuantityStepper productId={product.id} compact />
        ) : (
          <div className="grid h-8 place-items-center rounded-xl bg-zx-bg text-[10px] font-bold text-zx-muted">
            Unavailable
          </div>
        )}
      </div>
    </article>
  );
}

export function ProductRow({ title, products, href }: { title: string; products: Product[]; href?: string }) {
  if (!products.length) return null;
  return (
    <section className="mb-5 sm:mb-6">
      <div className="mb-2.5 flex items-center justify-between px-3 sm:px-4">
        <h2 className="font-heading text-sm sm:text-lg font-bold text-zx-ink">{title}</h2>
        {href && (
          <Link href={href} className="flex items-center gap-0.5 text-xs font-bold text-zx-ink hover:text-zx-yellow">
            See all <Icon name="chevron-right" size={14} />
          </Link>
        )}
      </div>
      <div className="no-scrollbar flex gap-2.5 overflow-x-auto px-3 sm:px-4 pb-2">
        {products.map((p) => (
          <div
            key={p.id}
            className="w-[140px] xs:w-[150px] sm:w-[165px] md:w-[180px] shrink-0 min-w-0"
          >
            <ProductCard product={p} />
          </div>
        ))}
      </div>
    </section>
  );
}

export function ProductGrid({ products, cols }: { products: Product[]; cols?: number }) {
  if (!products.length) {
    return (
      <p className="px-4 py-12 text-center text-xs sm:text-sm text-zx-muted">Nothing here yet. Try another filter.</p>
    );
  }

  if (cols) {
    return (
      <div
        className="grid gap-2.5 sm:gap-3.5 px-3 sm:px-4 pb-4"
        style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}
      >
        {products.map((p) => (
          <div key={p.id} className="min-w-0">
            <ProductCard product={p} />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 xs:grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2.5 sm:gap-3.5 px-3 sm:px-4 pb-4">
      {products.map((p) => (
        <div key={p.id} className="min-w-0">
          <ProductCard product={p} />
        </div>
      ))}
    </div>
  );
}

export function BannerCarousel({ banners }: { banners: Banner[] }) {
  const [i, setI] = useState(0);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (banners.length < 2) return;
    timer.current = setInterval(() => setI((n) => (n + 1) % banners.length), 5000);
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [banners.length]);

  if (!banners.length) return null;

  return (
    <div className="px-3 sm:px-4 mb-4">
      <div className="relative overflow-hidden rounded-2xl shadow-sm border border-zx-line/40">
        <div
          className="flex transition-transform duration-500 ease-out"
          style={{ transform: `translateX(-${i * 100}%)` }}
        >
          {banners.map((b) => (
            <Link key={b.id} href={b.href} className="relative block min-w-full">
              <div className="w-full aspect-[21/9] sm:aspect-[21/7] md:aspect-[24/7] min-h-[125px] max-h-[220px] sm:max-h-[260px] relative bg-zx overflow-hidden">
                <SmartImage
                  src={b.image}
                  alt={b.title}
                  ratio="auto"
                  className="w-full h-full object-cover"
                  eager
                />
                {/* Clean gradient overlay matching Foodpanda style */}
                <div className="absolute inset-0 bg-gradient-to-r from-zx/90 via-zx/40 to-transparent flex flex-col justify-end p-3.5 sm:p-5 pr-14 sm:pr-16 text-white">
                  <span className="inline-block rounded-full bg-zx-yellow text-white font-extrabold text-[9px] sm:text-[10px] px-2 py-0.5 w-max mb-1">
                    Special Offer
                  </span>
                  <p className="font-heading text-sm sm:text-lg md:text-xl font-extrabold leading-tight">
                    {b.title}
                  </p>
                  <p className="line-clamp-1 text-[11px] sm:text-xs text-white/80 mt-0.5">
                    {b.subtitle}
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Carousel Dots */}
        <div className="absolute bottom-2.5 right-3 flex gap-1.5 z-10">
          {banners.map((b, idx) => (
            <button
              key={b.id}
              type="button"
              className={`h-1.5 rounded-full transition-all duration-300 ${
                idx === i ? "w-4 bg-zx-yellow" : "w-1.5 bg-white/50"
              }`}
              onClick={() => setI(idx)}
              aria-label={`Banner ${idx + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

/**
 * Realistic 3D item artwork for each category.
 *
 * Source 1: inlined base64 WebP data URI (inside the JS bundle — renders on
 * ANY host with zero network requests; this is what made Vercel hosting
 * unreliable with fetched image paths).
 * Source 2: the same optimized WebP served from /public/images/cats as a
 * second fallback for offline service-worker caching.
 * There is intentionally no emoji or line-icon fallback — only the 3D art.
 */
export function CategoryIcon3D({
  slug,
  size = 56,
  className = "",
}: {
  slug: string;
  size?: number;
  className?: string;
}) {
  const [attempt, setAttempt] = useState(0); // 0 = inlined data URI, 1 = public file
  const dataUri = CATEGORY_3D_DATA_URIS[slug];
  const publicSrc = CATEGORY_ICON_SRC[slug];

  if (!dataUri && !publicSrc) return null;

  const src = attempt === 0 ? (dataUri ?? publicSrc) : publicSrc;
  if (!src) return null;

  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={src}
      alt=""
      width={size}
      height={size}
      loading="eager"
      decoding="async"
      draggable={false}
      onError={() => {
        if (attempt === 0 && publicSrc) setAttempt(1);
      }}
      className={`zx-cat3d ${className}`}
      style={{ width: size, height: size }}
    />
  );
}

/**
 * Homepage-only single-line category slider.
 * One horizontally scrollable row, left-aligned, with the 3D art + name per
 * category. The full grid remains on the /categories page.
 */
export function CategoryStrip({ categories }: { categories: { slug: string; name: string; icon: string }[] }) {
  return (
    <div className="no-scrollbar -mx-3 sm:-mx-4 flex items-stretch gap-2.5 overflow-x-auto px-3 sm:px-4 pb-1" role="list" aria-label="Categories">
      {categories.map((c) => (
        <Link
          key={c.slug}
          href={`/categories/${c.slug}`}
          role="listitem"
          className="w-[104px] xs:w-[116px] sm:w-[124px] shrink-0 flex flex-col items-center gap-1.5 group active:scale-95 transition-transform"
        >
          <div className="zx-cat3d-cell grid h-14 w-14 sm:h-[68px] sm:w-[68px] place-items-center rounded-2xl bg-gradient-to-b from-white to-zx-bg shadow-[0_5px_12px_rgba(26,31,44,0.12)] ring-1 ring-zx-line/30 transition-all group-hover:shadow-[0_9px_18px_rgba(26,31,44,0.18)] group-hover:ring-zx-yellow/50">
            <CategoryIcon3D slug={c.slug} size={44} />
          </div>
          <span className="line-clamp-2 text-center text-[10px] sm:text-[11px] font-bold text-zx-ink leading-tight min-h-[1.5rem]">
            {c.name}
          </span>
        </Link>
      ))}
    </div>
  );
}

export function CategoryGrid({ categories }: { categories: { slug: string; name: string; icon: string }[] }) {
  return (
    <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2 sm:gap-3 px-3 sm:px-4 mb-4">
      {categories.map((c) => (
        <Link
          key={c.slug}
          href={`/categories/${c.slug}`}
          className="flex min-w-0 flex-col items-center gap-1.5 group active:scale-95 transition-transform"
        >
          {/* 3D item art floats on a soft card, no boxy border like the reference */}
          <div className="zx-cat3d-cell grid h-16 w-16 sm:h-[74px] sm:w-[74px] place-items-center rounded-2xl bg-gradient-to-b from-white to-zx-bg shadow-[0_6px_14px_rgba(26,31,44,0.12)] ring-1 ring-zx-line/30 transition-all group-hover:shadow-[0_10px_20px_rgba(26,31,44,0.18)] group-hover:ring-zx-yellow/50">
            <CategoryIcon3D slug={c.slug} size={52} />
          </div>
          <span className="line-clamp-2 text-center text-[10px] sm:text-[11px] font-bold text-zx-ink leading-tight min-h-[1.5rem]">
            {c.name}
          </span>
        </Link>
      ))}
    </div>
  );
}

export function SkeletonGrid({ count = 6 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 sm:gap-3 px-3 sm:px-4">
      {Array.from({ length: count }).map((_, i) => (
        <SkeletonCard key={i} />
      ))}
    </div>
  );
}
