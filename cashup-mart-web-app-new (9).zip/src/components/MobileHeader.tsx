"use client";

import { useStore } from "@/components/store";
import { Icon } from "@/components/Icon";
import Link from "next/link";
import { SearchBar } from "./SearchBar";
import { ThemeToggle } from "./Theme";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";

/** Pages where shoppers browse products, so the search bar floats there. */
const SEARCH_PAGES = ["/", "/categories"];

export function MobileHeader() {
  const { address, setLocationModalOpen, favorites } = useStore();
  const pathname = usePathname();
  const withSearch = SEARCH_PAGES.some((path) =>
    path === "/" ? pathname === "/" : pathname.startsWith(path),
  );

  const [q, setQ] = useState("");
  const [floating, setFloating] = useState(false);
  const topRef = useRef<HTMLDivElement>(null);

  // The logo + search tray floats once the address row has scrolled out of view.
  useEffect(() => {
    const el = topRef.current;
    if (!withSearch || !el || typeof IntersectionObserver === "undefined") {
      setFloating(false);
      return;
    }
    const observer = new IntersectionObserver(([entry]) => setFloating(!entry.isIntersecting), { threshold: 0 });
    observer.observe(el);
    return () => observer.disconnect();
  }, [withSearch]);

  // Leaving a search page must not leave the tray floating.
  useEffect(() => { if (!withSearch) setFloating(false); }, [withSearch]);

  return (
    <>
      {/* Address & actions row (scrolls away normally, on every page) */}
      <div ref={topRef} className="flex items-center justify-between gap-2 bg-zx px-3.5 pb-1 pt-3 text-white md:hidden">
        <button
          type="button"
          onClick={() => setLocationModalOpen(true)}
          className="flex min-w-0 flex-1 items-center gap-2 text-left transition-opacity active:opacity-80"
          aria-label="Change delivery address"
        >
          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-zx-yellow text-white">
            <Icon name="location" size={18} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1 text-[11px] font-bold uppercase leading-none tracking-wider text-zx-line">
              <span>{address?.label || "Deliver To"}</span>
              <Icon name="chevron-right" size={12} className="opacity-80" />
            </div>
            <p className="mt-0.5 truncate text-xs font-semibold text-white">
              {address?.area || "Set delivery location in Karachi"}
            </p>
          </div>
        </button>

        <div className="flex shrink-0 items-center gap-1.5">
          <ThemeToggle className="bg-white/10 text-white" />
          <Link
            href="/favorites"
            className="relative grid h-9 w-9 place-items-center rounded-full bg-zx-card/10 text-white transition-transform active:scale-90"
            aria-label="Favorites"
          >
            <Icon name="heart" size={18} className={favorites.length > 0 ? "fill-zx-error stroke-zx-error" : ""} />
            {favorites.length > 0 && (
              <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-zx-yellow px-1 text-[9px] font-extrabold text-white">
                {favorites.length}
              </span>
            )}
          </Link>
          <Link href="/" className="shrink-0 transition-transform active:scale-95" aria-label="CashUp Express home">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="https://imglink.cc/cdn/iidohuM4Z3.png"
              onError={(e) => {
                if (!e.currentTarget.src.endsWith("/cashup-logo.png")) {
                  e.currentTarget.src = "/cashup-logo.png";
                }
              }}
              alt="CashUp Express"
              className="h-8 w-8 rounded-lg object-contain"
            />
          </Link>
        </div>
      </div>

      {/* Search row: only on product-listing pages. Curved purple tray when floating. */}
      {withSearch && (
        <div
          data-floating={floating ? "true" : "false"}
          className={`sticky top-0 z-40 bg-zx px-3.5 pb-3 pt-2 transition-[border-radius,box-shadow] duration-300 ease-out md:hidden ${
            floating ? "rounded-b-[28px] shadow-[0_12px_28px_rgba(26,31,44,0.38)]" : "rounded-b-none shadow-none"
          }`}
        >
          <SearchBar floating={floating} />
        </div>
      )}
    </>
  );
}
