"use client";

import { useStore } from "@/components/store";
import { Icon } from "@/components/Icon";
import Link from "next/link";
import { usePathname } from "next/navigation";

export function MobileNavBar({ onMenu }: { onMenu: () => void }) {
  const pathname = usePathname();
  const { cartCount } = useStore();

  const items = [
    { href: "/", label: "Home", icon: "home" },
    { href: "/categories", label: "Categories", icon: "categories" },
    { href: "/cart", label: "Cart", icon: "cart", isCenter: true },
    { href: "/orders", label: "Orders", icon: "orders" },
    { href: "#menu", label: "Menu", icon: "menu", isMenu: true },
  ] as const;

  return (
    <div className="fixed inset-x-0 bottom-0 z-50 md:hidden pointer-events-none px-3 pb-[calc(10px+env(safe-area-inset-bottom))]">
      <nav
        aria-label="Mobile Navigation"
        className="pointer-events-auto mx-auto max-w-md w-full h-16 bg-zx text-white rounded-2xl shadow-[0_12px_32px_rgba(26,31,44,0.4)] flex items-center justify-around px-1 relative border border-white/5"
      >
        {items.map((it) => {
          if ("isCenter" in it && it.isCenter) {
            const active = pathname.startsWith("/cart");
            return (
              <Link
                key={it.href}
                href={it.href}
                className="relative -top-5 flex flex-col items-center group active:scale-90 transition-transform"
                aria-label={`Cart, ${cartCount} items`}
              >
                <div
                  className={`h-14 w-14 rounded-full flex items-center justify-center shadow-lg border-4 border-white transition-colors ${
                    active ? "bg-zx-yellow text-white" : "bg-zx-yellow text-white"
                  }`}
                >
                  <Icon name="cart" size={24} />
                  {cartCount > 0 && (
                    <span className="absolute -top-1 -right-1 h-5 min-w-5 rounded-full bg-zx text-white border-2 border-white text-[10px] font-extrabold grid place-items-center px-1">
                      {cartCount}
                    </span>
                  )}
                </div>
                <span className="text-[10px] font-bold text-white mt-0.5 tracking-tight">Cart</span>
              </Link>
            );
          }

          if ("isMenu" in it && it.isMenu) {
            return (
              <button
                key={it.label}
                type="button"
                onClick={onMenu}
                className="flex flex-col items-center justify-center flex-1 h-full text-white/70 hover:text-white active:scale-95 transition-all gap-0.5"
                aria-label="Open menu"
              >
                <div className="h-7 w-7 grid place-items-center rounded-full">
                  <Icon name="menu" size={20} />
                </div>
                <span className="text-[10px] font-medium tracking-tight">Menu</span>
              </button>
            );
          }

          const active = it.href === "/" ? pathname === "/" : pathname.startsWith(it.href);

          return (
            <Link
              key={it.href}
              href={it.href}
              className={`flex flex-col items-center justify-center flex-1 h-full transition-all gap-0.5 active:scale-95 ${
                active ? "text-white font-bold" : "text-white/70 hover:text-white font-medium"
              }`}
            >
              <div
                className={`h-7 w-7 grid place-items-center rounded-full transition-colors ${
                  active ? "bg-zx-yellow" : ""
                }`}
              >
                <Icon name={it.icon} size={20} />
              </div>
              <span className="text-[10px] tracking-tight">{it.label}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
