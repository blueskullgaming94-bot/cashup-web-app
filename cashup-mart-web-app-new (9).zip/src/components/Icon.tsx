type IconProps = {
  name: string;
  className?: string;
  size?: number;
};

export function Icon({ name, className = "", size = 24 }: IconProps) {
  return (
    <svg
      className={`zx-icon ${className}`}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      aria-hidden
    >
      <use href={`/icons.svg#${name}`} />
    </svg>
  );
}
