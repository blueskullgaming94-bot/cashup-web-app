"use client";

/**
 * Four-second CashUp wordmark reveal (text layer only).
 * The logo mark itself is rendered as a plain HTML <img> in IntroLogo above
 * this SVG, because SVG <image> elements are unreliable across hosts.
 *
 * Motion: word fades/rises (1.2s from 0.9s), clip wipe left-to-right
 * (2.5s from 1.0s), red accent (0.55s from 3.1s), light sweep (2s from 2.05s,
 * finishing at 4.05s).
 */
export function WordmarkIntro({
  className = "",
  text = "CashUp",
  delay = 0,
}: {
  className?: string;
  text?: string;
  delay?: number;
}) {
  const start = (offset: number) => `${Math.round((delay + offset) * 100) / 100}s`;
  const width = 620;
  const center = 600;
  const half = width / 2;

  return (
    <svg
      className={className}
      viewBox="0 0 1200 400"
      role="img"
      aria-label={`${text} logo`}
      preserveAspectRatio="xMidYMid meet"
    >
      <defs>
        <linearGradient id="zx-intro-sweep" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#fff" stopOpacity="0" />
          <stop offset=".5" stopColor="#fff" stopOpacity=".95" />
          <stop offset="1" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
        <clipPath id="zx-intro-word-reveal">
          <rect x={center - half - 10} y="105" width="0" height="190">
            <animate
              attributeName="width"
              values={`0;${width + 20}`}
              keyTimes="0;1"
              dur="2.5s"
              begin={start(1.0)}
              fill="freeze"
              calcMode="spline"
              keySplines=".4 0 .2 1"
            />
          </rect>
        </clipPath>
      </defs>

      {/* Wordmark reveals left-to-right. */}
      <g opacity="0" transform="translate(0 14)">
        <animate
          attributeName="opacity"
          values="0;1"
          dur="1.2s"
          begin={start(0.9)}
          fill="freeze"
          calcMode="spline"
          keySplines=".16 1 .3 1"
        />
        <animateTransform
          attributeName="transform"
          type="translate"
          values="0 14;0 0"
          dur="1.2s"
          begin={start(0.9)}
          fill="freeze"
          calcMode="spline"
          keySplines=".16 1 .3 1"
        />
        <g clipPath="url(#zx-intro-word-reveal)">
          <text
            x={center}
            y="245"
            textAnchor="middle"
            textLength={width}
            lengthAdjust="spacingAndGlyphs"
            fontFamily="Poppins, Arial, Helvetica, sans-serif"
            fontSize="150"
            fontWeight="800"
            fill="#fff"
          >
            {text}
          </text>
        </g>
      </g>

      {/* Red brand accent appears after the word reveal, without a bounce. */}
      <circle cx={center + half + 16} cy="236" r="0" fill="#ff2448">
        <animate
          attributeName="r"
          values="0;10;8"
          keyTimes="0;.7;1"
          dur=".55s"
          begin={start(3.1)}
          fill="freeze"
          calcMode="spline"
          keySplines=".2 .7 .2 1;.2 .7 .2 1"
        />
        <animate attributeName="opacity" values="0;1" dur=".3s" begin={start(3.1)} fill="freeze" />
      </circle>

      {/* Restrained light sweep closes the sequence under the wordmark. */}
      <rect
        x={center - half - 40}
        y="285"
        width={width + 80}
        height="2"
        rx="1"
        fill="url(#zx-intro-sweep)"
        opacity="0"
      >
        <animate
          attributeName="opacity"
          values="0;1;0"
          keyTimes="0;.35;1"
          dur="2s"
          begin={start(2.05)}
          fill="freeze"
        />
        <animateTransform
          attributeName="transform"
          type="scale"
          values=".08 1;1 1"
          keyTimes="0;1"
          dur="1.8s"
          begin={start(2.05)}
          fill="freeze"
          additive="sum"
        />
      </rect>
    </svg>
  );
}
