"use client";

import { banners as bundledBanners, catalogUpdatedAt, categories as bundledCategories, products as bundledProducts } from "@/data/catalog";
import { fetchCatalog, fetchOrders, placeOrder } from "@/lib/api";
import { normalizeSavedAddress } from "@/lib/address-fields";
import { DELIVERY_PROMPT_KEY, deliveryDetailsComplete, readDeviceValue, shouldPromptForDelivery, writeDeviceValue, type DeliveryPromptReason } from "@/lib/delivery-state";
import { idbGet, idbGetCart, idbGetOrders, idbPutOrder, idbSaveCart, idbSet } from "@/lib/idb";
import {
  changePassword as changeStoredPassword, clearSession, getSessionAccount, loginAccount as loginStoredAccount,
  registerAccount as registerStoredAccount, updateAccount, type AccountResult, type PublicAccount,
} from "@/lib/accounts";
import type { Address, CartItem, CatalogPayload, CustomerProfile, Order, Product } from "@/lib/types";
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";

const bundledCatalog: CatalogPayload = {
  categories: bundledCategories, products: bundledProducts, banners: bundledBanners, updatedAt: catalogUpdatedAt,
};
export type RetryResult = { ok: true; order: Order } | { ok: false; error: string; offline: boolean };

type StoreValue = {
  catalog: CatalogPayload;
  lastUpdated: string | null;
  online: boolean;
  hydrated: boolean;
  refreshing: boolean;
  refreshOrders: (phone: string) => Promise<void>;
  locationModalOpen: boolean;
  setLocationModalOpen: (open: boolean) => void;
  /** Returns true when contact + delivery details are already complete. */
  promptForDelivery: (reason: DeliveryPromptReason) => boolean;
  needsRegistration: boolean;
  address: Address | null;
  setAddress: (a: Address) => void;
  savedAddresses: Address[];
  saveAddress: (a: Address) => void;
  /** Removes a saved address. The active (default) address cannot be removed here. */
  removeSavedAddress: (a: Address) => boolean;
  profile: CustomerProfile | null;
  setProfile: (p: CustomerProfile | null) => void;
  cart: CartItem[];
  cartCount: number;
  addToCart: (productId: string, qty?: number) => void;
  setQty: (productId: string, qty: number) => void;
  clearCart: () => void;
  favorites: string[];
  toggleFav: (productId: string) => void;
  orders: Order[];
  rememberOrder: (order: Order) => void;
  retryOrder: (id: string) => Promise<RetryResult>;
  productById: (id: string) => Product | undefined;
  recentSearches: string[];
  pushSearch: (q: string) => void;
  /** Device-local account (null when logged out). */
  account: PublicAccount | null;
  registerAccount: (input: { name: string; phone: string; email?: string; password: string; avatar?: string | null }) => Promise<AccountResult>;
  loginAccount: (identifier: string, password: string) => Promise<AccountResult>;
  logout: () => void;
  updateAccountProfile: (patch: { name?: string; phone?: string; email?: string; avatar?: string | null }) => AccountResult;
  changeAccountPassword: (current: string, next: string) => Promise<AccountResult>;
};

const StoreContext = createContext<StoreValue | null>(null);

// A broken/blocked IndexedDB must not indefinitely delay restoring contact data.
async function optionalRead<T>(read: () => Promise<T>, fallback: T): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    return await Promise.race([
      Promise.resolve().then(read).catch(() => fallback),
      new Promise<T>((resolve) => { timer = setTimeout(() => resolve(fallback), 1200); }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [catalog, setCatalog] = useState<CatalogPayload>(bundledCatalog);
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [online, setOnline] = useState(true);
  const [hydrated, setHydrated] = useState(false);
  const [address, setAddressState] = useState<Address | null>(null);
  const [savedAddresses, setSavedAddresses] = useState<Address[]>([]);
  const [profile, setProfileState] = useState<CustomerProfile | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [refreshing, setRefreshing] = useState(false);
  const [locationModalOpen, updateLocationModal] = useState(false);
  const [account, setAccount] = useState<PublicAccount | null>(null);
  const accountRef = useRef<PublicAccount | null>(null);
  accountRef.current = account;
  const syncing = useRef(false);
  const needsRegistration = !deliveryDetailsComplete(address, profile);

  const setLocationModalOpen = useCallback((open: boolean) => {
    // A close/dismiss must be remembered even across full navigations/reloads.
    writeDeviceValue(DELIVERY_PROMPT_KEY, true);
    updateLocationModal(open);
  }, []);

  const promptForDelivery = useCallback((reason: DeliveryPromptReason) => {
    if (!hydrated) return false;
    const seen = readDeviceValue(DELIVERY_PROMPT_KEY, false);
    const open = shouldPromptForDelivery(reason, !needsRegistration, seen);
    writeDeviceValue(DELIVERY_PROMPT_KEY, true);
    if (open) updateLocationModal(true);
    return !needsRegistration;
  }, [hydrated, needsRegistration]);

  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    setOnline(navigator.onLine);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    // Each key is read independently BEFORE the optional catalog database.
    const localAddress = normalizeSavedAddress(readDeviceValue<Address | null>("cashup-address", null));
    const localProfile = readDeviceValue<CustomerProfile | null>("cashup-profile", null);
    const localSaved = readDeviceValue<Address[]>("cashup-saved-addresses", []);
    const localCart = readDeviceValue<CartItem[] | null>("cashup-cart", null);
    setAddressState(localAddress);
    setProfileState(localProfile);
    setSavedAddresses(Array.isArray(localSaved) ? localSaved.map(normalizeSavedAddress).filter((a): a is Address => a !== null) : []);
    const fav = readDeviceValue<string[]>("cashup-favorites", []);
    const recent = readDeviceValue<string[]>("cashup-recent-searches", []);
    setFavorites(Array.isArray(fav) ? fav : []);
    setRecentSearches(Array.isArray(recent) ? recent : []);
    if (Array.isArray(localCart)) setCart(localCart);
    // Logged-in device account: restore its details if the device copy is missing.
    const session = getSessionAccount();
    setAccount(session);
    if (session && !localProfile) {
      const restored = { name: session.name, phone: session.phone, verified: session.verified };
      setProfileState(restored);
      writeDeviceValue("cashup-profile", restored);
    }
    if (session && !localAddress && session.address) {
      setAddressState(normalizeSavedAddress(session.address));
      writeDeviceValue("cashup-address", session.address);
      setSavedAddresses(session.savedAddresses ?? []);
    }

    void (async () => {
      const [cached, dbCart, localOrders, backupAddress, backupProfile] = await Promise.all([
        optionalRead(() => idbGet<CatalogPayload>("catalog"), undefined),
        optionalRead(() => idbGetCart(), []),
        optionalRead(() => idbGetOrders<Order>(), []),
        localAddress ? Promise.resolve(localAddress) : optionalRead(() => idbGet<Address>("delivery-address"), undefined),
        localProfile ? Promise.resolve(localProfile) : optionalRead(() => idbGet<CustomerProfile | null>("delivery-profile"), undefined),
      ]);
      if (cancelled) return;
      if (cached?.products?.length) {
        setCatalog(cached);
        setLastUpdated(cached.updatedAt);
      }
      if (!localAddress && !session?.address && backupAddress) setAddressState(normalizeSavedAddress(backupAddress));
      if (!localProfile && !session && backupProfile) setProfileState(backupProfile);
      if (!Array.isArray(localCart) && dbCart.length) setCart(dbCart);
      if (localOrders.length) setOrders(localOrders.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
      // Do not prompt until all available saved delivery data has been restored.
      setHydrated(true);
    })();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    let cancelled = false;
    setRefreshing(true);
    void fetchCatalog().then((data) => {
      if (cancelled || !data?.products?.length) return;
      setCatalog(data);
      setLastUpdated(data.updatedAt);
      void idbSet("catalog", data).catch(() => undefined);
    }).catch(() => undefined).finally(() => { if (!cancelled) setRefreshing(false); });
    return () => { cancelled = true; };
  }, [hydrated, online]);

  // Persist functional cart updates; rapid Add/Reorder calls cannot overwrite one another.
  useEffect(() => {
    if (!hydrated) return;
    writeDeviceValue("cashup-cart", cart);
    void idbSaveCart(cart).catch(() => undefined);
  }, [cart, hydrated]);

  const addToCart = useCallback((productId: string, qty = 1) => {
    const product = catalog.products.find((p) => p.id === productId);
    if (!product?.inStock || !product.active) return;
    const count = Math.max(1, Math.min(20, Math.floor(qty) || 1));
    setCart((prev) => {
      const found = prev.some((item) => item.productId === productId);
      return found
        ? prev.map((item) => item.productId === productId ? { ...item, qty: Math.min(20, item.qty + count) } : item)
        : [...prev, { productId, qty: count }];
    });
    // Adding an item is an explicit request, unlike simply switching pages.
    promptForDelivery("cart");
  }, [catalog.products, promptForDelivery]);

  const setQty = useCallback((productId: string, qty: number) => {
    const existing = cart.find((c) => c.productId === productId)?.qty ?? 0;
    setCart((prev) => qty <= 0
      ? prev.filter((item) => item.productId !== productId)
      : prev.map((item) => item.productId === productId ? { ...item, qty: Math.min(20, Math.floor(qty)) } : item));
    if (qty > existing) promptForDelivery("cart");
  }, [cart, promptForDelivery]);
  const clearCart = useCallback(() => setCart([]), []);

  /** Mirror changes into the logged-in device account (best effort). */
  const syncAccount = useCallback((patch: Parameters<typeof updateAccount>[1]) => {
    const current = accountRef.current;
    if (!current) return;
    const result = updateAccount(current.id, patch);
    if (result.ok) setAccount(result.account);
  }, []);

  const setAddress = useCallback((a: Address) => {
    setAddressState(a);
    writeDeviceValue("cashup-address", a);
    writeDeviceValue(DELIVERY_PROMPT_KEY, true);
    void idbSet("delivery-address", a).catch(() => undefined);
    syncAccount({ address: a });
  }, [syncAccount]);

  const saveAddress = useCallback((a: Address) => {
    setSavedAddresses((prev) => {
      const next = [a, ...prev.filter((x) => x.area !== a.area || x.details !== a.details)].slice(0, 8);
      writeDeviceValue("cashup-saved-addresses", next);
      syncAccount({ savedAddresses: next });
      return next;
    });
    setAddress(a);
  }, [setAddress, syncAccount]);

  const removeSavedAddress = useCallback((target: Address) => {
    const same = (x: Address) => x.area === target.area && x.details === target.details;
    // The default address is what orders are delivered to; it's changed, not deleted.
    if (address && same(address)) return false;
    const next = savedAddresses.filter((x) => !same(x));
    if (next.length === savedAddresses.length) return false;
    setSavedAddresses(next);
    writeDeviceValue("cashup-saved-addresses", next);
    syncAccount({ savedAddresses: next });
    return true;
  }, [address, savedAddresses, syncAccount]);

  const setProfile = useCallback((p: CustomerProfile | null) => {
    setProfileState(p);
    writeDeviceValue("cashup-profile", p);
    void idbSet("delivery-profile", p).catch(() => undefined);
    if (p) syncAccount({ name: p.name, phone: p.phone, verified: p.verified });
  }, [syncAccount]);

  /** Load an account's details into the active app state. */
  const applyAccount = useCallback((acc: PublicAccount) => {
    setAccount(acc);
    const restored: CustomerProfile = { name: acc.name, phone: acc.phone, verified: acc.verified };
    setProfileState(restored);
    writeDeviceValue("cashup-profile", restored);
    void idbSet("delivery-profile", restored).catch(() => undefined);
    if (acc.address) {
      setAddressState(normalizeSavedAddress(acc.address));
      writeDeviceValue("cashup-address", acc.address);
      void idbSet("delivery-address", acc.address).catch(() => undefined);
      setSavedAddresses((acc.savedAddresses ?? []).map(normalizeSavedAddress).filter((a): a is Address => a !== null));
      writeDeviceValue("cashup-saved-addresses", acc.savedAddresses ?? []);
    }
    writeDeviceValue(DELIVERY_PROMPT_KEY, true);
  }, []);

  const registerAccount = useCallback(async (input: { name: string; phone: string; email?: string; password: string; avatar?: string | null }) => {
    const result = await registerStoredAccount({
      ...input,
      verified: Boolean(profile?.verified && profile.phone === input.phone),
      address, savedAddresses,
    });
    if (result.ok) applyAccount(result.account);
    return result;
  }, [address, savedAddresses, profile, applyAccount]);

  const loginAccount = useCallback(async (identifier: string, password: string) => {
    const result = await loginStoredAccount(identifier, password);
    if (!result.ok) return result;
    // Keep an address typed on this device if the account doesn't have one yet.
    if (!result.account.address && address) {
      const merged = updateAccount(result.account.id, { address, savedAddresses });
      applyAccount(merged.ok ? merged.account : result.account);
      return merged.ok ? merged : result;
    }
    applyAccount(result.account);
    return result;
  }, [address, savedAddresses, applyAccount]);

  const logout = useCallback(() => {
    clearSession();
    setAccount(null);
    setProfileState(null);
    setAddressState(null);
    setSavedAddresses([]);
    writeDeviceValue("cashup-profile", null);
    writeDeviceValue("cashup-address", null);
    writeDeviceValue("cashup-saved-addresses", []);
    void idbSet("delivery-profile", null).catch(() => undefined);
    void idbSet("delivery-address", null).catch(() => undefined);
  }, []);

  const updateAccountProfile = useCallback((patch: { name?: string; phone?: string; email?: string; avatar?: string | null }) => {
    const current = accountRef.current;
    if (!current) return { ok: false as const, error: "Please log in first." };
    const result = updateAccount(current.id, patch);
    if (result.ok) {
      setAccount(result.account);
      const next: CustomerProfile = {
        name: result.account.name, phone: result.account.phone,
        verified: result.account.phone === current.phone ? result.account.verified : false,
      };
      setProfileState(next);
      writeDeviceValue("cashup-profile", next);
    }
    return result;
  }, []);

  const changeAccountPassword = useCallback(async (current: string, next: string) => {
    const acc = accountRef.current;
    if (!acc) return { ok: false as const, error: "Please log in first." };
    return changeStoredPassword(acc.id, current, next);
  }, []);

  const toggleFav = useCallback((productId: string) => {
    setFavorites((prev) => {
      const next = prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId];
      writeDeviceValue("cashup-favorites", next);
      return next;
    });
  }, []);

  const rememberOrder = useCallback((order: Order) => {
    setOrders((prev) => [order, ...prev.filter((o) => o.id !== order.id)]);
    void idbPutOrder(order).catch(() => undefined);
  }, []);

  const sendOrder = useCallback(async (order: Order): Promise<RetryResult> => {
    const res = await placeOrder({
      name: order.customerName, phone: order.phone, address: order.address,
      items: order.items.map((i) => ({ productId: i.productId, qty: i.qty })),
      promoCode: order.promoCode, deliverySlot: order.deliverySlot, note: order.note,
    });
    if (!res.ok) {
      const reason: "offline" | "server" = res.offline ? "offline" : "server";
      rememberOrder({ ...order, pendingSync: true, pendingReason: reason });
      return { ok: false, error: res.error, offline: res.offline };
    }
    const confirmed: Order = { ...res.data.order, pendingSync: false, pendingReason: undefined };
    await idbPutOrder(confirmed);
    setOrders((prev) => {
      const next = prev.filter((o) => o.id !== order.id && o.id !== confirmed.id);
      return [confirmed, ...next].sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    });
    return { ok: true, order: confirmed };
  }, [rememberOrder]);

  const retryOrder = useCallback(async (id: string): Promise<RetryResult> => {
    try {
      const local = await idbGetOrders<Order>();
      const order = local.find((o) => o.id === id);
      if (!order) return { ok: false, error: "This order is not saved on this device", offline: false };
      return await sendOrder(order);
    } catch {
      return { ok: false, error: "Could not send the saved order. Please try again.", offline: !navigator.onLine };
    }
  }, [sendOrder]);

  useEffect(() => {
    if (!online || !hydrated || syncing.current) return;
    syncing.current = true;
    void idbGetOrders<Order>().then(async (local) => {
      for (const order of local.filter((o) => o.pendingSync)) await sendOrder(order);
    }).catch(() => undefined).finally(() => { syncing.current = false; });
  }, [online, hydrated, sendOrder]);

  const productById = useCallback((id: string) => catalog.products.find((p) => p.id === id), [catalog.products]);
  const pushSearch = useCallback((q: string) => {
    const term = q.trim();
    if (!term) return;
    setRecentSearches((prev) => {
      const next = [term, ...prev.filter((x) => x.toLowerCase() !== term.toLowerCase())].slice(0, 8);
      writeDeviceValue("cashup-recent-searches", next);
      return next;
    });
  }, []);

  const cartCount = useMemo(() => cart.reduce((n, i) => n + i.qty, 0), [cart]);
  const refreshOrders = useCallback(async (phone: string) => {
    if (!phone || !navigator.onLine) return;
    const list = await fetchOrders(phone);
    if (!list?.length) return;
    for (const o of list) void idbPutOrder(o).catch(() => undefined);
    setOrders((prev) => {
      const byId = new Map(prev.map((o) => [o.id, o]));
      for (const o of list) byId.set(o.id, { ...o, pendingSync: false });
      return Array.from(byId.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    });
  }, []);

  const value = useMemo<StoreValue>(() => ({
    catalog, lastUpdated, online, hydrated, refreshing, refreshOrders,
    locationModalOpen, setLocationModalOpen, promptForDelivery, needsRegistration,
    address, setAddress, savedAddresses, saveAddress, removeSavedAddress, profile, setProfile,
    cart, cartCount, addToCart, setQty, clearCart, favorites, toggleFav,
    orders, rememberOrder, retryOrder, productById, recentSearches, pushSearch,
    account, registerAccount, loginAccount, logout, updateAccountProfile, changeAccountPassword,
  }), [
    catalog, lastUpdated, online, hydrated, refreshing, refreshOrders,
    locationModalOpen, setLocationModalOpen, promptForDelivery, needsRegistration,
    address, setAddress, savedAddresses, saveAddress, removeSavedAddress, profile, setProfile,
    cart, cartCount, addToCart, setQty, clearCart, favorites, toggleFav,
    orders, rememberOrder, retryOrder, productById, recentSearches, pushSearch,
    account, registerAccount, loginAccount, logout, updateAccountProfile, changeAccountPassword,
  ]);

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}
