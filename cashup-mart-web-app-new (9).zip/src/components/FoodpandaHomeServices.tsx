"use client";

import Link from "next/link";
import { Icon } from "./Icon";

export function FoodpandaHomeServices() {
  const quickCategories = [
    {
      title: "Grocery",
      subtitle: "Daily Rashan",
      badge: "Express",
      href: "/categories/staples",
      icon: "cat-staples",
    },
    {
      title: "Fresh Farm",
      subtitle: "Fruits & Veg",
      badge: "Daily Fresh",
      href: "/categories/fruits-vegetables",
      icon: "cat-fruits-veg",
    },
    {
      title: "Dairy & Eggs",
      subtitle: "Milk, Butter",
      badge: "Morning Essentials",
      href: "/categories/dairy-eggs",
      icon: "cat-dairy-eggs",
    },
    {
      title: "Meat & Fish",
      subtitle: "Raw & Frozen",
      badge: "100% Halal",
      href: "/categories/meat-frozen",
      icon: "cat-meat-frozen",
    },
  ];

  return (
    <section className="px-3 sm:px-4 mb-4">
      {/* 2x2 Feature Service Cards (Foodpanda Mart Style) */}
      <div className="grid grid-cols-2 gap-2.5 sm:gap-3.5">
        {quickCategories.map((svc) => (
          <Link
            key={svc.title}
            href={svc.href}
            className="group relative flex flex-col justify-between overflow-hidden rounded-2xl bg-zx-card p-3.5 sm:p-4 shadow-sm border border-zx-line/40 hover:border-zx-yellow transition-all hover:shadow-md active:scale-[0.98]"
          >
            {/* Top row: title & tag */}
            <div>
              <span className="inline-block rounded-full bg-zx-yellow/30 px-2 py-0.5 text-[10px] font-bold text-zx-ink mb-1.5">
                {svc.badge}
              </span>
              <h3 className="font-heading text-sm sm:text-base font-bold text-zx-ink leading-tight group-hover:text-zx-yellow transition-colors">
                {svc.title}
              </h3>
              <p className="text-[11px] text-zx-muted mt-0.5">{svc.subtitle}</p>
            </div>

            {/* Bottom row: Icon card decoration */}
            <div className="mt-3 flex items-center justify-between">
              <span className="text-[11px] font-bold text-zx-ink flex items-center gap-0.5 group-hover:translate-x-0.5 transition-transform">
                Order <Icon name="chevron-right" size={13} />
              </span>
              <div className="grid h-9 w-9 sm:h-10 sm:w-10 place-items-center rounded-xl bg-zx-yellow text-white shadow-sm group-hover:scale-105 transition-transform">
                <Icon name={svc.icon} size={20} />
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
