"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { Icon } from "./Icon";

type CodeNotice = { id: number; code: string; leaving: boolean };
type CodeNoticeApi = { show: (code: string) => void; sent: () => void; hide: () => void };
const Context = createContext<CodeNoticeApi | null>(null);

async function copyCode(code: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(code);
    return true;
  } catch {
    const previous = document.activeElement as HTMLElement | null;
    const text = document.createElement("textarea");
    text.value = code;
    text.readOnly = true;
    text.style.cssText = "position:fixed;left:0;top:0;opacity:0;pointer-events:none";
    document.body.appendChild(text);
    try { text.select(); return document.execCommand("copy"); }
    catch { return false; }
    finally { text.remove(); previous?.focus({ preventScroll: true }); }
  }
}

function CodeCard({ notice, onClose }: { notice: CodeNotice; onClose: () => void }) {
  const [copied, setCopied] = useState<"idle" | "done" | "failed">("idle");
  const start = useRef<{ x: number; y: number } | null>(null);
  const [drag, setDrag] = useState(0);
  const [compact, setCompact] = useState(true);
  useEffect(() => { setCopied("idle"); setDrag(0); }, [notice.id]);
  useEffect(() => {
    if (copied === "idle") return;
    const timer = setTimeout(() => setCopied("idle"), 2400);
    return () => clearTimeout(timer);
  }, [copied]);
  // Phones show the top banner (swipe up to dismiss); desktops show the
  // bottom-right panel (swipe right to dismiss).
  useEffect(() => {
    const query = window.matchMedia("(min-width: 768px)");
    const apply = () => setCompact(!query.matches);
    apply();
    query.addEventListener("change", apply);
    return () => query.removeEventListener("change", apply);
  }, []);
  const dismissAt = compact ? -40 : 55;
  const moved = compact ? drag < dismissAt : drag > dismissAt;
  return (
    <div className={`zx-code-notice-wrap ${notice.leaving ? "out" : ""}`}>
      <section
        role="alert" aria-label="Verification code notification" className="zx-code-notice"
        style={{
          touchAction: compact ? "pan-x" : "pan-y",
          transform: drag ? (compact ? `translateY(${drag}px)` : `translateX(${drag}px)`) : undefined,
          transition: drag ? "none" : undefined,
        }}
        onPointerDown={(event) => {
          if ((event.target as HTMLElement).closest("button")) return;
          start.current = { x: event.clientX, y: event.clientY };
        }}
        onPointerMove={(event) => {
          if (start.current === null) return;
          setDrag(compact ? Math.min(0, event.clientY - start.current.y) : Math.max(0, event.clientX - start.current.x));
        }}
        onPointerUp={() => { if (moved) onClose(); start.current = null; setDrag(0); }}
        onPointerCancel={() => { start.current = null; setDrag(0); }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="https://imglink.cc/cdn/iidohuM4Z3.png"
          onError={(e) => {
            if (!e.currentTarget.src.endsWith("/cashup-logo.png")) {
              e.currentTarget.src = "/cashup-logo.png";
            }
          }}
          alt=""
          className="zx-code-logo object-contain"
        />
        <div className="zx-code-content">
          <div className="zx-code-caption"><span>CashUp Express</span><span>now</span></div>
          <p className="zx-code-label">Your verification code</p>
          <p className="zx-code-digits" data-testid="code-notice-value">{notice.code}</p>
          <p className="zx-code-explanation">Enter this code at checkout to verify your phone. Keep it private.</p>
        </div>
        <div className="zx-code-actions">
          <button type="button" className="zx-code-copy" onClick={async () => setCopied(await copyCode(notice.code) ? "done" : "failed")} aria-live="polite">
            <Icon name={copied === "done" ? "check" : "orders"} size={16} />{copied === "done" ? "Copied" : copied === "failed" ? "Retry copy" : "Copy"}
          </button>
          <button type="button" className="zx-code-dismiss" onClick={onClose} aria-label="Dismiss notification">Dismiss</button>
        </div>
      </section>
    </div>
  );
}

export function CodeNoticeProvider({ children }: { children: ReactNode }) {
  const [notice, setNotice] = useState<CodeNotice | null>(null);
  const [confirmation, setConfirmation] = useState<number | null>(null);
  const id = useRef(0);
  const timers = useRef<{ hide?: ReturnType<typeof setTimeout>; remove?: ReturnType<typeof setTimeout>; sent?: ReturnType<typeof setTimeout> }>({});

  const clearCardTimers = useCallback(() => {
    if (timers.current.hide) clearTimeout(timers.current.hide);
    if (timers.current.remove) clearTimeout(timers.current.remove);
  }, []);
  const hide = useCallback(() => {
    clearCardTimers();
    if (timers.current.sent) clearTimeout(timers.current.sent);
    setConfirmation(null);
    setNotice((current) => current ? { ...current, leaving: true } : null);
    timers.current.remove = setTimeout(() => setNotice(null), 230);
  }, [clearCardTimers]);
  const sent = useCallback(() => {
    if (timers.current.sent) clearTimeout(timers.current.sent);
    setConfirmation(++id.current);
    timers.current.sent = setTimeout(() => setConfirmation(null), 2400);
  }, []);
  const show = useCallback((code: string) => {
    if (!/^\d{6}$/.test(code)) return;
    clearCardTimers();
    setNotice({ id: ++id.current, code, leaving: false });
    timers.current.hide = setTimeout(hide, 45000);
  }, [clearCardTimers, hide]);
  useEffect(() => () => {
    clearCardTimers();
    if (timers.current.sent) clearTimeout(timers.current.sent);
  }, [clearCardTimers]);

  const value = useMemo(() => ({ show, sent, hide }), [show, sent, hide]);
  return (
    <Context.Provider value={value}>
      {children}
      {confirmation !== null && (
        <div key={confirmation} className="zx-code-sent" role="status" aria-live="polite" aria-label="Code sent confirmation" data-testid="code-sent-confirmation">
          <div className="zx-code-sent-pill">
            <svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true"><circle cx="12" cy="12" r="10" fill="#E52424" /><path d="m7 12 3.2 3.2L17 8.5" fill="none" stroke="#FFFFFF" strokeWidth="2.3" strokeLinecap="round" strokeLinejoin="round" /></svg>
            <span>Code Sent!</span>
          </div>
        </div>
      )}
      {notice && <CodeCard notice={notice} onClose={hide} />}
    </Context.Provider>
  );
}
const noop: CodeNoticeApi = { show: () => undefined, sent: () => undefined, hide: () => undefined };
export function useCodeNotice() { return useContext(Context) ?? noop; }
