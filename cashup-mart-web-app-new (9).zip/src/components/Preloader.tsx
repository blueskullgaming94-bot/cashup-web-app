"use client";

import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { AnimatedBrandLogo } from "./BrandLogo";

/**
 * Global logo preloader.
 * - Instant yellow top progress bar on every navigation (so something always happens).
 * - Full-screen purple logo loader for page switches / slow actions: shows after 90ms,
 *   stays at least 320ms, force-hides at 15s with a Retry error state.
 * - Never blocks cached/offline pages.
 */
export function Preloader() {
  const pathname = usePathname();
  const [stuck, setStuck] = useState(false);
  const api = useRef<{ show: () => void; hide: () => void; wrap: <T>(p: Promise<T>) => Promise<T> } | null>(null);
  const first = useRef(true);

  useEffect(() => {
    const el = document.getElementById("zx-loader");
    const bar = document.getElementById("zx-progress");
    const DELAY = 90;
    const MIN = 320;
    const MAX = 15000;
    let count = 0;
    let shownAt = 0;
    let delayT: ReturnType<typeof setTimeout> | null = null;
    let maxT: ReturnType<typeof setTimeout> | null = null;
    let barT: ReturnType<typeof setTimeout> | null = null;

    const clearBar = () => {
      if (!bar) return;
      bar.style.width = "100%";
      if (barT) clearTimeout(barT);
      barT = setTimeout(() => {
        bar.classList.remove("on");
        bar.style.width = "0";
      }, 260);
    };

    const reset = () => {
      count = 0;
      if (maxT) clearTimeout(maxT);
      maxT = null;
      el?.classList.remove("on");
      setStuck(false);
      clearBar();
    };

    const show = (isExplicitAction = false) => {
      if (typeof navigator !== "undefined" && !navigator.onLine) return;
      if (bar) {
        bar.classList.add("on");
        bar.style.width = "72%";
      }
      // Only show the heavy full-screen purple loader for explicit actions (like OTP/checkout)
      // or if explicitly requested. Regular page navigations only show the top gold progress bar.
      if (!isExplicitAction) return;

      count++;
      if (count > 1 || delayT || el?.classList.contains("on")) return;
      delayT = setTimeout(() => {
        delayT = null;
        shownAt = Date.now();
        el?.classList.add("on");
        maxT = setTimeout(() => {
          el?.classList.remove("on");
          setStuck(true);
        }, MAX);
      }, DELAY);
    };

    const hide = () => {
      // Clean up top bar first
      clearBar();
      count = Math.max(0, count - 1);
      if (count > 0) return;
      if (delayT) {
        clearTimeout(delayT);
        delayT = null;
        return;
      }
      const wait = Math.max(0, MIN - (Date.now() - shownAt));
      setTimeout(reset, wait);
    };

    const wrap = async <T,>(p: Promise<T>) => {
      // Actions wrapped in CashUpLoader.wrap are explicit actions, so pass true
      show(true);
      try {
        return await p;
      } finally {
        hide();
      }
    };

    api.current = { 
      show: () => show(true), // external calls to show are explicit
      hide, 
      wrap 
    };
    (window as unknown as { CashUpLoader: typeof api.current }).CashUpLoader = api.current;

    // Show top progress bar instantly when a link is tapped, so navigation never looks frozen.
    const onPointerDown = (e: PointerEvent) => {
      const a = (e.target as HTMLElement | null)?.closest?.("a[href]");
      if (!a) return;
      const href = a.getAttribute("href") || "";
      // Ignore hashes, external links, asset links, target="_blank", or download links
      if (
        !href.startsWith("/") ||
        href.includes("#") ||
        href.includes(".") ||
        a.getAttribute("target") === "_blank" ||
        a.hasAttribute("download")
      ) return;
      if (href === pathname || href === `${pathname}/` || `${href}/` === pathname) return;
      if (typeof navigator !== "undefined" && !navigator.onLine) return;
      
      // Just show the gold top progress bar for navigation
      show(false);
    };
    document.addEventListener("pointerdown", onPointerDown, true);
    return () => {
      document.removeEventListener("pointerdown", onPointerDown, true);
      if (delayT) clearTimeout(delayT);
      if (maxT) clearTimeout(maxT);
      if (barT) clearTimeout(barT);
    };
  }, [pathname]);

  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    api.current?.hide();
  }, [pathname]);

  return (
    <>
      <div id="zx-progress" aria-hidden />
      <div id="zx-loader" role="status" aria-live="polite" aria-label="Loading your groceries">
        <AnimatedBrandLogo />
        <p>Loading your groceries...</p>
      </div>
      {stuck && (
        <div className="fixed inset-0 z-[10002] flex flex-col items-center justify-center gap-3 bg-zx px-6 text-center">
          <svg viewBox="0 0 120 120" className="h-24 w-24" aria-hidden>
            <circle cx="60" cy="60" r="46" fill="none" stroke="#E52424" strokeWidth="3" opacity="0.25" />
            <circle
              cx="60"
              cy="60"
              r="46"
              fill="none"
              stroke="#E52424"
              strokeWidth="4"
              strokeLinecap="round"
              strokeDasharray="70 220"
              className="zx-spin"
              style={{ transformOrigin: "60px 60px" }}
            />
            <path d="M62 34l-16 30h12l-6 22 18-32H58z" fill="#E52424" />
          </svg>
          <p className="font-heading text-lg font-bold text-white">Taking too long</p>
          <p className="text-sm text-white/70">Check your connection and try again.</p>
          <div className="mt-2 flex gap-2">
            <button
              type="button"
              className="zx-btn"
              onClick={() => {
                setStuck(false);
                window.location.reload();
              }}
            >
              Retry
            </button>
            <button type="button" className="zx-btn zx-btn-ghost" onClick={() => setStuck(false)}>
              Dismiss
            </button>
          </div>
        </div>
      )}
    </>
  );
}
