"use client";

import { splitImageSource } from "@/data/image-cdn";
import { useRouter } from "next/navigation";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { Icon } from "./Icon";

/* ------------------------------------------------------------------ toasts */

export type ToastKind = "cart" | "success" | "error" | "info" | "offline" | "heart" | "order";
type Toast = { id: number; kind: ToastKind; title: string; body?: string };

const ToastCtx = createContext<{ push: (t: Omit<Toast, "id">) => void } | null>(null);

function ToastArt({ kind }: { kind: ToastKind }) {
  const yellow = "#E52424";
  if (kind === "cart") {
    return (
      <svg viewBox="0 0 40 40" className="h-9 w-9 shrink-0" aria-hidden>
        <circle cx="20" cy="20" r="17" fill={yellow} opacity="0.16" />
        <g fill="none" stroke={yellow} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
          <path className="zx-drop" d="M11 15h18l-2 12H13z" />
          <path className="zx-drop" d="M16 15a4 4 0 0 1 8 0" />
          <path className="zx-draw" stroke="#FFFFFF" strokeWidth="2.6" d="M16 21.5l2.6 2.6L25 17.5" />
        </g>
      </svg>
    );
  }
  if (kind === "success" || kind === "order") {
    return (
      <svg viewBox="0 0 40 40" className="h-9 w-9 shrink-0" aria-hidden>
        <circle cx="20" cy="20" r="17" fill={yellow} opacity="0.16" />
        <circle cx="20" cy="20" r="13" fill="none" stroke={yellow} strokeWidth="2" opacity="0.5" className="zx-ring" />
        <circle cx="20" cy="20" r="12" fill="none" stroke={yellow} strokeWidth="2.4" />
        <path className="zx-draw" d="M14 20.5l4 4 8-9" fill="none" stroke={yellow} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  }
  if (kind === "error") {
    return (
      <svg viewBox="0 0 40 40" className="h-9 w-9 shrink-0" aria-hidden>
        <circle cx="20" cy="20" r="17" fill="#dc2626" opacity="0.18" />
        <g stroke="#fda4a4" strokeWidth="2.6" strokeLinecap="round" fill="none">
          <path className="zx-drop" d="M14 14l12 12M26 14L14 26" />
        </g>
      </svg>
    );
  }
  if (kind === "heart") {
    return (
      <svg viewBox="0 0 40 40" className="h-9 w-9 shrink-0" aria-hidden>
        <path
          className="zx-drop"
          d="M20 31s-11-6.6-11-14a6 6 0 0 1 11-3.4A6 6 0 0 1 31 17c0 7.4-11 14-11 14z"
          fill={yellow}
          stroke={yellow}
          strokeWidth="2"
          strokeLinejoin="round"
        />
      </svg>
    );
  }
  if (kind === "offline") {
    return (
      <svg viewBox="0 0 40 40" className="h-9 w-9 shrink-0" aria-hidden>
        <g fill="none" stroke={yellow} strokeWidth="2.2" strokeLinecap="round">
          <path d="M8 16a17 17 0 0 1 24 0" opacity="0.45" />
          <path d="M12.5 21a11 11 0 0 1 15 0" opacity="0.7" />
          <path d="M17 26a5 5 0 0 1 6 0" />
          <path className="zx-drop" d="M9 9l22 22" stroke="#fda4a4" />
        </g>
        <circle cx="20" cy="31" r="1.6" fill={yellow} />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 40 40" className="h-9 w-9 shrink-0" aria-hidden>
      <circle cx="20" cy="20" r="17" fill={yellow} opacity="0.16" />
      <g fill="none" stroke={yellow} strokeWidth="2.4" strokeLinecap="round">
        <circle cx="20" cy="20" r="12" opacity="0.5" />
        <path className="zx-draw" d="M20 14.5v7M20 25.5v.2" />
      </g>
    </svg>
  );
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const idRef = useRef(0);
  const timers = useRef<Record<number, ReturnType<typeof setTimeout>>>({});

  const remove = useCallback((id: number) => {
    setToasts((prev) => prev.map((t) => (t.id === id ? { ...t, out: true } : t)) as Toast[]);
    setTimeout(() => setToasts((prev) => prev.filter((t) => t.id !== id)), 240);
  }, []);

  const push = useCallback(
    (t: Omit<Toast, "id">) => {
      const id = ++idRef.current;
      setToasts((prev) => [...prev.slice(-2), { ...t, id }]);
      timers.current[id] = setTimeout(() => remove(id), 2600);
    },
    [remove],
  );

  useEffect(() => () => Object.values(timers.current).forEach(clearTimeout), []);

  const value = useMemo(() => ({ push }), [push]);

  return (
    <ToastCtx.Provider value={value}>
      {children}
      <div className="zx-toasts" aria-live="polite" aria-atomic="false">
        {toasts.map((t) => (
          <div key={t.id} className={`zx-toast ${(t as Toast & { out?: boolean }).out ? "out" : ""}`}>
            <ToastArt kind={t.kind} />
            <span className="min-w-0">
              <span className="block truncate font-heading text-sm font-semibold">{t.title}</span>
              {t.body && <span className="block truncate text-xs text-white/70">{t.body}</span>}
            </span>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastCtx);
  return ctx?.push ?? (() => undefined);
}

// Kept as re-exports so all existing pages share one notification provider.
export { CodeNoticeProvider, useCodeNotice } from "./CodeNotifications";

/* ------------------------------------------------------- page header (back/close) */

export function PageHeader({
  title,
  back,
  onClose,
  right,
}: {
  title: string;
  back?: string;
  onClose?: () => void;
  right?: ReactNode;
}) {
  const router = useRouter();
  return (
    <header className="flex items-center gap-2 bg-zx px-3 py-2.5 text-white">
      {back !== undefined ? (
        <button
          type="button"
          className="grid h-11 w-11 shrink-0 place-items-center rounded-full active:scale-95 transition-transform"
          onClick={() => (back ? router.push(back) : router.back())}
          aria-label="Back"
        >
          <Icon name="chevron-left" />
        </button>
      ) : (
        <span className="w-2 shrink-0" />
      )}
      <h1 className="font-heading min-w-0 flex-1 truncate text-base font-bold">{title}</h1>
      {right}
      {onClose && (
        <button
          type="button"
          className="grid h-11 w-11 shrink-0 place-items-center rounded-full active:scale-95 transition-transform"
          onClick={onClose}
          aria-label="Close"
        >
          <Icon name="close" />
        </button>
      )}
    </header>
  );
}

/* --------------------------------------------------------------- sheet / modal */

export function Sheet({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  return (
    <>
      <div className={`zx-backdrop ${open ? "open" : ""}`} onClick={onClose} aria-hidden />
      <div
        className={`zx-sheet ${open ? "open" : ""}`}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        aria-hidden={!open}
        inert={!open}
      >
        <div className="zx-handle" />
        {title && (
          <div className="mb-2 flex items-center justify-between">
            <p className="font-heading text-lg font-bold">{title}</p>
            <button type="button" className="grid h-10 w-10 place-items-center rounded-full" onClick={onClose} aria-label="Close">
              <Icon name="close" size={20} />
            </button>
          </div>
        )}
        {children}
      </div>
    </>
  );
}

export function Modal({
  open,
  onClose,
  title,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  return (
    <div className={`zx-modal ${open ? "open" : ""}`} role="dialog" aria-modal="true" aria-label={title}>
      <div
        className={`zx-backdrop zx-backdrop-blur ${open ? "open" : ""}`}
        onClick={onClose}
        aria-hidden
      />
      <div className="zx-modal-card">
        {title && (
          <div className="mb-2 flex items-center justify-between gap-3">
            <p className="font-heading truncate text-lg font-bold">{title}</p>
            <button
              type="button"
              className="grid h-10 w-10 shrink-0 place-items-center rounded-full transition-transform active:scale-90"
              onClick={onClose}
              aria-label="Close"
            >
              <Icon name="close" size={20} />
            </button>
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------- image */

export function SmartImage({
  src,
  alt,
  className = "",
  ratio = "1 / 1",
  eager = false,
  fallbackSrc,
}: {
  src: string;
  alt: string;
  className?: string;
  ratio?: string;
  eager?: boolean;
  /** Extra same-origin fallback. Hosted images already carry their bundled path. */
  fallbackSrc?: string;
}) {
  const parts = splitImageSource(src);
  const primary = parts.url;
  const backup = fallbackSrc ?? parts.fallback;
  // Ultimate same-origin fallback — always exists, so a card never goes blank
  // even if both the ImgLink CDN and the local mirror fail.
  const PLACEHOLDER = "/images/placeholder.svg";

  type Stage = { src: string; attempt: 0 | 1 | 2; status: "loading" | "loaded" | "error" };
  const [stage, setStage] = useState<Stage>({ src: primary, attempt: 0, status: "loading" });

  // When the source changes (new catalog, filter, page), derive a fresh loading
  // state during render. No effect runs after mount, so a finished load is never
  // overwritten by a late reset.
  const current: Stage =
    stage.src === primary ? stage : { src: primary, attempt: 0, status: "loading" };
  const status = current.status;
  const activeSrc =
    current.attempt === 1 && backup
      ? backup
      : current.attempt === 2
        ? PLACEHOLDER
        : primary;
  // `ratio="auto"` leaves sizing to the parent so responsive classes can win.
  const ratioStyle = ratio === "auto" ? undefined : { aspectRatio: ratio };

  const markLoaded = useCallback(() => {
    setStage((s) => {
      if (s.src === primary && s.status === "loaded") return s;
      return { src: primary, attempt: s.src === primary ? s.attempt : 0, status: "loaded" };
    });
  }, [primary]);

  const handleFailure = useCallback(() => {
    setStage((s) => {
      const attempt = s.src === primary ? s.attempt : 0;
      // 0 (ImgLink CDN) -> 1 (local mirror) -> 2 (branded placeholder) -> error icon.
      if (attempt === 0) {
        if (backup && backup !== primary && backup !== PLACEHOLDER) {
          return { src: primary, attempt: 1, status: "loading" };
        }
        return { src: primary, attempt: 2, status: "loading" };
      }
      if (attempt === 1) {
        return { src: primary, attempt: 2, status: "loading" };
      }
      return { src: primary, attempt, status: "error" };
    });
  }, [primary, backup, PLACEHOLDER]);

  // Cached images can finish loading before React attaches onLoad (page changes,
  // remounts). Check the element itself so those images are marked as loaded.
  const imgRef = useCallback(
    (node: HTMLImageElement | null) => {
      if (node && node.complete && node.naturalWidth > 0) markLoaded();
    },
    [markLoaded],
  );

  // Never leave a shopper staring at a skeleton: after 4s move to the next
  // fallback (local mirror, then branded placeholder, then icon).
  useEffect(() => {
    if (status !== "loading") return;
    const timer = window.setTimeout(handleFailure, 4000);
    return () => window.clearTimeout(timer);
  }, [status, activeSrc, handleFailure]);

  return (
    <div className={`relative overflow-hidden bg-zx-bg ${className}`} style={ratioStyle}>
      {status === "loading" && <div className="zx-skel absolute inset-0" aria-hidden />}
      {status === "error" ? (
        <div className="absolute inset-0 grid place-items-center text-zx-muted">
          <Icon name="info" />
        </div>
      ) : (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          ref={imgRef}
          src={activeSrc}
          alt={alt}
          loading={eager ? "eager" : "lazy"}
          decoding="async"
          referrerPolicy="no-referrer"
          className="absolute inset-0 h-full w-full object-cover"
          onLoad={markLoaded}
          onError={handleFailure}
        />
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ skeletons */

export function SkeletonCard() {
  return (
    <div className="zx-card overflow-hidden">
      <div className="zx-skel aspect-square w-full rounded-none" />
      <div className="space-y-2 p-3">
        <div className="zx-skel h-3 w-4/5" />
        <div className="zx-skel h-3 w-1/2" />
        <div className="zx-skel h-9 w-full" />
      </div>
    </div>
  );
}

export function SkeletonRow({ count = 4 }: { count?: number }) {
  return (
    <div className="no-scrollbar flex gap-3 overflow-hidden px-4">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="w-[148px] shrink-0">
          <SkeletonCard />
        </div>
      ))}
    </div>
  );
}
