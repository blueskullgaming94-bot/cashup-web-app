"use client";

import "leaflet/dist/leaflet.css";
import type { Circle, Map as LeafletInstance, Marker } from "leaflet";
import { useEffect, useRef, useState } from "react";

type Props = {
  lat: number;
  lng: number;
  zoom?: number;
  accuracy?: number;
  onChange: (lat: number, lng: number) => void;
  onTilesFailed?: () => void;
  onTilesReady?: () => void;
};

export default function LeafletMap({ lat, lng, zoom = 14, accuracy, onChange, onTilesFailed, onTilesReady }: Props) {
  const holder = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletInstance | null>(null);
  const markerRef = useRef<Marker | null>(null);
  const circleRef = useRef<Circle | null>(null);
  const latest = useRef({ lat, lng, zoom, accuracy, onChange, onTilesFailed, onTilesReady });
  latest.current = { lat, lng, zoom, accuracy, onChange, onTilesFailed, onTilesReady };
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let disposed = false;
    let resize: ResizeObserver | undefined;
    let frame = 0;
    void (async () => {
      const mod = await import("leaflet");
      const L = mod.default ?? mod;
      if (disposed || !holder.current) return;
      const current = latest.current;
      const map = L.map(holder.current, { zoomControl: false, attributionControl: true })
        .setView([current.lat, current.lng], current.zoom);
      L.control.zoom({ position: "bottomleft" }).addTo(map);
      let errors = 0;
      const tiles = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        maxZoom: 19, minZoom: 8, crossOrigin: true,
      }).addTo(map);
      tiles.on("tileerror", () => { if (++errors >= 3 && !disposed) latest.current.onTilesFailed?.(); });
      tiles.on("tileload", () => { if (!disposed) latest.current.onTilesReady?.(); });
      const icon = L.divIcon({ className: "", html: '<div class="zx-pin"></div>', iconSize: [30, 30], iconAnchor: [15, 30] });
      const circle = L.circle([current.lat, current.lng], {
        radius: current.accuracy ?? 0, color: "#1A1F2C", weight: 1,
        fillColor: "#E52424", fillOpacity: current.accuracy ? 0.18 : 0, interactive: false,
      }).addTo(map);
      const marker = L.marker([current.lat, current.lng], { icon, draggable: true, autoPan: true, title: "Delivery pin" }).addTo(map);
      const move = (la: number, lo: number) => {
        marker.setLatLng([la, lo]);
        latest.current.onChange(la, lo);
      };
      marker.on("dragend", () => { const p = marker.getLatLng(); move(p.lat, p.lng); });
      map.on("click", (event) => move(event.latlng.lat, event.latlng.lng));
      mapRef.current = map;
      markerRef.current = marker;
      circleRef.current = circle;
      setReady(true);
      frame = requestAnimationFrame(() => { if (!disposed) map.invalidateSize({ pan: false }); });
      if (typeof ResizeObserver !== "undefined") {
        resize = new ResizeObserver(() => { if (!disposed) map.invalidateSize({ pan: false }); });
        resize.observe(holder.current);
      }
    })().catch(() => { if (!disposed) latest.current.onTilesFailed?.(); });
    return () => {
      disposed = true;
      cancelAnimationFrame(frame);
      resize?.disconnect();
      const map = mapRef.current;
      if (map) {
        // Removing a map mid pan/zoom animation makes Leaflet read a detached
        // pane (`_leaflet_pos`). Stop animations and listeners first.
        try { map.stop(); map.off(); } catch { /* already detached */ }
        // Leaflet schedules _onZoomTransitionEnd on an uncancellable 250ms timer.
        // It only acts while `_animatingZoom` is true; clear it so a zoom that is
        // still animating when the popup closes can't touch the removed map pane.
        (map as unknown as { _animatingZoom?: boolean })._animatingZoom = false;
        try { map.remove(); } catch { /* already removed */ }
      }
      mapRef.current = null;
      markerRef.current = null;
      circleRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    const marker = markerRef.current;
    if (!ready || !map || !marker) return;
    const position = marker.getLatLng();
    const changed = Math.abs(position.lat - lat) > 0.0000001 || Math.abs(position.lng - lng) > 0.0000001;
    if (changed) {
      marker.setLatLng([lat, lng]);
      // Only animate when the map is actually on screen.
      const visible = Boolean((map.getContainer() as HTMLElement).offsetParent);
      map.setView([lat, lng], zoom, { animate: visible && !window.matchMedia("(prefers-reduced-motion: reduce)").matches });
    }
    circleRef.current?.setLatLng([lat, lng]).setRadius(accuracy ?? 0).setStyle({ fillOpacity: accuracy ? 0.18 : 0 });
  }, [lat, lng, zoom, accuracy, ready]);

  return <div ref={holder} className="h-full w-full" data-testid="delivery-live-map" data-lat={lat} data-lng={lng} aria-label="Delivery location map" />;
}
