"use client";

import { useId, useRef, useState, type ReactNode } from "react";
import { Icon } from "./Icon";

const ACTION_WIDTH = 92;
const START_THRESHOLD = 8;

/**
 * Swipe a row to the RIGHT to reveal a Delete button on its left. Deleting always
 * needs a deliberate tap on that button — the swipe alone never removes anything.
 *
 * - Touch and mouse drag (pointer events); vertical scrolling still works.
 * - Keyboard: focus the row, Right Arrow reveals Delete, Left Arrow / Escape hides it.
 * - Tapping the row (or swiping back) closes it again.
 */
export function SwipeToDelete({
  children,
  onDelete,
  label,
  className = "",
}: {
  children: ReactNode;
  onDelete: () => void;
  /** Describes the row for screen readers, e.g. "Office, Clifton". */
  label: string;
  className?: string;
}) {
  const hintId = useId();
  const [offset, setOffset] = useState(0);
  const [dragging, setDragging] = useState(false);
  const open = offset >= ACTION_WIDTH / 2 && !dragging;
  const drag = useRef<{ x: number; y: number; from: number; active: boolean } | null>(null);
  const moved = useRef(false);

  function settle(next: number) {
    setDragging(false);
    setOffset(next >= ACTION_WIDTH / 2 ? ACTION_WIDTH : 0);
  }

  return (
    <div className={`relative overflow-hidden rounded-xl ${className}`}>
      {/* Revealed action (behind the row, on the left). Not focusable until revealed. */}
      <div className="absolute inset-y-0 left-0 flex" style={{ width: ACTION_WIDTH }} aria-hidden={!open}>
        <button
          type="button"
          tabIndex={open ? 0 : -1}
          onClick={onDelete}
          className="flex h-full w-full flex-col items-center justify-center gap-1 bg-zx-error text-xs font-bold text-white transition-colors active:bg-[#b91c1c]"
          aria-label={`Delete address ${label}`}
        >
          <Icon name="trash" size={20} />
          Delete
        </button>
      </div>

      <div
        role="group"
        tabIndex={0}
        aria-label={label}
        aria-describedby={hintId}
        className={`relative select-none bg-zx-bg ${dragging ? "" : "transition-transform duration-200 ease-out"}`}
        style={{ transform: `translateX(${offset}px)`, touchAction: "pan-y" }}
        onPointerDown={(e) => {
          if (e.pointerType === "mouse" && e.button !== 0) return;
          drag.current = { x: e.clientX, y: e.clientY, from: offset, active: false };
          moved.current = false;
        }}
        onPointerMove={(e) => {
          const d = drag.current;
          if (!d) return;
          const dx = e.clientX - d.x;
          const dy = e.clientY - d.y;
          if (!d.active) {
            if (Math.abs(dy) > START_THRESHOLD && Math.abs(dy) > Math.abs(dx)) {
              drag.current = null; // vertical scroll — leave it to the browser
              return;
            }
            if (Math.abs(dx) < START_THRESHOLD) return;
            d.active = true;
            moved.current = true;
            setDragging(true);
            e.currentTarget.setPointerCapture?.(e.pointerId);
          }
          // Only rightward travel (with a little rubber-band past the button).
          setOffset(Math.max(0, Math.min(ACTION_WIDTH + 14, d.from + dx)));
        }}
        onPointerUp={() => {
          const d = drag.current;
          drag.current = null;
          if (d?.active) settle(offset);
        }}
        onPointerCancel={() => {
          if (drag.current?.active) settle(offset);
          drag.current = null;
        }}
        onClickCapture={(e) => {
          // A drag must not count as a tap; a tap on an open row just closes it.
          if (moved.current) { e.preventDefault(); e.stopPropagation(); moved.current = false; return; }
          if (open) { e.preventDefault(); e.stopPropagation(); setOffset(0); }
        }}
        onKeyDown={(e) => {
          if (e.key === "ArrowRight") { e.preventDefault(); setOffset(ACTION_WIDTH); }
          else if (e.key === "ArrowLeft" || e.key === "Escape") { e.preventDefault(); setOffset(0); }
        }}
      >
        {children}
        <span id={hintId} className="sr-only">
          Swipe right, or press the right arrow key, to show the delete button.
        </span>
      </div>
    </div>
  );
}
