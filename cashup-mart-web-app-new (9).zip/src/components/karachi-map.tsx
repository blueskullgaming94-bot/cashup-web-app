"use client";

import { detectCurrentLocation } from "@/lib/geolocation";
import { isInsideKarachi, nearestArea } from "@/lib/karachi";
import dynamic from "next/dynamic";
import { useEffect, useRef, useState } from "react";
import { Icon } from "./Icon";
import { KarachiSvgMap } from "./karachi-svg-map";

const LeafletMap = dynamic(() => import("./leaflet-map"), {
  ssr: false, loading: () => <div className="zx-skel h-full w-full rounded-none" />,
});
export type PinSelection = { source: "gps" | "pin"; accuracy?: number };
type Props = {
  lat: number;
  lng: number;
  areaLabel?: string;
  accuracy?: number;
  onChange: (lat: number, lng: number, selection?: PinSelection) => void;
  onSelectArea?: (area: string) => void;
  online: boolean;
};

export function KarachiMap({ lat, lng, areaLabel, accuracy, onChange, onSelectArea, online }: Props) {
  const [tilesReady, setTilesReady] = useState(false);
  const [tilesFailed, setTilesFailed] = useState(false);
  const [mapVersion, setMapVersion] = useState(0);
  const [tracking, setTracking] = useState(false);
  const [progressAccuracy, setProgressAccuracy] = useState<number | null>(null);
  const [message, setMessage] = useState("");
  const activeRequest = useRef<AbortController | null>(null);

  useEffect(() => {
    setTilesReady(false);
    setTilesFailed(false);
  }, [online]);
  useEffect(() => () => activeRequest.current?.abort(), []);

  function cancelTracking() {
    activeRequest.current?.abort();
    activeRequest.current = null;
    setTracking(false);
  }

  async function useMyLocation() {
    cancelTracking();
    if (!window.isSecureContext) {
      setMessage("Automatic location needs HTTPS. You can still select an area or drop the pin.");
      return;
    }
    const controller = new AbortController();
    activeRequest.current = controller;
    setMessage("");
    setProgressAccuracy(null);
    setTracking(true);
    try {
      const fix = await detectCurrentLocation({
        signal: controller.signal,
        onProgress: (p) => setProgressAccuracy(Math.ceil(p.accuracy)),
      });
      if (controller.signal.aborted) return;
      onChange(fix.lat, fix.lng, { source: "gps", accuracy: fix.accuracy });
      setMessage(isInsideKarachi(fix.lat, fix.lng)
        ? `Pin located (accuracy ±${Math.ceil(fix.accuracy)} m). ${fix.accuracy > 100 ? "The signal is approximate; move the pin to your entrance if needed." : "Please check that the pin marks your entrance."}`
        : "This position is outside our Karachi delivery area. Select a Karachi address to continue.");
    } catch (error) {
      if (controller.signal.aborted) return;
      setMessage(error instanceof Error ? error.message : "Could not get a position. Please select your address manually.");
    } finally {
      if (activeRequest.current === controller) {
        activeRequest.current = null;
        setTracking(false);
      }
    }
  }

  function selectPin(la: number, lo: number) {
    cancelTracking();
    setMessage("");
    onChange(la, lo, { source: "pin" });
  }

  return (
    <div className="space-y-2 min-w-0">
      <button
        type="button"
        onClick={useMyLocation}
        disabled={tracking}
        className="zx-btn w-full"
        aria-label="Use my current location"
      >
        <Icon name="location" size={18} /> {tracking ? "Locating you…" : "Use my current location"}
      </button>
      <div className="zx-map" aria-busy={tracking}>
        {online ? (
          <LeafletMap
            key={mapVersion}
            lat={lat} lng={lng} accuracy={accuracy} zoom={accuracy !== undefined ? 18 : 14}
            onChange={selectPin}
            onTilesReady={() => { setTilesReady(true); setTilesFailed(false); }}
            onTilesFailed={() => setTilesFailed(true)}
          />
        ) : (
          <KarachiSvgMap lat={lat} lng={lng} onChange={selectPin} onSelectArea={(area) => { cancelTracking(); onSelectArea?.(area); }} />
        )}
        <div className="pointer-events-none absolute left-3 top-3 max-w-[85%] truncate rounded-full bg-zx px-3 py-1.5 text-[11px] font-semibold text-white">
          {online ? "Live map" : "Offline map"} · {isInsideKarachi(lat, lng) ? (areaLabel || nearestArea(lat, lng)) : "Outside Karachi"}
        </div>
        {online && !tilesReady && !tilesFailed && !tracking && (
          <div className="pointer-events-none absolute inset-0 grid place-items-center bg-zx-card/50" role="status">
            <span className="rounded-full bg-zx px-3 py-2 text-xs text-white">Loading live map…</span>
          </div>
        )}
        {online && tilesFailed && !tracking && (
          <div className="absolute inset-x-3 bottom-8 rounded-xl bg-zx-card/95 p-3 text-xs shadow">
            <p>Map tiles could not load. Your selected pin is unchanged.</p>
            <button type="button" className="mt-1 min-h-9 font-bold underline" onClick={() => { setTilesFailed(false); setTilesReady(false); setMapVersion((v) => v + 1); }}>
              Retry live map
            </button>
          </div>
        )}
        {tracking && (
          <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-zx/80 p-4 text-center backdrop-blur-sm" role="status" aria-live="polite">
            <svg viewBox="0 0 64 64" className="h-14 w-14" aria-hidden="true">
              <circle cx="32" cy="32" r="26" fill="none" stroke="#E52424" strokeWidth="2" opacity="0.25" />
              <circle cx="32" cy="32" r="17" fill="none" stroke="#E52424" strokeWidth="2" opacity="0.4" />
              <circle cx="32" cy="32" r="26" fill="none" stroke="#E52424" strokeWidth="3" strokeDasharray="45 120" className="zx-spin" />
              <circle cx="32" cy="32" r="5" fill="#E52424" />
            </svg>
            <p className="text-sm font-bold text-white">Finding your most accurate location…</p>
            <p className="text-xs text-white/80">
              {progressAccuracy === null ? "Allow precise location when your browser asks." : `Current accuracy ±${progressAccuracy} m. Refining the GPS signal…`}
            </p>
            <button type="button" className="min-h-10 rounded-full border border-white/30 px-4 text-xs font-semibold text-white" onClick={cancelTracking}>Cancel locating</button>
          </div>
        )}
      </div>
      {message && <p role="status" className="rounded-xl bg-zx-yellow/15 px-3 py-2 text-xs leading-relaxed text-zx-ink">{message}</p>}
      <p className="text-[11px] leading-relaxed text-zx-muted">
        Location is used only when you ask. GPS accuracy and mapped house numbers vary; confirm your door or flat before saving.
      </p>
    </div>
  );
}
