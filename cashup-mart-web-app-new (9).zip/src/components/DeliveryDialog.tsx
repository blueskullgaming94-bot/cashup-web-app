"use client";

import { useEffect } from "react";
import { LocationPicker } from "./location";
import { useStore } from "./store";
import { Modal } from "./ui";

/** One global delivery dialog, including on checkout. Closed dialogs don't mount maps. */
export function DeliveryDialog() {
  const { hydrated, address, locationModalOpen, setLocationModalOpen } = useStore();
  useEffect(() => {
    if (!hydrated || !locationModalOpen) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = previous; };
  }, [hydrated, locationModalOpen]);

  if (!hydrated || !locationModalOpen) return null;
  const close = () => setLocationModalOpen(false);
  return (
    <Modal open onClose={close} title={address ? "Update Delivery Location" : "Where should we deliver?"}>
      <LocationPicker variant="modal" onDone={close} onClose={close} />
    </Modal>
  );
}
