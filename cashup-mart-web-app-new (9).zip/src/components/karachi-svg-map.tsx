"use client";

import { AREA_COORDS, fromView, nearestArea, toView } from "@/lib/karachi";
import { useCallback, useRef } from "react";

type Props = {
  lat: number;
  lng: number;
  onChange: (lat: number, lng: number) => void;
  onSelectArea?: (area: string) => void;
};

const COAST =
  "M0,72 L8,70 L16,74 L24,71 L31,76 L38,73 L46,78 L54,74 L62,79 L70,75 L78,80 L86,76 L100,82 L100,100 L0,100 Z";

const ROADS = [
  "M6,40 L34,44 L58,38 L92,46",
  "M22,6 L28,34 L36,62 L30,92",
  "M48,4 L52,30 L60,54 L74,84",
  "M8,58 L40,62 L70,58 L96,66",
];

/**
 * Branded offline map of Karachi. Always renders (no tiles, no network):
 * purple land, yellow roads, tappable area dots and a draggable pin.
 */
export function KarachiSvgMap({ lat, lng, onChange, onSelectArea }: Props) {
  const svgRef = useRef<SVGSVGElement | null>(null);
  const dragging = useRef(false);
  const pin = toView(lat, lng);

  const emit = useCallback(
    (clientX: number, clientY: number) => {
      const svg = svgRef.current;
      if (!svg) return;
      const rect = svg.getBoundingClientRect();
      const x = ((clientX - rect.left) / rect.width) * 100;
      const y = ((clientY - rect.top) / rect.height) * 100;
      const next = fromView(Math.max(0, Math.min(100, x)), Math.max(0, Math.min(100, y)));
      onChange(next.lat, next.lng);
    },
    [onChange],
  );

  const dots = Object.entries(AREA_COORDS).map(([name, c]) => ({ name, ...toView(c.lat, c.lng) }));
  const active = nearestArea(lat, lng);

  return (
    <div className="relative h-full w-full">
      <svg
        ref={svgRef}
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        className="h-full w-full touch-none select-none"
        role="application"
        aria-label="Karachi delivery map. Drag the pin to set your location."
        onPointerDown={(e) => {
          dragging.current = true;
          (e.target as Element).setPointerCapture?.(e.pointerId);
          emit(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (dragging.current) emit(e.clientX, e.clientY);
        }}
        onPointerUp={() => {
          dragging.current = false;
        }}
        onPointerCancel={() => {
          dragging.current = false;
        }}
      >
        <rect width="100" height="100" fill="#EDF1F7" />
        <path d={COAST} fill="#1A1F2C" opacity="0.12" />
        <path d={COAST} fill="none" stroke="#1A1F2C" strokeWidth="0.5" opacity="0.35" />
        {ROADS.map((d, i) => (
          <path key={i} d={d} fill="none" stroke="#E52424" strokeWidth="0.9" opacity="0.55" strokeLinecap="round" />
        ))}
        <path
          d="M14,20 L46,16 L72,22 L88,34 L84,56 L60,64 L34,60 L12,46 Z"
          fill="#2A4B9B"
          opacity="0.08"
          stroke="#2A4B9B"
          strokeWidth="0.35"
          strokeOpacity="0.25"
        />
        {dots.map((d) => (
          <g
            key={d.name}
            onClick={(e) => {
              e.stopPropagation();
              onSelectArea?.(d.name);
            }}
            className="zx-map-dot"
          >
            <circle cx={d.x} cy={d.y} r={d.name === active ? 1.5 : 0.9} fill={d.name === active ? "#E52424" : "#2A4B9B"} opacity={d.name === active ? 1 : 0.5} />
            <circle cx={d.x} cy={d.y} r="3" fill="transparent" />
          </g>
        ))}
        <g transform={`translate(${pin.x} ${pin.y})`} pointerEvents="none">
          <circle r="4" fill="#E52424" opacity="0.28" className="zx-ring" />
          <path
            d="M0,0 C0,0 -3.4,-4.2 -3.4,-6.6 A3.4,3.4 0 1,1 3.4,-6.6 C3.4,-4.2 0,0 0,0 Z"
            fill="#E52424"
            stroke="#FFFFFF"
            strokeWidth="0.7"
          />
          <circle cy="-6.6" r="1.1" fill="#FFFFFF" />
        </g>
      </svg>
      <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-center justify-between bg-gradient-to-t from-zx/80 to-transparent px-3 py-2 text-[11px] text-white">
        <span>Offline Karachi map · drag to move the pin</span>
        <span className="font-semibold text-white">{active}</span>
      </div>
    </div>
  );
}
