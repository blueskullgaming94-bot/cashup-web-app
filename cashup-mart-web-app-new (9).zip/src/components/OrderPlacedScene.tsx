"use client";

/**
 * Order-placed story animation (pure SVG + CSS, brand colours only).
 *
 * It reads as a logical sequence on one shared 9s timeline:
 *   1. The store (left) lights up and the delivery route draws to the home (right).
 *   2. The rider leaves the store on a CD70-style bike — wheels spin, speed lines
 *      stream, exhaust puffs, the grocery box rides along.
 *   3. The rider parks at the customer's home.
 *   4. The box is handed over: the check mark draws on the delivery box and an
 *      arrival ring pops at the door.
 *   5. The location pin drops on the home — "delivered to your door".
 *
 * `prefers-reduced-motion` freezes the final handed-over frame (see globals.css).
 */
export function OrderPlacedScene({ compact = false }: { compact?: boolean }) {
  const height = compact ? "h-36 sm:h-40" : "h-52 sm:h-56 md:h-64";

  return (
    <svg
      viewBox="0 0 400 220"
      className={`w-full ${height}`}
      preserveAspectRatio="xMidYMid meet"
      role="img"
      aria-label="Animation: a CashUp Express rider collects your groceries from the store and rides to your home in Karachi"
    >
      <defs>
        <linearGradient id="zxSky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#2A4B9B" />
          <stop offset="58%" stopColor="#1B2340" />
          <stop offset="100%" stopColor="#10151F" />
        </linearGradient>
        <linearGradient id="zxRoad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#232B40" />
          <stop offset="100%" stopColor="#10151F" />
        </linearGradient>
        <radialGradient id="zxGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#E52424" stopOpacity="0.6" />
          <stop offset="100%" stopColor="#E52424" stopOpacity="0" />
        </radialGradient>
        <clipPath id="zxScene">
          <rect x="0" y="0" width="400" height="220" rx="16" />
        </clipPath>
      </defs>

      <g clipPath="url(#zxScene)">
        {/* ---------- sky ---------- */}
        <rect width="400" height="220" fill="url(#zxSky)" />

        {/* sun / street glow */}
        <g className="zx-sun-glow">
          <circle cx="342" cy="42" r="34" fill="url(#zxGlow)" />
          <circle cx="342" cy="42" r="12" fill="#E52424" opacity="0.9" />
        </g>

        {/* ---------- distant skyline ---------- */}
        <g fill="#0E1322" opacity="0.9">
          <rect x="96" y="118" width="20" height="47" />
          <rect x="120" y="104" width="14" height="61" />
          <rect x="140" y="126" width="24" height="39" />
          <rect x="172" y="112" width="16" height="53" />
          <path d="M194 165v-34l11-8 11 8v34z" />
          <rect x="222" y="122" width="20" height="43" />
          <rect x="248" y="108" width="13" height="57" />
          <rect x="266" y="128" width="22" height="37" />
        </g>
        <g fill="#9EC1E8" className="zx-window-blink">
          <rect x="101" y="126" width="4" height="4" />
          <rect x="124" y="112" width="4" height="4" />
          <rect x="146" y="134" width="4" height="4" />
          <rect x="177" y="120" width="4" height="4" />
          <rect x="227" y="130" width="4" height="4" />
          <rect x="252" y="116" width="4" height="4" />
          <rect x="272" y="136" width="4" height="4" />
        </g>

        {/* ---------- road ---------- */}
        <rect x="0" y="165" width="400" height="55" fill="url(#zxRoad)" />
        <rect x="0" y="165" width="400" height="2" fill="#E52424" opacity="0.22" />
        <g fill="#FFFFFF" opacity="0.16">
          <rect x="14" y="208" width="30" height="3" rx="1.5" />
          <rect x="72" y="208" width="30" height="3" rx="1.5" />
          <rect x="130" y="208" width="30" height="3" rx="1.5" />
          <rect x="188" y="208" width="30" height="3" rx="1.5" />
          <rect x="246" y="208" width="30" height="3" rx="1.5" />
          <rect x="304" y="208" width="30" height="3" rx="1.5" />
          <rect x="362" y="208" width="30" height="3" rx="1.5" />
        </g>

        {/* ---------- store (origin) ---------- */}
        <g>
          <rect x="20" y="106" width="64" height="59" fill="#1A1F2C" />
          <rect x="20" y="106" width="64" height="59" fill="none" stroke="#E52424" strokeOpacity="0.22" />
          <rect x="14" y="99" width="76" height="9" rx="3" fill="#E52424" />
          <rect x="30" y="115" width="44" height="14" rx="3" fill="#10151F" stroke="#E52424" strokeOpacity="0.65" />
          <text
            x="52"
            y="125.5"
            textAnchor="middle"
            fontSize="8.5"
            fontWeight="700"
            fill="#FFFFFF"
            fontFamily="Poppins, Inter, sans-serif"
            letterSpacing="0.6"
          >
            CASHUP
          </text>
          <rect x="44" y="140" width="16" height="25" rx="2" fill="#E52424" opacity="0.85" />
          <rect x="26" y="140" width="13" height="12" rx="1.5" fill="#9EC1E8" opacity="0.5" className="zx-window-blink" />
          <rect x="66" y="140" width="13" height="12" rx="1.5" fill="#9EC1E8" opacity="0.5" className="zx-window-blink" />
        </g>

        {/* ---------- customer home (destination) ---------- */}
        <g>
          <rect x="316" y="114" width="62" height="51" fill="#1A1F2C" />
          <rect x="316" y="114" width="62" height="51" fill="none" stroke="#E52424" strokeOpacity="0.22" />
          <path d="M308 116 L347 90 L386 116 Z" fill="#2A4B9B" stroke="#E52424" strokeOpacity="0.35" strokeWidth="1.5" />
          <rect x="339" y="136" width="17" height="29" rx="2" fill="#E52424" opacity="0.9" />
          <circle cx="352.5" cy="151" r="1.4" fill="#10151F" />
          <rect x="321" y="126" width="12" height="12" rx="1.5" fill="#9EC1E8" opacity="0.5" className="zx-window-blink" />
          <rect x="362" y="126" width="12" height="12" rx="1.5" fill="#9EC1E8" opacity="0.5" className="zx-window-blink" />
        </g>

        {/* ---------- route drawn from store to home ---------- */}
        <path
          className="zx-route-line zx-story"
          d="M90 191 Q 195 181 302 191"
          fill="none"
          stroke="#E52424"
          strokeWidth="3"
          strokeLinecap="round"
          opacity="0.85"
        />

        {/* ---------- arrival ring at the door ---------- */}
        <g className="zx-arrival-badge zx-story">
          <circle cx="347" cy="152" r="20" fill="none" stroke="#E52424" strokeWidth="2.5" opacity="0.85" />
          <circle cx="347" cy="152" r="27" fill="none" stroke="#E52424" strokeWidth="1.4" opacity="0.35" />
        </g>

        {/* ---------- pin drops on the home ---------- */}
        <g className="zx-home-pin zx-story" transform="translate(347 88)">
          <path
            d="M0 0 C0 0 -11 -13.5 -11 -21 A11 11 0 1 1 11 -21 C11 -13.5 0 0 0 0 Z"
            fill="#E52424"
            stroke="#10151F"
            strokeWidth="2"
          />
          <circle cy="-21" r="3.6" fill="#10151F" />
        </g>

        {/* ---------- rider on a CD70-style bike (side view, flat design) ---------- */}
        <g className="zx-rider-move zx-story">
          <g transform="translate(96 178)">
            {/* soft ground shadow */}
            <ellipse cx="24" cy="1.5" rx="40" ry="3.2" fill="#000" opacity="0.35" />

            {/* speed lines (only while riding) */}
            <g className="zx-speed-gate zx-story" stroke="#E52424" strokeLinecap="round" fill="none" opacity="0">
              <path className="zx-speed-line" d="M-58 -46 h30" strokeWidth="2.4" />
              <path className="zx-speed-line" d="M-74 -32 h42" strokeWidth="2.4" style={{ animationDelay: "0.1s" }} />
              <path className="zx-speed-line" d="M-56 -18 h26" strokeWidth="2" style={{ animationDelay: "0.2s" }} />
            </g>

            {/* exhaust puffs (only while riding) */}
            <g className="zx-puff-gate zx-story" opacity="0">
              <circle className="zx-puff" cx="-20" cy="-14" r="3.6" fill="#FFFFFF" />
              <circle className="zx-puff" cx="-20" cy="-14" r="2.8" fill="#FFFFFF" style={{ animationDelay: "0.45s" }} />
              <circle className="zx-puff" cx="-20" cy="-14" r="4.4" fill="#FFFFFF" style={{ animationDelay: "0.9s" }} />
            </g>

            <g className="zx-bike-bob">
              {/* ===== bicycle ===== */}
              {/* rear wheel */}
              <g transform="translate(0 -14)">
                <circle r="14" fill="#10151F" stroke="#FFFFFF" strokeWidth="2.4" />
                <g className="zx-wheel">
                  <circle r="9" fill="none" stroke="#FFFFFF" strokeWidth="0.8" opacity="0.45" />
                  <path d="M-9 0h18M0 -9v18M-6.4 -6.4l12.8 12.8M6.4 -6.4l-12.8 12.8" stroke="#E52424" strokeWidth="1.2" opacity="0.9" />
                </g>
                <circle r="2.4" fill="#E52424" />
              </g>
              {/* front wheel */}
              <g transform="translate(48 -14)">
                <circle r="14" fill="#10151F" stroke="#FFFFFF" strokeWidth="2.4" />
                <g className="zx-wheel">
                  <circle r="9" fill="none" stroke="#FFFFFF" strokeWidth="0.8" opacity="0.45" />
                  <path d="M-9 0h18M0 -9v18M-6.4 -6.4l12.8 12.8M6.4 -6.4l-12.8 12.8" stroke="#E52424" strokeWidth="1.2" opacity="0.9" />
                </g>
                <circle r="2.4" fill="#E52424" />
              </g>

              {/* frame */}
              <path
                d="M0 -14 L14 -33 M14 -33 L30 -19 L48 -14 M48 -14 L42 -35"
                fill="none"
                stroke="#FFFFFF"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* fenders */}
              <path d="M-14 -22 a15.5 15.5 0 0 1 27 -6" fill="none" stroke="#FFFFFF" strokeWidth="2.6" strokeLinecap="round" opacity="0.85" />
              <path d="M35 -25 a15.5 15.5 0 0 1 25 -4" fill="none" stroke="#FFFFFF" strokeWidth="2.6" strokeLinecap="round" opacity="0.85" />
              {/* engine + exhaust */}
              <rect x="15" y="-25" width="15" height="9" rx="2.5" fill="#2A4B9B" stroke="#FFFFFF" strokeWidth="1.3" />
              <path d="M15 -17 H-8" stroke="#FFFFFF" strokeWidth="3.2" strokeLinecap="round" opacity="0.75" />
              <circle cx="-8" cy="-17" r="2.6" fill="#FFFFFF" opacity="0.75" />

              {/* seat + fuel tank */}
              <rect x="-2" y="-38" width="17" height="5.5" rx="2.75" fill="#10151F" stroke="#FFFFFF" strokeWidth="1.1" />
              <rect x="13" y="-41" width="22" height="8" rx="4" fill="#E52424" />
              <rect x="15" y="-40" width="18" height="2.2" rx="1.1" fill="#10151F" opacity="0.18" />

              {/* handlebar + headlight */}
              <path d="M42 -35 L47 -43" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" />
              <path d="M43 -43 h10" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" />
              <circle cx="52" cy="-31" r="8" fill="url(#zxGlow)" />
              <circle cx="52" cy="-31" r="4" fill="#E52424" stroke="#10151F" strokeWidth="1" />

              {/* ===== delivery box (rider's back) ===== */}
              <g transform="translate(-30 -66)">
                <rect width="27" height="26" rx="4" fill="#E52424" stroke="#10151F" strokeWidth="2" />
                <rect x="0" y="0" width="27" height="6.5" rx="3.25" fill="#10151F" opacity="0.15" />
                <rect x="10.5" y="25" width="6" height="4" rx="1.2" fill="#10151F" opacity="0.3" />
                <circle cx="13.5" cy="16" r="8" fill="#fff" opacity="0.95" />
                <path
                  className="zx-box-check zx-story"
                  d="M9.5 16.5 l3 3 6-7"
                  fill="none"
                  stroke="#10151F"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </g>

              {/* ===== rider (seated, facing right) ===== */}
              {/* leg: hip → knee → foot on peg */}
              <path
                d="M9 -37 L23 -26 L21 -13"
                fill="none"
                stroke="#2A4B9B"
                strokeWidth="6"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* shoe */}
              <rect x="15.5" y="-14.5" width="10.5" height="4.5" rx="2.25" fill="#FFFFFF" />
              {/* torso: hips → shoulders (slight lean forward) */}
              <path d="M8 -38 L17 -56" fill="none" stroke="#2A4B9B" strokeWidth="11" strokeLinecap="round" />
              {/* arm: shoulder → elbow → handlebar */}
              <path
                d="M17 -54 L29 -48 L45 -43"
                fill="none"
                stroke="#2A4B9B"
                strokeWidth="5.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* glove */}
              <circle cx="46" cy="-42.5" r="2.6" fill="#E52424" />
              {/* scarf streaming back */}
              <path d="M15 -57 C 8 -59 4 -63 -3 -61" fill="none" stroke="#E52424" strokeWidth="4" strokeLinecap="round" opacity="0.9" />
              {/* helmet */}
              <circle cx="21.5" cy="-63.5" r="8" fill="#E52424" stroke="#10151F" strokeWidth="1.6" />
              <path d="M17.5 -67.5 a8 8 0 0 1 8 -1.5" fill="none" stroke="#fff" strokeWidth="1.4" strokeLinecap="round" opacity="0.7" />
              {/* visor */}
              <rect x="24.5" y="-66.5" width="7" height="5.5" rx="2.4" fill="#10151F" opacity="0.92" />
            </g>
          </g>
        </g>
      </g>
    </svg>
  );
}
