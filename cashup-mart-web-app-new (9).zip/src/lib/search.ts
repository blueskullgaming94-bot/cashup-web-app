import type { Product } from "./types";

/**
 * Small, dependency-free product search used by the floating search bar.
 *
 * Deliberately tolerant of typos: a shopper typing "aple", "onoin" or "milkk"
 * still reaches the right item. Runs entirely on-device, so it works offline.
 *
 * Ranking (highest first):
 *   exact match > word-start > start > substring > typo (edit distance) > subsequence
 * Name matches rank above brand, which rank above category words.
 */

const STOP_WORDS = new Set(["the", "a", "an", "of", "for", "and", "ka", "ki", "ke"]);

export function normalize(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function tokenize(value: string): string[] {
  return normalize(value)
    .split(" ")
    .filter((word) => word.length > 0 && !STOP_WORDS.has(word));
}

/** Classic edit distance with an early exit once the budget is exceeded. */
export function editDistance(a: string, b: string, budget: number): number {
  if (a === b) return 0;
  if (Math.abs(a.length - b.length) > budget) return budget + 1;
  let previous = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const current = [i];
    let rowBest = current[0];
    for (let j = 1; j <= b.length; j++) {
      const substitution = previous[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1);
      current[j] = Math.min(previous[j] + 1, current[j - 1] + 1, substitution);
      rowBest = Math.min(rowBest, current[j]);
    }
    if (rowBest > budget) return budget + 1;
    previous = current;
  }
  return previous[b.length];
}

export type RankedProduct = { product: Product; score: number; matched: string };

/** How many single-character mistakes we forgive, scaled to the word length. */
function typoBudget(word: string): number {
  if (word.length >= 7) return 3;
  if (word.length >= 5) return 2;
  if (word.length >= 3) return 1;
  return 0;
}

function fieldScore(haystack: string, tokens: string[], weight: number): number {
  if (!haystack) return 0;
  let total = 0;
  for (const token of tokens) {
    if (haystack === token) { total += weight * 100; continue; }
    if (new RegExp(`\\b${token}`).test(haystack)) { total += weight * 70; continue; }
    if (haystack.includes(token)) { total += weight * 55; continue; }
    const budget = typoBudget(token);
    if (budget > 0) {
      // Compare against whole words first, then the field as one string
      // (so "onoin" still reaches "onion", and "tamatar" reaches "tamatar").
      const words = haystack.split(" ").filter(Boolean);
      let best = Infinity;
      for (const word of words) {
        if (Math.abs(word.length - token.length) > budget) continue;
        best = Math.min(best, editDistance(token, word, budget));
      }
      if (best > budget && haystack.length <= token.length + budget * 2) {
        best = Math.min(best, editDistance(token, haystack, budget));
      }
      if (best <= budget) {
        // Fewer mistakes score higher.
        total += weight * (48 - best * 12);
      }
    }
  }
  return total;
}

/** True when the token's letters appear in order (helps with abbreviations). */
function isSubsequence(token: string, haystack: string): boolean {
  let at = 0;
  for (const char of haystack) {
    if (char === token[at]) at += 1;
    if (at === token.length) return true;
  }
  return at === token.length;
}

export function rankProducts(products: Product[], query: string, limit = 6): RankedProduct[] {
  const tokens = tokenize(query);
  if (!tokens.length) return [];
  const results: RankedProduct[] = [];

  for (const product of products) {
    if (!product.active) continue;
    const name = normalize(product.name);
    const brand = normalize(product.brand);
    const kind = normalize(`${product.subcategory} ${product.category}`);
    const unit = normalize(product.unit);

    const score =
      fieldScore(name, tokens, 6) +
      fieldScore(brand, tokens, 3) +
      fieldScore(kind, tokens, 2) +
      fieldScore(unit, tokens, 1);

    // Letters typed in order (e.g. "knum" → "kinnow") as a weak fallback.
    let sequence = 0;
    for (const token of tokens) {
      if (token.length >= 3 && !name.includes(token) && isSubsequence(token, name)) sequence += 12;
    }

    const total = score + sequence;
    if (total <= 0) continue;
    // Prefer items that match more of what was typed.
    const coverage = tokens.reduce((sum, token) => sum + (name.includes(token) ? 8 : 0), 0);
    results.push({
      product,
      score: total + coverage - (product.inStock ? 0 : 6),
      matched: name,
    });
  }

  return results.sort((a, b) => b.score - a.score || a.product.name.localeCompare(b.product.name)).slice(0, limit);
}
