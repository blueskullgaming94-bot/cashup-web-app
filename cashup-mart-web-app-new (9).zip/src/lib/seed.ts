import { banners as bannerSeed, categories as categorySeed, products as productSeed } from "@/data/catalog";
import { db } from "@/db";
import { banners, categories, products } from "@/db/schema";
import { ensureSchema } from "./schema-init";

let seeded = false;
let seeding: Promise<void> | null = null;

/**
 * Idempotently sync developer-managed catalog data into PostgreSQL.
 *
 * This intentionally upserts on each new server process rather than only
 * inserting into an empty DB. That means changes to image hosts, prices,
 * stock, descriptions and banners deploy immediately — existing customer,
 * address and order data is never touched.
 */
export async function ensureSeeded() {
  if (seeded) return;
  if (seeding) return seeding;
  seeding = doSeed().finally(() => {
    seeding = null;
  });
  return seeding;
}

async function doSeed() {
  await ensureSchema();

  for (const [i, c] of categorySeed.entries()) {
    await db
      .insert(categories)
      .values({
        slug: c.slug,
        name: c.name,
        icon: c.icon,
        subcategories: c.subcategories,
        blurb: c.blurb,
        sortOrder: i,
      })
      .onConflictDoUpdate({
        target: categories.slug,
        set: {
          name: c.name,
          icon: c.icon,
          subcategories: c.subcategories,
          blurb: c.blurb,
          sortOrder: i,
        },
      });
  }

  for (const [i, b] of bannerSeed.entries()) {
    await db
      .insert(banners)
      .values({
        id: b.id,
        title: b.title,
        subtitle: b.subtitle,
        image: b.image,
        href: b.href,
        sortOrder: i,
        active: true,
      })
      .onConflictDoUpdate({
        target: banners.id,
        set: {
          title: b.title,
          subtitle: b.subtitle,
          image: b.image,
          href: b.href,
          sortOrder: i,
          active: true,
        },
      });
  }

  // Batches keep the seed fast while remaining comfortably below PG parameter limits.
  const chunkSize = 40;
  for (let i = 0; i < productSeed.length; i += chunkSize) {
    for (const p of productSeed.slice(i, i + chunkSize)) {
      await db
        .insert(products)
        .values({
          id: p.id,
          slug: p.slug,
          name: p.name,
          category: p.category,
          subcategory: p.subcategory,
          brand: p.brand,
          unit: p.unit,
          price: p.price,
          salePrice: p.salePrice,
          image: p.image,
          description: p.description,
          inStock: p.inStock,
          active: p.active,
          tags: p.tags,
        })
        .onConflictDoUpdate({
          target: products.id,
          set: {
            slug: p.slug,
            name: p.name,
            category: p.category,
            subcategory: p.subcategory,
            brand: p.brand,
            unit: p.unit,
            price: p.price,
            salePrice: p.salePrice,
            image: p.image,
            description: p.description,
            inStock: p.inStock,
            active: p.active,
            tags: p.tags,
          },
        });
    }
  }

  seeded = true;
}
