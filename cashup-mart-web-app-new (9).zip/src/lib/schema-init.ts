import { db } from "@/db";
import { sql } from "drizzle-orm";

/**
 * Idempotent schema bootstrap.
 *
 * The platform can hand us a fresh/empty PostgreSQL at any time (new sandbox,
 * redeploy, DB reset). If tables are missing, every DB call fails and — before
 * this existed — order placement failed and the UI mislabelled it as
 * "Waiting for internet".
 *
 * `ensureSchema()` runs `CREATE TABLE IF NOT EXISTS` DDL that mirrors
 * `src/db/schema.ts` exactly, so the API self-heals with no manual migrate step.
 * `npx drizzle-kit push` remains the canonical path and produces the same shape.
 */
let done = false;
let inFlight: Promise<void> | null = null;

const DDL = [
  `CREATE TABLE IF NOT EXISTS categories (
     slug varchar(80) PRIMARY KEY,
     name varchar(120) NOT NULL,
     icon varchar(80) NOT NULL,
     subcategories jsonb NOT NULL,
     blurb text NOT NULL,
     sort_order integer NOT NULL DEFAULT 0
   )`,
  `CREATE TABLE IF NOT EXISTS products (
     id varchar(40) PRIMARY KEY,
     slug varchar(160) NOT NULL,
     name varchar(200) NOT NULL,
     category varchar(80) NOT NULL,
     subcategory varchar(80) NOT NULL,
     brand varchar(120) NOT NULL,
     unit varchar(60) NOT NULL,
     price integer NOT NULL,
     sale_price integer,
     image text NOT NULL,
     description text NOT NULL,
     in_stock boolean NOT NULL DEFAULT true,
     active boolean NOT NULL DEFAULT true,
     tags jsonb NOT NULL DEFAULT '[]'::jsonb
   )`,
  `CREATE TABLE IF NOT EXISTS banners (
     id varchar(40) PRIMARY KEY,
     title varchar(160) NOT NULL,
     subtitle varchar(200) NOT NULL,
     image text NOT NULL,
     href varchar(200) NOT NULL,
     sort_order integer NOT NULL DEFAULT 0,
     active boolean NOT NULL DEFAULT true
   )`,
  `CREATE TABLE IF NOT EXISTS customers (
     id serial PRIMARY KEY,
     phone varchar(20) NOT NULL,
     name varchar(120) NOT NULL,
     created_at timestamptz NOT NULL DEFAULT now()
   )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS customers_phone_idx ON customers (phone)`,
  `CREATE TABLE IF NOT EXISTS addresses (
     id serial PRIMARY KEY,
     phone varchar(20) NOT NULL,
     label varchar(80) NOT NULL,
     area varchar(120) NOT NULL,
     details text NOT NULL,
     note text NOT NULL DEFAULT '',
     lat real NOT NULL,
     lng real NOT NULL,
     is_default boolean NOT NULL DEFAULT false
   )`,
   `ALTER TABLE addresses ADD COLUMN IF NOT EXISTS house_number varchar(100) NOT NULL DEFAULT ''`,
   `ALTER TABLE addresses ADD COLUMN IF NOT EXISTS block_sector varchar(100) NOT NULL DEFAULT ''`,
   `ALTER TABLE addresses ADD COLUMN IF NOT EXISTS street varchar(180) NOT NULL DEFAULT ''`,
   `CREATE TABLE IF NOT EXISTS otp_codes (
     id serial PRIMARY KEY,
     phone varchar(20) NOT NULL,
     code_hash varchar(128) NOT NULL,
     expires_at timestamptz NOT NULL,
     attempts integer NOT NULL DEFAULT 0,
     created_at timestamptz NOT NULL DEFAULT now()
   )`,
  `CREATE INDEX IF NOT EXISTS otp_codes_phone_idx ON otp_codes (phone)`,
  `CREATE TABLE IF NOT EXISTS orders (
     id varchar(40) PRIMARY KEY,
     number varchar(32) NOT NULL,
     customer_name varchar(120) NOT NULL,
     phone varchar(20) NOT NULL,
     address jsonb NOT NULL,
     items jsonb NOT NULL,
     subtotal integer NOT NULL,
     delivery_fee integer NOT NULL,
     discount integer NOT NULL DEFAULT 0,
     total integer NOT NULL,
     promo_code varchar(40),
     payment_method varchar(20) NOT NULL DEFAULT 'cod',
     status varchar(32) NOT NULL DEFAULT 'placed',
     delivery_slot varchar(40) NOT NULL,
     note text NOT NULL DEFAULT '',
     ops_token varchar(64) NOT NULL,
     created_at timestamptz NOT NULL DEFAULT now(),
     updated_at timestamptz NOT NULL DEFAULT now()
   )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS orders_number_idx ON orders (number)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS orders_ops_token_idx ON orders (ops_token)`,
  `CREATE INDEX IF NOT EXISTS orders_phone_idx ON orders (phone)`,
];

export async function ensureSchema(): Promise<void> {
  if (done) return;
  if (inFlight) return inFlight;
  inFlight = (async () => {
    for (const statement of DDL) {
      await db.execute(sql.raw(statement));
    }
    done = true;
  })()
    .catch((err) => {
      console.error("[schema-init] could not ensure schema:", err);
      throw err;
    })
    .finally(() => {
      inFlight = null;
    });
  return inFlight;
}
