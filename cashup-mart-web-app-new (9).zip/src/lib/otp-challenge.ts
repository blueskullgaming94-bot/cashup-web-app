import { createHmac, randomInt, timingSafeEqual } from "crypto";
import { normalizePkPhone } from "./phone";

const COOKIE = "zx_otp";
const PATH = "/api/otp";
const TTL_MS = 5 * 60 * 1000;
const MAX_ATTEMPTS = 5;
const KEY = process.env.OTP_CHALLENGE_SECRET || process.env.SESSION_SECRET || "cashup-express-local-otp-secret-set-OTP_CHALLENGE_SECRET-in-production";

type Challenge = {
  phone: string;
  codeHash: string;
  issuedAt: number;
  expiresAt: number;
  attempts: number;
};

const requests = new Map<string, { last: number; start: number; count: number }>();

function digest(value: string) {
  return createHmac("sha256", KEY).update(value).digest("base64url");
}
function hashCode(phone: string, code: string) {
  return digest(`otp:${phone}:${code}`);
}
function safeEqual(a: string, b: string) {
  const left = Buffer.from(a);
  const right = Buffer.from(b);
  return left.length === right.length && timingSafeEqual(left, right);
}
function seal(challenge: Challenge) {
  const payload = Buffer.from(JSON.stringify(challenge)).toString("base64url");
  return `${payload}.${digest(payload)}`;
}

/** Sealed challenge token for the JSON response body (works without cookies). */
export function sealOtpChallenge(challenge: Challenge): string {
  return seal(challenge);
}

/** Validates a token from the request body or the cookie. Null when missing, tampered, expired or exhausted. */
export function parseOtpChallenge(token: string): Challenge | null {
  const dot = token.indexOf(".");
  if (dot < 1) return null;
  const payload = token.slice(0, dot);
  const signature = token.slice(dot + 1);
  if (!safeEqual(signature, digest(payload))) return null;
  try {
    const challenge = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as Challenge;
    if (
      !challenge || typeof challenge.phone !== "string" || typeof challenge.codeHash !== "string" ||
      !Number.isFinite(challenge.expiresAt) || !Number.isFinite(challenge.issuedAt) ||
      !Number.isInteger(challenge.attempts) || challenge.expiresAt <= Date.now() || challenge.attempts >= MAX_ATTEMPTS
    ) return null;
    return challenge;
  } catch {
    return null;
  }
}
function cookieAttributes(maxAge: number) {
  return `${COOKIE}=__VALUE__; Path=${PATH}; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${process.env.NODE_ENV === "production" ? "; Secure" : ""}`;
}
export function otpSetCookie(challenge: Challenge) {
  return cookieAttributes(Math.max(1, Math.ceil((challenge.expiresAt - Date.now()) / 1000))).replace("__VALUE__", seal(challenge));
}
export function otpClearCookie() {
  return cookieAttributes(0).replace("__VALUE__", "");
}
function cookieValue(request: Request) {
  const raw = request.headers.get("cookie") || "";
  const entry = raw.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${COOKIE}=`));
  return entry?.slice(COOKIE.length + 1) || "";
}
export function readOtpChallenge(request: Request): Challenge | null {
  const token = cookieValue(request);
  if (!token) return null;
  return parseOtpChallenge(token);
}

export function checkOtpSendLimit(request: Request, phoneInput: string): { ok: true } | { ok: false; error: string; retryAfter: number } {
  const phone = normalizePkPhone(phoneInput);
  const ip = (request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || "unknown").split(",")[0].trim();
  const keys = [`phone:${phone}`, `ip:${ip}`];
  const now = Date.now();
  for (const key of keys) {
    const item = requests.get(key);
    if (item && item.start + 60 * 60 * 1000 <= now) requests.delete(key);
  }
  const previous = requests.get(keys[0]);
  if (previous && now - previous.last < 45_000) {
    return { ok: false, error: "Please wait before requesting another code.", retryAfter: Math.ceil((45_000 - (now - previous.last)) / 1000) };
  }
  for (const key of keys) {
    const item = requests.get(key);
    if (item && item.count >= 5) {
      return { ok: false, error: "Too many code requests. Please try again later.", retryAfter: Math.ceil((item.start + 60 * 60 * 1000 - now) / 1000) };
    }
  }
  for (const key of keys) {
    const item = requests.get(key);
    requests.set(key, { last: now, start: item?.start ?? now, count: (item?.count ?? 0) + 1 });
  }
  return { ok: true };
}

export function makeOtpChallenge(phoneInput: string) {
  const phone = normalizePkPhone(phoneInput);
  const code = String(randomInt(100000, 1000000));
  const issuedAt = Date.now();
  const challenge: Challenge = { phone, codeHash: hashCode(phone, code), issuedAt, expiresAt: issuedAt + TTL_MS, attempts: 0 };
  return { code, challenge };
}

export function checkOtpCode(challenge: Challenge, phoneInput: string, codeInput: string): { ok: boolean; challenge: Challenge } {
  const next = { ...challenge, attempts: challenge.attempts + 1 };
  const phone = normalizePkPhone(phoneInput);
  const code = codeInput.trim();
  return { ok: phone === challenge.phone && safeEqual(hashCode(phone, code), challenge.codeHash), challenge: next };
}
