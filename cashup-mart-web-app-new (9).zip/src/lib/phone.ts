export function normalizePkPhone(input: string) {
  const digits = input.replace(/[^\d]/g, "");
  if (digits.startsWith("92") && digits.length === 12) return digits;
  if (digits.startsWith("0") && digits.length === 11) return `92${digits.slice(1)}`;
  if (digits.length === 10 && digits.startsWith("3")) return `92${digits}`;
  return digits;
}

export function isValidPkMobile(input: string) {
  const n = normalizePkPhone(input);
  return /^923\d{9}$/.test(n);
}

export function formatPkPhone(input: string) {
  const n = normalizePkPhone(input);
  if (!/^92\d{10}$/.test(n)) return input;
  return `+${n.slice(0, 2)} ${n.slice(2, 5)} ${n.slice(5, 12)}`;
}

export function displayPhone(input: string) {
  const n = normalizePkPhone(input);
  if (!/^92\d{10}$/.test(n)) return input;
  return `0${n.slice(2)}`;
}
