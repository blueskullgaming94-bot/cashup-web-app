import { formatMapAddress, reverseLookupUrl, type MapAddress, type NominatimAddress } from "./geocode";
import { isInsideKarachi } from "./karachi";

const apiBase = (process.env.NEXT_PUBLIC_API_BASE || "").replace(/\/$/, "");
const staticEndpoint = process.env.NEXT_PUBLIC_GEOCODER_URL || "https://nominatim.openstreetmap.org/reverse";
const cache = new Map<string, MapAddress>();
let directQueue: Promise<unknown> = Promise.resolve();
let lastDirectRequest = 0;

function aborted(signal?: AbortSignal) {
  if (signal?.aborted) throw new DOMException("Lookup cancelled", "AbortError");
}

/** User initiated only: call once when GPS settles or a pin is dropped, not on every pan. */
export async function reverseGeocode(
  lat: number,
  lng: number,
  preferredArea?: string,
  signal?: AbortSignal,
): Promise<MapAddress> {
  aborted(signal);
  if (!isInsideKarachi(lat, lng)) return formatMapAddress({}, lat, lng, preferredArea);
  const key = `${lat.toFixed(6)},${lng.toFixed(6)},${preferredArea ?? ""}`;
  const saved = cache.get(key);
  if (saved) return saved;
  if (!navigator.onLine) throw new Error("Your pin is saved in the form. Connect to the internet to fill street details, or type them below.");

  const controller = new AbortController();
  let timedOut = false;
  const cancel = () => controller.abort();
  signal?.addEventListener("abort", cancel, { once: true });
  const timer = setTimeout(() => { timedOut = true; controller.abort(); }, 14000);
  try {
    const params = new URLSearchParams({ lat: String(lat), lng: String(lng) });
    if (preferredArea) params.set("area", preferredArea);
    const res = await fetch(`${apiBase}/api/geocode?${params}`, {
      signal: controller.signal, cache: "no-store", headers: { Accept: "application/json" },
    });
    const isJson = res.headers.get("content-type")?.includes("application/json");
    if (res.ok && isJson) {
      const data = await res.json() as MapAddress;
      if (typeof data.details === "string" && typeof data.outside === "boolean") {
        cache.set(key, data);
        return data;
      }
      throw new Error("Map details were incomplete. Please enter your address manually.");
    }
    // Static EdgeOne/Capacitor bundles have no route handlers. The same documented
    // service is available through CORS, without sending contact/address input.
    if (!apiBase && (res.status === 404 || res.status === 405 || (res.ok && !isJson))) {
      const task = directQueue.catch(() => undefined).then(async () => {
        const wait = Math.max(0, 1100 - (Date.now() - lastDirectRequest));
        if (wait) await new Promise((resolve) => setTimeout(resolve, wait));
        aborted(controller.signal);
        lastDirectRequest = Date.now();
        const upstreamUrl = reverseLookupUrl(staticEndpoint, lat, lng);
        if (preferredArea) upstreamUrl.searchParams.set("area", preferredArea);
        const upstream = await fetch(upstreamUrl, {
          signal: controller.signal, credentials: "omit", headers: { Accept: "application/json" },
        });
        if (!upstream.ok) throw new Error("Map address lookup is unavailable. Please type your street details below.");
        const raw = await upstream.json() as NominatimAddress;
        if (raw.error) throw new Error("No street address is mapped at this pin. Please enter it manually.");
        const result = formatMapAddress(raw, lat, lng, preferredArea);
        if (!result.details) throw new Error("No street address is mapped at this pin. Please enter it manually.");
        return result;
      });
      directQueue = task.catch(() => undefined);
      const result = await task;
      cache.set(key, result);
      return result;
    }
    const error = isJson ? await res.json().catch(() => null) as { error?: string } | null : null;
    throw new Error(error?.error || "Map lookup is unavailable. Your pin has not been lost; enter your address below.");
  } catch (error) {
    if (signal?.aborted) throw new DOMException("Lookup cancelled", "AbortError");
    if (timedOut) throw new Error("Street lookup took too long. Your pin is selected; please type your address or try again.");
    if (error instanceof TypeError) throw new Error("Could not reach the address service. Please enter the details manually.");
    throw error;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", cancel);
  }
}
