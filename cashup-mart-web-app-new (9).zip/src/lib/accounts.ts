import { isValidPkMobile, normalizePkPhone } from "./phone";
import type { Address } from "./types";

/**
 * Device-local customer accounts (no server/database required).
 *
 * Accounts live in this browser's localStorage so a shopper can log back in on
 * the same device instead of re-entering details. Passwords are NEVER stored in
 * plain text: they are hashed with PBKDF2-SHA-256 (random salt, 150k iterations)
 * via the Web Crypto API. Because data is device-local, an account created on
 * one phone/browser is not available on another; clearing site data removes it.
 */
export type LocalAccount = {
  id: string;
  name: string;
  phone: string;
  email: string;
  avatar: string | null;
  verified: boolean;
  address: Address | null;
  savedAddresses: Address[];
  passwordHash: string;
  salt: string;
  iterations: number;
  createdAt: string;
  updatedAt: string;
};
export type PublicAccount = Omit<LocalAccount, "passwordHash" | "salt" | "iterations">;
export type AccountResult = { ok: true; account: PublicAccount } | { ok: false; error: string };

const ACCOUNTS_KEY = "cashup-accounts";
const SESSION_KEY = "cashup-session";
const ATTEMPTS_KEY = "cashup-login-attempts";
const ITERATIONS = 150_000;
const MAX_ATTEMPTS = 5;
const LOCK_MS = 60_000;
export const MIN_PASSWORD = 8;
const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,24}$/;

export class AccountError extends Error {}

export function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}
export function isValidEmail(email: string) {
  return EMAIL_RE.test(normalizeEmail(email));
}
export function passwordProblem(password: string): string | null {
  if (password.length < MIN_PASSWORD) return `Password must be at least ${MIN_PASSWORD} characters.`;
  if (password.length > 128) return "Password is too long (max 128 characters).";
  if (!/[a-z]/i.test(password) || !/\d/.test(password)) return "Use at least one letter and one number.";
  return null;
}

function storage(): Storage {
  if (typeof window === "undefined" || !window.localStorage) throw new AccountError("Storage is unavailable in this browser.");
  return window.localStorage;
}

function isAccount(value: unknown): value is LocalAccount {
  const a = value as LocalAccount;
  return Boolean(a && typeof a.id === "string" && typeof a.phone === "string" && typeof a.passwordHash === "string" && typeof a.salt === "string");
}

function loadAll(): LocalAccount[] {
  try {
    const raw = storage().getItem(ACCOUNTS_KEY);
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? list.filter(isAccount) : [];
  } catch {
    return [];
  }
}

function saveAll(list: LocalAccount[]) {
  try {
    storage().setItem(ACCOUNTS_KEY, JSON.stringify(list));
  } catch (error) {
    if (error instanceof AccountError) throw error;
    throw new AccountError("This device is out of storage space. Try a smaller profile photo or clear old site data.");
  }
}

export function toPublic(account: LocalAccount): PublicAccount {
  const { passwordHash: _h, salt: _s, iterations: _i, ...rest } = account;
  void _h; void _s; void _i;
  return rest;
}

function bytesToB64(bytes: Uint8Array) {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s);
}
function b64ToBytes(b64: string) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function sameHash(a: string, b: string) {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

async function hashPassword(password: string, salt: string, iterations: number) {
  const subtle = globalThis.crypto?.subtle;
  if (!subtle) throw new AccountError("Secure password storage needs an HTTPS connection. Open the site over https:// to use accounts.");
  const key = await subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: b64ToBytes(salt), iterations }, key, 256);
  return bytesToB64(new Uint8Array(bits));
}

function newSalt() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return bytesToB64(bytes);
}

function findByIdentifier(list: LocalAccount[], identifier: string) {
  const value = identifier.trim();
  if (value.includes("@")) {
    const email = normalizeEmail(value);
    return list.find((a) => a.email && a.email === email);
  }
  const phone = normalizePkPhone(value);
  return list.find((a) => a.phone === phone);
}

function conflict(list: LocalAccount[], selfId: string | null, phone: string, email: string): string | null {
  if (list.some((a) => a.id !== selfId && a.phone === phone)) return "An account with this mobile number already exists on this device. Log in instead.";
  if (email && list.some((a) => a.id !== selfId && a.email === email)) return "An account with this email already exists on this device. Log in instead.";
  return null;
}

/* ---------------------------------------------------------------- session */

export function getSessionAccount(): PublicAccount | null {
  try {
    const id = storage().getItem(SESSION_KEY);
    const account = id ? loadAll().find((a) => a.id === id) : undefined;
    return account ? toPublic(account) : null;
  } catch {
    return null;
  }
}
function setSession(id: string) {
  try { storage().setItem(SESSION_KEY, id); } catch { /* session simply won't persist */ }
}
export function clearSession() {
  try { storage().removeItem(SESSION_KEY); } catch { /* ignore */ }
}

/* ------------------------------------------------------- login throttling */

type Attempts = Record<string, { count: number; until: number }>;
function readAttempts(): Attempts {
  try { return JSON.parse(storage().getItem(ATTEMPTS_KEY) || "{}") as Attempts; } catch { return {}; }
}
function writeAttempts(value: Attempts) {
  try { storage().setItem(ATTEMPTS_KEY, JSON.stringify(value)); } catch { /* ignore */ }
}
function attemptKey(identifier: string) {
  return identifier.includes("@") ? normalizeEmail(identifier) : normalizePkPhone(identifier);
}

/* ----------------------------------------------------------------- actions */

export async function registerAccount(input: {
  name: string; phone: string; email?: string; password: string; avatar?: string | null;
  verified?: boolean; address?: Address | null; savedAddresses?: Address[];
}): Promise<AccountResult> {
  try {
    const name = input.name.trim();
    const phone = normalizePkPhone(input.phone);
    const email = input.email ? normalizeEmail(input.email) : "";
    if (!name) return { ok: false, error: "Enter your full name." };
    if (!isValidPkMobile(phone)) return { ok: false, error: "Enter a valid Pakistani mobile number (03xx…)." };
    if (email && !isValidEmail(email)) return { ok: false, error: "Enter a valid email address." };
    const weak = passwordProblem(input.password);
    if (weak) return { ok: false, error: weak };
    const list = loadAll();
    const clash = conflict(list, null, phone, email);
    if (clash) return { ok: false, error: clash };
    const salt = newSalt();
    const now = new Date().toISOString();
    const account: LocalAccount = {
      id: crypto.randomUUID(), name, phone, email,
      avatar: input.avatar ?? null, verified: Boolean(input.verified),
      address: input.address ?? null, savedAddresses: input.savedAddresses ?? [],
      passwordHash: await hashPassword(input.password, salt, ITERATIONS), salt, iterations: ITERATIONS,
      createdAt: now, updatedAt: now,
    };
    saveAll([...list, account]);
    setSession(account.id);
    return { ok: true, account: toPublic(account) };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : "Could not create the account." };
  }
}

export async function loginAccount(identifier: string, password: string): Promise<AccountResult> {
  try {
    if (!identifier.trim() || !password) return { ok: false, error: "Enter your mobile number or email and your password." };
    const key = attemptKey(identifier);
    const attempts = readAttempts();
    const state = attempts[key];
    if (state && state.until > Date.now()) {
      const seconds = Math.ceil((state.until - Date.now()) / 1000);
      return { ok: false, error: `Too many attempts. Please wait ${seconds}s and try again.` };
    }
    const account = findByIdentifier(loadAll(), identifier);
    // Always run the hash so timing doesn't reveal whether the account exists.
    const hash = await hashPassword(password, account?.salt ?? newSalt(), account?.iterations ?? ITERATIONS);
    if (!account || !sameHash(hash, account.passwordHash)) {
      const count = (state?.count ?? 0) + 1;
      attempts[key] = { count: count >= MAX_ATTEMPTS ? 0 : count, until: count >= MAX_ATTEMPTS ? Date.now() + LOCK_MS : 0 };
      writeAttempts(attempts);
      return { ok: false, error: "Incorrect mobile number/email or password." };
    }
    delete attempts[key];
    writeAttempts(attempts);
    setSession(account.id);
    return { ok: true, account: toPublic(account) };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : "Could not log in." };
  }
}

export function updateAccount(
  id: string,
  patch: Partial<Pick<LocalAccount, "name" | "phone" | "email" | "avatar" | "verified" | "address" | "savedAddresses">>,
): AccountResult {
  try {
    const list = loadAll();
    const index = list.findIndex((a) => a.id === id);
    if (index < 0) return { ok: false, error: "Account not found on this device. Please log in again." };
    const current = list[index];
    const next: LocalAccount = { ...current, ...patch, updatedAt: new Date().toISOString() };
    if (patch.name !== undefined) {
      next.name = patch.name.trim();
      if (!next.name) return { ok: false, error: "Enter your full name." };
    }
    if (patch.phone !== undefined) {
      next.phone = normalizePkPhone(patch.phone);
      if (!isValidPkMobile(next.phone)) return { ok: false, error: "Enter a valid Pakistani mobile number (03xx…)." };
    }
    if (patch.email !== undefined) {
      next.email = patch.email ? normalizeEmail(patch.email) : "";
      if (next.email && !isValidEmail(next.email)) return { ok: false, error: "Enter a valid email address." };
    }
    const clash = conflict(list, id, next.phone, next.email);
    if (clash) return { ok: false, error: clash };
    list[index] = next;
    saveAll(list);
    return { ok: true, account: toPublic(next) };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : "Could not save your profile." };
  }
}

export async function changePassword(id: string, currentPassword: string, nextPassword: string): Promise<AccountResult> {
  try {
    const list = loadAll();
    const index = list.findIndex((a) => a.id === id);
    if (index < 0) return { ok: false, error: "Account not found on this device. Please log in again." };
    const account = list[index];
    const check = await hashPassword(currentPassword, account.salt, account.iterations);
    if (!sameHash(check, account.passwordHash)) return { ok: false, error: "Your current password is incorrect." };
    const weak = passwordProblem(nextPassword);
    if (weak) return { ok: false, error: weak };
    const salt = newSalt();
    list[index] = {
      ...account, salt, iterations: ITERATIONS,
      passwordHash: await hashPassword(nextPassword, salt, ITERATIONS), updatedAt: new Date().toISOString(),
    };
    saveAll(list);
    return { ok: true, account: toPublic(list[index]) };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : "Could not change the password." };
  }
}
