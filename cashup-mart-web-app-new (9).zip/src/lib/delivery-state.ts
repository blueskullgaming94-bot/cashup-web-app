import { isInsideKarachi } from "./karachi";
import { hasRequiredAddressFields } from "./address-fields";
import { isValidPkMobile } from "./phone";
import type { Address, CustomerProfile } from "./types";

export const DELIVERY_PROMPT_KEY = "cashup-delivery-prompt-seen";
export type DeliveryPromptReason = "first-visit" | "cart" | "checkout" | "edit";

// In-memory backup keeps state usable if browser storage is blocked. It is only
// accessed on the client; it is not a server-side customer/session store.
const memory = new Map<string, unknown>();

export function readDeviceValue<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  for (const kind of ["localStorage", "sessionStorage"] as const) {
    try {
      const raw = window[kind].getItem(key);
      if (raw !== null) {
        const value = JSON.parse(raw) as T;
        memory.set(key, value);
        return value;
      }
    } catch {
      // One corrupt value / unavailable storage must not discard other details.
    }
  }
  return memory.has(key) ? (memory.get(key) as T) : fallback;
}

export function writeDeviceValue<T>(key: string, value: T): void {
  if (typeof window === "undefined") return;
  memory.set(key, value);
  for (const kind of ["localStorage", "sessionStorage"] as const) {
    try {
      window[kind].setItem(key, JSON.stringify(value));
    } catch {
      // Quota/private-mode failures must not prevent saving in React memory.
    }
  }
}

export function deliveryDetailsComplete(address: Address | null, profile: CustomerProfile | null): boolean {
  return Boolean(
    address && hasRequiredAddressFields(address) && typeof address.area === "string" && address.area.trim() &&
    typeof address.details === "string" && address.details.trim() &&
    isInsideKarachi(address.lat, address.lng) &&
    profile && typeof profile.name === "string" && profile.name.trim() &&
    typeof profile.phone === "string" && isValidPkMobile(profile.phone),
  );
}

export function shouldPromptForDelivery(reason: DeliveryPromptReason, complete: boolean, alreadySeen: boolean): boolean {
  if (reason === "edit") return true;
  if (complete) return false;
  return reason !== "first-visit" || !alreadySeen;
}
