export type LocationFix = { lat: number; lng: number; accuracy: number };
export type LocationFailureCode = "permission" | "unavailable" | "timeout" | "unsupported";

export class LocationError extends Error {
  constructor(public code: LocationFailureCode, message: string) { super(message); }
}

/**
 * A short, user-requested high-accuracy watch. Take the best reported fix, stop
 * at <=25m accuracy or after 12s, and ALWAYS stop the watch on abort/unmount.
 * Accuracy comes from the device; this cannot promise a house/flat GPS match.
 */
export function detectCurrentLocation({
  signal,
  onProgress,
  geolocation = typeof navigator === "undefined" ? undefined : navigator.geolocation,
  maxWait = 12000,
}: {
  signal: AbortSignal;
  onProgress?: (fix: LocationFix) => void;
  geolocation?: Geolocation;
  maxWait?: number;
}): Promise<LocationFix> {
  return new Promise((resolve, reject) => {
    if (signal.aborted) { reject(new DOMException("Location cancelled", "AbortError")); return; }
    if (!geolocation) { reject(new LocationError("unsupported", "This browser cannot locate you. Select an area or drag the pin.")); return; }
    let best: LocationFix | null = null;
    let watch: number | undefined;
    let finished = false;
    let timer: ReturnType<typeof setTimeout> | undefined;

    const cleanup = () => {
      if (watch !== undefined) geolocation.clearWatch(watch);
      if (timer) clearTimeout(timer);
      signal.removeEventListener("abort", cancel);
    };
    const finish = (error?: Error) => {
      if (finished) return;
      finished = true;
      cleanup();
      if (!error && best) resolve(best);
      else reject(error || new LocationError("timeout", "Could not get a GPS position in time. Try near a window, or drop the pin manually."));
    };
    const cancel = () => finish(new DOMException("Location cancelled", "AbortError"));
    signal.addEventListener("abort", cancel, { once: true });
    timer = setTimeout(() => finish(), maxWait);
    try {
      watch = geolocation.watchPosition((position) => {
        if (finished) return;
        const { latitude: lat, longitude: lng, accuracy } = position.coords;
        if (![lat, lng, accuracy].every(Number.isFinite) || accuracy < 0) return;
        if (!best || accuracy < best.accuracy) {
          best = { lat, lng, accuracy };
          onProgress?.(best);
        }
        if (best.accuracy <= 25) finish();
      }, (error) => {
        if (finished) return;
        if (error.code === 1) {
          finish(new LocationError("permission", "Location permission is blocked. Allow precise location in your browser settings, or select your address manually."));
        } else if (best) {
          finish();
        } else {
          finish(new LocationError(error.code === 3 ? "timeout" : "unavailable",
            error.code === 3 ? "GPS timed out. Try again near a window, or drop the pin manually." : "Your device could not get a location. Turn on location services, or drop the pin manually."));
        }
      }, { enableHighAccuracy: true, maximumAge: 0, timeout: maxWait });
      // Test doubles (and unusual implementations) may invoke success synchronously.
      if (finished) geolocation.clearWatch(watch);
    } catch {
      finish(new LocationError("unavailable", "Location access is unavailable. Use an HTTPS connection or drop the pin manually."));
    }
  });
}
