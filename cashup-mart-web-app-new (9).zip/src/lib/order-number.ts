/** Formats an order date as ddmmyy using UTC, matching order-number generation on server and device. */
export function formatOrderDate(date: Date): string {
  const [year, month, day] = date.toISOString().slice(0, 10).split("-");
  return `${day}${month}${year.slice(-2)}`;
}

/** Creates the customer-facing order number, e.g. CX-101026-4821. */
export function createOrderNumber(date = new Date()): string {
  const suffix = Math.floor(1000 + Math.random() * 9000);
  return `CX-${formatOrderDate(date)}-${suffix}`;
}
