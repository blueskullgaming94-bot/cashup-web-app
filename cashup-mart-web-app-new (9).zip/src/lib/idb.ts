const DB_NAME = "cashup-express";
const DB_VERSION = 1;

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains("kv")) db.createObjectStore("kv");
      if (!db.objectStoreNames.contains("cart")) db.createObjectStore("cart", { keyPath: "productId" });
      if (!db.objectStoreNames.contains("orders")) db.createObjectStore("orders", { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function txDone(tx: IDBTransaction) {
  return new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error);
  });
}

export async function idbGet<T>(key: string): Promise<T | undefined> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = db.transaction("kv").objectStore("kv").get(key);
    req.onsuccess = () => resolve(req.result as T | undefined);
    req.onerror = () => reject(req.error);
  });
}

export async function idbSet<T>(key: string, value: T) {
  const db = await openDb();
  const tx = db.transaction("kv", "readwrite");
  tx.objectStore("kv").put(value, key);
  await txDone(tx);
}

export async function idbGetCart(): Promise<{ productId: string; qty: number }[]> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = db.transaction("cart").objectStore("cart").getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

export async function idbSaveCart(items: { productId: string; qty: number }[]) {
  const db = await openDb();
  const tx = db.transaction("cart", "readwrite");
  const store = tx.objectStore("cart");
  store.clear();
  for (const item of items) store.put(item);
  await txDone(tx);
}

export async function idbGetOrders<T>(): Promise<T[]> {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const req = db.transaction("orders").objectStore("orders").getAll();
    req.onsuccess = () => resolve((req.result || []) as T[]);
    req.onerror = () => reject(req.error);
  });
}

export async function idbPutOrder<T extends { id: string }>(order: T) {
  const db = await openDb();
  const tx = db.transaction("orders", "readwrite");
  tx.objectStore("orders").put(order);
  await txDone(tx);
}
