import { isInsideKarachi } from "./karachi";
import type { Address } from "./types";
import type { MapAddress } from "./geocode";

export const REQUIRED_ADDRESS_FIELDS = ["houseNumber", "blockSector", "area"] as const;
export type RequiredAddressField = (typeof REQUIRED_ADDRESS_FIELDS)[number];
export type DeliveryFields = Record<RequiredAddressField, string> & { street: string };
export type AddressFieldErrors = Partial<Record<RequiredAddressField, string>>;
export const ADDRESS_LABELS: Record<RequiredAddressField, string> = {
  houseNumber: "House Number", blockSector: "Block/Sector", area: "Area",
};
export const ADDRESS_LIMITS: Record<RequiredAddressField, number> = { houseNumber: 100, blockSector: 100, area: 120 };

export function addressText(value: unknown): string {
  return typeof value === "string" ? value.trim().replace(/\s+/g, " ") : "";
}
function record(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : {};
}
function unique(parts: string[]) {
  const seen = new Set<string>();
  return parts.filter((part) => {
    const key = part.toLowerCase();
    if (!key || seen.has(key)) return false;
    seen.add(key); return true;
  });
}

/** Strict check for both the form and API; legacy free text alone is not enough. */
export function requiredAddressErrors(input: unknown): AddressFieldErrors {
  const value = record(input);
  const errors: AddressFieldErrors = {};
  for (const field of REQUIRED_ADDRESS_FIELDS) {
    const text = addressText(value[field]);
    if (!text) errors[field] = `${ADDRESS_LABELS[field]} is required. Please enter it manually.`;
    else if (text.length > ADDRESS_LIMITS[field]) errors[field] = `${ADDRESS_LABELS[field]} must be ${ADDRESS_LIMITS[field]} characters or fewer.`;
  }
  return errors;
}
export function hasRequiredAddressFields(input: unknown): boolean {
  return Object.keys(requiredAddressErrors(input)).length === 0;
}
export function formatAddressDetails(fields: DeliveryFields): string {
  return unique([fields.houseNumber, fields.street, fields.blockSector, fields.area].map(addressText)).join(", ");
}

/**
 * Read old saved text conservatively. A street number is never a house number;
 * missing components stay empty so the shopper can supply them once.
 * An explicitly empty structured field is intentional and is not reconstructed.
 */
export function fieldsFromSavedAddress(address: Address | null | undefined): DeliveryFields {
  const data = record(address);
  const text = addressText(data.details);
  const parts = text.split(",").map(addressText).filter(Boolean);
  const segments = unique(Array.from(text.matchAll(/\b(?:block|sector)\s*(?:no\.?\s*)?#?\s*[a-z0-9]+(?:[-/][a-z0-9]+)*/gi), (m) => m[0]));
  const first = parts[0] || "";
  const safeHouse = /\d/.test(first) && !/\b(street|st\.?|road|rd\.?|highway|shahrah|sector|block|district|division|sindh|pakistan|karachi|town)\b/i.test(first) ? first : "";
  const street = parts.find((part) => /\b(street|st\.?|road|rd\.?|lane|shahrah|khayaban)\b/i.test(part)) || "";
  return {
    houseNumber: "houseNumber" in data ? addressText(data.houseNumber) : safeHouse,
    blockSector: "blockSector" in data ? addressText(data.blockSector) : segments.join(", "),
    area: addressText(data.area),
    street: "street" in data ? addressText(data.street) : street,
  };
}

export function normalizeSavedAddress(address: Address | null | undefined): Address | null {
  if (!address || typeof address !== "object" || !Number.isFinite(address.lat) || !Number.isFinite(address.lng)) return null;
  return { ...address, ...fieldsFromSavedAddress(address) };
}

/** Structured map values only. No made-up house/sector; no approximate area accepted. */
export function fieldsFromMap(result: MapAddress): DeliveryFields {
  if (result.outside) return { houseNumber: "", blockSector: "", area: "", street: "" };
  // The provider may return a building name; only an actual house_number counts.
  const mappedHouse = result.components?.house_number;
  const houseNumber = addressText(mappedHouse !== undefined ? mappedHouse : result.hasHouseNumber ? result.houseNumber : "");
  return {
    houseNumber,
    blockSector: unique([addressText(result.block), addressText(result.sector)]).join(", "),
    area: result.areaIsApproximate ? "" : addressText(result.area),
    street: houseNumber ? "" : addressText(result.street),
  };
}

export function missingMappedFields(fields: DeliveryFields): RequiredAddressField[] {
  return REQUIRED_ADDRESS_FIELDS.filter((field) => !addressText(fields[field]));
}

/** Validate untrusted order addresses and derive summary text server-side. */
export function validateOrderAddress(input: unknown):
  | { ok: true; address: Address & DeliveryFields }
  | { ok: false; error: string; fieldErrors: AddressFieldErrors } {
  const data = record(input);
  const fieldErrors = requiredAddressErrors(data);
  if (Object.keys(fieldErrors).length) {
    return { ok: false, error: "House Number, Block/Sector and Area are all required.", fieldErrors };
  }
  if (typeof data.lat !== "number" || typeof data.lng !== "number" || !isInsideKarachi(data.lat, data.lng)) {
    return { ok: false, error: "We deliver only in Karachi right now. Select a Karachi pin.", fieldErrors: {} };
  }
  const fields: DeliveryFields = {
    houseNumber: addressText(data.houseNumber), blockSector: addressText(data.blockSector),
    area: addressText(data.area), street: addressText(data.street).slice(0, 180),
  };
  return {
    ok: true,
    address: {
      ...fields,
      label: addressText(data.label).slice(0, 80) || "Home",
      details: formatAddressDetails(fields), note: addressText(data.note).slice(0, 500),
      lat: data.lat, lng: data.lng,
      ...(typeof data.accuracyMeters === "number" && Number.isFinite(data.accuracyMeters) && data.accuracyMeters >= 0
        ? { accuracyMeters: data.accuracyMeters } : {}),
    },
  };
}
