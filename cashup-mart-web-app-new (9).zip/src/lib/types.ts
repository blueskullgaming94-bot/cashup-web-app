import type { OrderStatus } from "./config";

export type Category = {
  slug: string;
  name: string;
  icon: string;
  subcategories: string[];
  blurb: string;
};

export type Product = {
  id: string;
  slug: string;
  name: string;
  category: string;
  subcategory: string;
  brand: string;
  unit: string;
  price: number;
  salePrice: number | null;
  image: string;
  description: string;
  inStock: boolean;
  active: boolean;
  tags: Array<"popular" | "deal" | "new">;
};

export type Banner = {
  id: string;
  title: string;
  subtitle: string;
  image: string;
  href: string;
};

export type CartItem = {
  productId: string;
  qty: number;
};

export type Address = {
  id?: string;
  label: string;
  /** Optional only for older stored addresses. All new saves/orders require these. */
  houseNumber?: string;
  blockSector?: string;
  area: string;
  street?: string;
  /** Display summary derived from the structured fields. */
  details: string;
  note: string;
  lat: number;
  lng: number;
  /** Reported by the device, not an exact-address guarantee. */
  accuracyMeters?: number;
  mapAddress?: string;
};

export type CustomerProfile = {
  name: string;
  phone: string;
  verified: boolean;
};

export type OrderItemSnapshot = {
  productId: string;
  name: string;
  unit: string;
  qty: number;
  unitPrice: number;
  lineTotal: number;
  image: string;
};

export type Order = {
  /** Why an order is still queued on the device: no connection, or the store server rejected/failed it. */
  pendingReason?: "offline" | "server";
  id: string;
  number: string;
  customerName: string;
  phone: string;
  address: Address;
  items: OrderItemSnapshot[];
  subtotal: number;
  deliveryFee: number;
  discount: number;
  total: number;
  promoCode: string | null;
  paymentMethod: "cod";
  status: OrderStatus;
  deliverySlot: string;
  note: string;
  createdAt: string;
  updatedAt: string;
  pendingSync?: boolean;
};

export type CatalogPayload = {
  categories: Category[];
  products: Product[];
  banners: Banner[];
  updatedAt: string;
};
