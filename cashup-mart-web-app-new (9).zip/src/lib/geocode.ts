import { KARACHI_AREAS, isInsideKarachi, nearestArea } from "./karachi";

export type MapAddress = {
  lat: number;
  lng: number;
  area: string | null;
  areaIsApproximate: boolean;
  /** Concise, customer-facing address: house number (or street if none), block/sector, area. */
  details: string;
  displayName: string;
  components: Record<string, string>;
  houseNumber: string;
  street: string;
  block: string;
  sector: string;
  hasHouseNumber: boolean;
  hasStreet: boolean;
  outside: boolean;
  attribution: string;
};

export type NominatimAddress = {
  display_name?: string;
  name?: string;
  address?: Record<string, unknown>;
  extratags?: Record<string, unknown>;
  error?: string;
};

export const MAP_ATTRIBUTION = "© OpenStreetMap contributors";

function clean(value: unknown): string {
  return typeof value === "string" || typeof value === "number"
    ? String(value).trim().replace(/\s+/g, " ").slice(0, 180)
    : "";
}
function comparable(value: string) {
  return value.toLowerCase().replace(/[^\p{L}\p{N}]/gu, "");
}
function extractLabel(value: string, label: "block" | "sector"): string {
  if (!value) return "";
  const expression = label === "sector"
    ? /\bsector\s*(?:no\.?\s*)?(?:#\s*)?([a-z0-9]+(?:[-/]?[a-z0-9]+)*)/i
    : /\bblock\s*(?:no\.?\s*)?(?:#\s*)?([a-z0-9]+(?:[-/]?[a-z0-9]+)*)/i;
  const match = value.match(expression);
  if (!match) return "";
  const number = match[1].replace(/[-/]$/, "");
  return number ? `${label === "sector" ? "Sector" : "Block"} ${number}` : "";
}
function fromComponent(value: string, label: "block" | "sector"): string {
  if (!value) return "";
  if (new RegExp(`^${label}\\b`, "i").test(value)) return value;
  return `${label === "sector" ? "Sector" : "Block"} ${value}`;
}

/**
 * Reduce the nearest OSM object to delivery-useful detail only. Reverse geocoding
 * reports the nearest mapped road/building and is not proof that a house number
 * exactly matches the GPS point. Keep selected area priority and preserve the
 * input GPS point; never append highways, administrative districts or country.
 */
export function formatMapAddress(
  raw: NominatimAddress,
  lat: number,
  lng: number,
  preferredArea?: string | null,
): MapAddress {
  const components: Record<string, string> = {};
  for (const [key, value] of Object.entries(raw.address ?? {})) {
    const text = clean(value);
    if (text) components[key] = text;
  }
  for (const [key, value] of Object.entries(raw.extratags ?? {})) {
    if (!key.startsWith("addr:")) continue;
    const original = key.slice(5);
    const field = original === "housenumber" ? "house_number" : original === "housename" ? "house_name" : original;
    const text = clean(value);
    if (text && ["house_number", "house_name", "street", "block", "sector"].includes(field) && !components[field]) {
      components[field] = text;
    }
  }

  // Neighbourhood-level names only. Administrative towns/districts (e.g.
  // "Nazimabad District", "Manghopir Town") are deliberately excluded.
  const locality = [
    components.neighbourhood, components.suburb, components.quarter,
    components.residential, components.village, components.hamlet,
  ].filter(Boolean);
  const requested = clean(preferredArea);
  const preferred = KARACHI_AREAS.find((area) => comparable(area) === comparable(requested));
  const mappedArea = locality
    .flatMap((value) => KARACHI_AREAS.filter((area) => comparable(value).includes(comparable(area))))
    .sort((a, b) => b.length - a.length)[0] ?? null;
  // The map's own locality name (minus sector/block labels), e.g. "Sultanabad".
  const ownLocality = [components.suburb, components.quarter, components.residential, components.village, components.neighbourhood]
    .map((value) => clean((value || "").replace(/\b(?:sector|block)\s*(?:no\.?\s*)?#?\s*[a-z0-9-/]+/gi, "").replace(/[,\s]+$/, "")))
    .find((value) => value.length > 1) || "";
  const area = preferred ?? mappedArea ?? (ownLocality || (isInsideKarachi(lat, lng) ? nearestArea(lat, lng) : null));
  const areaIsApproximate = !preferred && !mappedArea && !ownLocality;

  const houseNumber = components.house_number || "";
  // Street name/number from the map; used when the pin has no house number.
  const street = components.road || components.street || components.pedestrian || components.lane ||
    components.footway || components.path || "";
  const rawBlock = components.block || "";
  const rawSector = components.sector || "";
  // Only keep a sector/block that belongs to the same locality as the area we
  // show — never pair a nearby object's "Sector 1" with a different area.
  const coherentLocality = preferred
    ? locality.some((value) => comparable(value).includes(comparable(preferred)))
    : true;
  const context = coherentLocality ? locality.join(", ") : "";
  const block = coherentLocality ? (rawBlock ? fromComponent(rawBlock, "block") : extractLabel(context, "block")) : "";
  const sector = coherentLocality ? (rawSector ? fromComponent(rawSector, "sector") : extractLabel(context, "sector")) : "";

  const parts: string[] = [];
  const seen = new Set<string>();
  for (const part of [houseNumber || street, block, sector, area ?? ""]) {
    const value = clean(part);
    const key = comparable(value);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    parts.push(value);
  }

  const countryCode = components.country_code?.toLowerCase();
  const outside = !isInsideKarachi(lat, lng) || Boolean(countryCode && countryCode !== "pk");
  return {
    lat,
    lng,
    area: outside ? null : area,
    areaIsApproximate,
    details: outside ? "" : parts.join(", "),
    displayName: parts.join(", "),
    components,
    houseNumber,
    street,
    block,
    sector,
    hasHouseNumber: Boolean(houseNumber),
    hasStreet: Boolean(street),
    outside,
    attribution: MAP_ATTRIBUTION,
  };
}

export function compactPreviouslyMappedAddress(fullAddress: string, selectedArea: string): string {
  const text = clean(fullAddress);
  if (!text) return "";
  const parts = text.split(",").map((part) => clean(part)).filter(Boolean);
  const house = parts.find((part) => /\d/.test(part) && !/\b(?:street|st\.?|road|rd\.?|highway|shahrah|karachi|district|division|sindh|pakistan|sector|block|town)\b/i.test(part)) ?? "";
  const block = extractLabel(text, "block");
  const sector = extractLabel(text, "sector");
  return [...new Set([house, block, sector, selectedArea].filter(Boolean))].join(", ");
}

export function reverseLookupUrl(base: string, lat: number, lng: number): URL {
  const url = new URL(base);
  url.searchParams.set("lat", String(lat));
  url.searchParams.set("lon", String(lng));
  url.searchParams.set("format", "jsonv2");
  url.searchParams.set("addressdetails", "1");
  url.searchParams.set("extratags", "1");
  url.searchParams.set("zoom", "18");
  url.searchParams.set("layer", "address");
  url.searchParams.set("accept-language", "en");
  return url;
}
