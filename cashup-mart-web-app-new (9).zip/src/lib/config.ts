export const STORE = {
  name: "CashUp Express",
  tagline: "Ghar ka Rashan, Dehleez Tak",
  city: "Karachi",
  currency: "PKR",
  currencySymbol: "Rs.",
  minOrderPkr: 300,
  deliveryFeePkr: 99,
  freeDeliveryPkr: 1499,
  asapMinutes: 45,
  supportWhatsApp: process.env.NEXT_PUBLIC_SUPPORT_WHATSAPP || "923001112223",
  supportPhone: process.env.NEXT_PUBLIC_SUPPORT_PHONE || "+92 300 111 2223",
  ownerWhatsApp: process.env.NEXT_PUBLIC_OWNER_WHATSAPP || process.env.OWNER_WHATSAPP || "923001112223",
  ownerEmail: process.env.OWNER_EMAIL || "orders@cashupexpress.pk",
  demoOtp: "123456",
} as const;

export const COLORS = {
  navy: "#1A1F2C",
  brand: "#2A4B9B",
  red: "#E52424",
  ice: "#9EC1E8",
  bg: "#EEF3FA",
  card: "#FFFFFF",
  muted: "#5B6B8C",
  success: "#16A34A",
  error: "#DC2626",
} as const;

export const ORDER_STATUSES = [
  "placed",
  "confirmed",
  "packing",
  "out_for_delivery",
  "delivered",
  "cancelled",
] as const;

export type OrderStatus = (typeof ORDER_STATUSES)[number];

export const STATUS_LABELS: Record<OrderStatus, string> = {
  placed: "Placed",
  confirmed: "Confirmed",
  packing: "Packing",
  out_for_delivery: "Out for delivery",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

export const DELIVERY_SLOTS = [
  { id: "asap", label: "As soon as possible", hint: `Usually ${STORE.asapMinutes} min` },
  { id: "today-eve", label: "Today, 6:00–8:00 pm", hint: "Evening slot" },
  { id: "tomorrow-morn", label: "Tomorrow, 10:00 am–12:00 pm", hint: "Morning slot" },
  { id: "tomorrow-eve", label: "Tomorrow, 6:00–8:00 pm", hint: "Evening slot" },
] as const;

export const PROMO_CODES = [
  {
    code: "CASHUP50",
    type: "flat" as const,
    value: 50,
    minSubtotal: 500,
    label: "Rs. 50 off on Rs. 500+",
  },
  {
    code: "WELCOME100",
    type: "flat" as const,
    value: 100,
    minSubtotal: 1000,
    label: "Rs. 100 off on Rs. 1,000+",
  },
  {
    code: "EXPRESS10",
    type: "percent" as const,
    value: 10,
    minSubtotal: 800,
    maxDiscount: 200,
    label: "10% off (max Rs. 200)",
  },
];
