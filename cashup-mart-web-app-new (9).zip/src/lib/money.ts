import { PROMO_CODES, STORE } from "./config";

export function formatPkr(amount: number) {
  const rounded = Math.round(amount);
  return `Rs. ${rounded.toLocaleString("en-PK")}`;
}

export function unitPrice(price: number, salePrice: number | null) {
  return salePrice && salePrice > 0 && salePrice < price ? salePrice : price;
}

export function deliveryFeeFor(subtotal: number) {
  if (subtotal >= STORE.freeDeliveryPkr) return 0;
  return STORE.deliveryFeePkr;
}

export function freeDeliveryRemaining(subtotal: number) {
  return Math.max(0, STORE.freeDeliveryPkr - subtotal);
}

export function applyPromo(code: string | null | undefined, subtotal: number) {
  if (!code) return { discount: 0, promo: null as (typeof PROMO_CODES)[number] | null, error: null as string | null };
  const promo = PROMO_CODES.find((p) => p.code === code.trim().toUpperCase());
  if (!promo) return { discount: 0, promo: null, error: "This promo code is not valid" };
  if (subtotal < promo.minSubtotal) {
    return {
      discount: 0,
      promo,
      error: `Add ${formatPkr(promo.minSubtotal - subtotal)} more to use ${promo.code}`,
    };
  }
  const raw = promo.type === "flat" ? promo.value : (subtotal * promo.value) / 100;
  const capped = "maxDiscount" in promo && promo.maxDiscount ? Math.min(raw, promo.maxDiscount) : raw;
  const discount = Math.min(Math.round(capped), subtotal);
  return { discount, promo, error: null };
}

export function totals(subtotal: number, promoCode?: string | null) {
  const promo = applyPromo(promoCode, subtotal);
  const deliveryFee = deliveryFeeFor(subtotal);
  const total = Math.max(0, subtotal - promo.discount + deliveryFee);
  return { ...promo, deliveryFee, total, subtotal };
}
