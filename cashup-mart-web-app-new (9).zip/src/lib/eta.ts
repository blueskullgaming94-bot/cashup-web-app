import { DELIVERY_SLOTS, STORE, type OrderStatus } from "./config";

export type EtaInput = {
  status: OrderStatus | string;
  pendingSync?: boolean;
  deliverySlot: string;
  createdAt: string;
  updatedAt: string;
};

/** Customer-facing arrival estimate. No step-by-step tracking — just when to expect the rider. */
export function orderEtaText(order: EtaInput): string {
  if (order.status === "cancelled") return "This order was cancelled — you won't be charged.";
  if (order.status === "delivered")
    return `Delivered · ${new Date(order.updatedAt).toLocaleString("en-PK", {
      day: "numeric",
      month: "short",
      hour: "numeric",
      minute: "2-digit",
    })}`;
  if (order.pendingSync) return "Arrival time appears here once the order reaches the store.";
  if (order.deliverySlot === "asap") {
    const eta = new Date(new Date(order.createdAt).getTime() + STORE.asapMinutes * 60000);
    return `Arriving by about ${eta.toLocaleTimeString("en-PK", { hour: "numeric", minute: "2-digit" })} (usually ~${STORE.asapMinutes} min)`;
  }
  const slot = DELIVERY_SLOTS.find((s) => s.id === order.deliverySlot);
  return slot ? `Scheduled · ${slot.label}` : `Slot: ${order.deliverySlot}`;
}
