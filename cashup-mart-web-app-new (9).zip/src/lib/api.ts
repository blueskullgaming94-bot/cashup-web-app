import { STORE } from "./config";
import { validateOrderAddress } from "./address-fields";
import { applyPromo, deliveryFeeFor, unitPrice } from "./money";
import { isInsideKarachi } from "./karachi";
import { safeFetch } from "./loader";
import type { Address, CatalogPayload, Order, OrderItemSnapshot, Product } from "./types";

/**
 * Single place for every network call.
 *
 * Results are explicit about *why* something failed so the UI never lies to the
 * customer: `offline: true` means "we could not reach a server" (queue the order
 * and retry automatically), `offline: false` means the server answered with a
 * real, fixable error (show the message, do NOT pretend it is a connection issue).
 *
 * When `NEXT_PUBLIC_API_BASE` is not set (static Edgio/EdgeOne drop) or the API
 * is unreachable, the app still works from the bundled catalog + IndexedDB.
 */
const BASE = (process.env.NEXT_PUBLIC_API_BASE || "").replace(/\/$/, "");
const url = (path: string) => `${BASE}${path}`;

export type ApiOk<T> = { ok: true; data: T };
export type ApiErr = { ok: false; error: string; offline: boolean; ticket?: string };
export type ApiResult<T> = ApiOk<T> | ApiErr;

const OFFLINE: ApiErr = { ok: false, error: "You are offline", offline: true };
const UNREACHABLE: ApiErr = { ok: false, error: "Could not reach the store server", offline: true };

async function call<T>(
  path: string,
  init?: RequestInit & { timeout?: number; retries?: number },
): Promise<ApiResult<T>> {
  if (typeof navigator !== "undefined" && !navigator.onLine) return OFFLINE;
  const res = await safeFetch(url(path), {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers || {}) },
  });
  if (!res) return UNREACHABLE;

  let payload: unknown = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }
  if (!res.ok) {
    const message =
      payload && typeof payload === "object" && "error" in payload
        ? String((payload as { error: unknown }).error)
        : `Request failed (${res.status})`;
    // A failed verify can rotate the stateless OTP ticket; hand it back so the
    // next attempt uses the current challenge instead of a stale one.
    const ticket =
      payload && typeof payload === "object" && "ticket" in payload && typeof (payload as { ticket: unknown }).ticket === "string"
        ? String((payload as { ticket: string }).ticket)
        : undefined;
    return { ok: false, error: message, offline: false, ...(ticket ? { ticket } : {}) };
  }
  return { ok: true, data: payload as T };
}

export async function fetchCatalog(): Promise<CatalogPayload | null> {
  const res = await call<CatalogPayload>("/api/catalog", { timeout: 12000 });
  return res.ok ? res.data : null;
}

export async function fetchOrders(phone: string): Promise<Order[] | null> {
  const res = await call<{ orders: Order[] }>(`/api/orders?phone=${encodeURIComponent(phone)}`);
  return res.ok ? res.data.orders : null;
}

/** `code` is only present when the server is configured to reveal it in the app. `ticket` proves the request. */
export type OtpSendResult = { ok?: boolean; code?: string; ticket?: string; gatewayStatus?: string; message?: string };

export async function sendOtp(phone: string): Promise<ApiResult<OtpSendResult>> {
  return call<OtpSendResult>("/api/otp/send", { method: "POST", body: JSON.stringify({ phone }), timeout: 15000 });
}

export async function verifyOtp(
  phone: string,
  code: string,
  name: string,
  ticket?: string,
): Promise<ApiResult<{ ok: boolean }>> {
  const res = await call<{ ok: boolean }>("/api/otp/verify", {
    method: "POST",
    body: JSON.stringify({ phone, code, name, ticket: ticket || undefined }),
  });
  // Offline / no backend: the on-device code verifies locally so
  // checkout never dead-ends on a static deployment.
  if (!res.ok && res.offline && code === STORE.demoOtp) return { ok: true, data: { ok: true } };
  return res;
}

export type PlaceOrderInput = {
  name: string;
  phone: string;
  address: Address;
  items: { productId: string; qty: number }[];
  promoCode?: string | null;
  deliverySlot: string;
  note: string;
};

/** Server-style validation, also usable fully offline against the cached catalog. */
export function priceOrder(products: Product[], input: PlaceOrderInput) {
  const checkedAddress = validateOrderAddress(input.address);
  if (!checkedAddress.ok) return { error: checkedAddress.error };
  if (!input.items.length) return { error: "Your cart is empty" as const };

  const snapshots: OrderItemSnapshot[] = [];
  let subtotal = 0;
  for (const line of input.items) {
    const p = products.find((x) => x.id === line.productId);
    if (!p || !p.active) return { error: "An item in your cart is no longer available" as const };
    if (!p.inStock) return { error: `${p.name} is out of stock` as const };
    const qty = Math.max(1, Math.min(20, line.qty));
    const price = unitPrice(p.price, p.salePrice);
    subtotal += price * qty;
    snapshots.push({
      productId: p.id,
      name: p.name,
      unit: p.unit,
      qty,
      unitPrice: price,
      lineTotal: price * qty,
      image: p.image,
    });
  }
  if (subtotal < STORE.minOrderPkr) {
    return { error: `Minimum order is Rs. ${STORE.minOrderPkr}` as const };
  }
  const promo = applyPromo(input.promoCode, subtotal);
  const deliveryFee = deliveryFeeFor(subtotal);
  const total = Math.max(0, subtotal - promo.discount + deliveryFee);
  return { error: null, items: snapshots, subtotal, deliveryFee, discount: promo.discount, total };
}

export async function placeOrder(input: PlaceOrderInput): Promise<ApiResult<{ order: Order }>> {
  return call<{ order: Order }>("/api/orders", {
    method: "POST",
    body: JSON.stringify(input),
    timeout: 20000,
    retries: 1,
  });
}

export async function cancelOrder(id: string, phone: string): Promise<ApiResult<{ order: Order }>> {
  return call<{ order: Order }>(`/api/orders/${id}`, {
    method: "POST",
    body: JSON.stringify({ action: "cancel", phone }),
  });
}

export function ownerWhatsAppLink(order: Order) {
  const lines = order.items.map((i) => `- ${i.qty}x ${i.name} (${i.unit}) Rs.${i.lineTotal}`).join("\n");
  const msg = `New CashUp Express order ${order.number}\n${order.customerName} ${order.phone}\n${order.address.area}, ${order.address.details}\n${lines}\nTOTAL COD Rs.${order.total}\nSlot: ${order.deliverySlot}`;
  return `https://wa.me/${STORE.ownerWhatsApp}?text=${encodeURIComponent(msg)}`;
}
