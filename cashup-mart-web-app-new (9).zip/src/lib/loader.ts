export type LoaderApi = {
  show: () => void;
  hide: () => void;
  wrap: <T>(p: Promise<T>) => Promise<T>;
};

declare global {
  interface Window {
    CashUpLoader?: LoaderApi;
  }
}

/** Safe access to the global preloader (works before hydration / without it). */
export const loader = {
  show() {
    if (typeof window === "undefined") return;
    window.CashUpLoader?.show();
  },
  hide() {
    if (typeof window === "undefined") return;
    window.CashUpLoader?.hide();
  },
  wrap<T>(p: Promise<T>): Promise<T> {
    if (typeof window === "undefined" || !window.CashUpLoader) return p;
    return window.CashUpLoader.wrap(p);
  },
};

/** fetch with a timeout + one retry, so slow networks never hang the UI. */
export async function safeFetch(
  input: string,
  init?: RequestInit & { timeout?: number; retries?: number },
): Promise<Response | null> {
  const timeout = init?.timeout ?? 9000;
  const retries = init?.retries ?? 1;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeout);
    try {
      const res = await fetch(input, { ...init, signal: ctrl.signal });
      clearTimeout(timer);
      return res;
    } catch {
      clearTimeout(timer);
      if (attempt === retries) return null;
    }
  }
  return null;
}
