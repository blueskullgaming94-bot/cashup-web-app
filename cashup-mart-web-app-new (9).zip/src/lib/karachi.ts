export const KARACHI_BOUNDS = {
  minLat: 24.74,
  maxLat: 25.17,
  minLng: 66.86,
  maxLng: 67.48,
};

export const KARACHI_CENTER = { lat: 24.885, lng: 67.05 };

/** Real-ish anchor points so the offline SVG map + nearest-area lookup work with no network. */
export const AREA_COORDS: Record<string, { lat: number; lng: number }> = {
  Clifton: { lat: 24.8138, lng: 67.0329 },
  "DHA Phase 1": { lat: 24.81, lng: 67.05 },
  "DHA Phase 2": { lat: 24.805, lng: 67.06 },
  "DHA Phase 4": { lat: 24.8, lng: 67.07 },
  "DHA Phase 5": { lat: 24.7925, lng: 67.0577 },
  "DHA Phase 6": { lat: 24.79, lng: 67.08 },
  "DHA Phase 8": { lat: 24.78, lng: 67.09 },
  PECHS: { lat: 24.87, lng: 67.05 },
  Bahadurabad: { lat: 24.87, lng: 67.07 },
  "Tariq Road": { lat: 24.845, lng: 67.045 },
  Saddar: { lat: 24.858, lng: 67.032 },
  Garden: { lat: 24.86, lng: 66.99 },
  "Soldier Bazaar": { lat: 24.86, lng: 67.02 },
  "Gulshan-e-Iqbal": { lat: 24.926, lng: 67.094 },
  "Gulistan-e-Jauhar": { lat: 24.91, lng: 67.15 },
  Gulberg: { lat: 24.9, lng: 67.07 },
  "Federal B Area": { lat: 24.91, lng: 67.06 },
  "North Nazimabad": { lat: 24.931, lng: 67.04 },
  Nazimabad: { lat: 24.91, lng: 67.02 },
  Hyderi: { lat: 24.94, lng: 67.04 },
  Liaquatabad: { lat: 24.9, lng: 67.03 },
  "North Karachi": { lat: 24.98, lng: 67.02 },
  "New Karachi": { lat: 24.97, lng: 67.03 },
  "Surjani Town": { lat: 25.02, lng: 67.01 },
  "Buffer Zone": { lat: 24.95, lng: 67.05 },
  "Scheme 33": { lat: 24.94, lng: 67.14 },
  "University Road": { lat: 24.92, lng: 67.11 },
  Malir: { lat: 24.9, lng: 67.21 },
  "Shah Faisal Colony": { lat: 24.87, lng: 67.17 },
  Korangi: { lat: 24.84, lng: 67.13 },
  Landhi: { lat: 24.85, lng: 67.21 },
  Kemari: { lat: 24.82, lng: 66.97 },
  Lyari: { lat: 24.85, lng: 66.99 },
  "Orangi Town": { lat: 24.9, lng: 66.94 },
  "Baldia Town": { lat: 24.9, lng: 66.89 },
  SITE: { lat: 24.87, lng: 66.98 },
  "PIB Colony": { lat: 24.91, lng: 67.07 },
  "Lines Area": { lat: 24.87, lng: 67.06 },
  Kharadar: { lat: 24.85, lng: 66.98 },
  "Burns Road": { lat: 24.86, lng: 67.01 },
  "Defence View": { lat: 24.82, lng: 67.07 },
  Cantt: { lat: 24.86, lng: 67.08 },
  Airport: { lat: 24.895, lng: 67.15 },
  "Gulshan-e-Maymar": { lat: 25.0, lng: 67.15 },
  "Safoora Goth": { lat: 24.91, lng: 67.22 },
};

export const KARACHI_AREAS = Object.keys(AREA_COORDS) as Array<keyof typeof AREA_COORDS>;

export type KarachiArea = string;

export function isInsideKarachi(lat: number, lng: number) {
  return (
    Number.isFinite(lat) &&
    Number.isFinite(lng) &&
    lat >= KARACHI_BOUNDS.minLat &&
    lat <= KARACHI_BOUNDS.maxLat &&
    lng >= KARACHI_BOUNDS.minLng &&
    lng <= KARACHI_BOUNDS.maxLng
  );
}

export function nearestArea(lat: number, lng: number): string {
  let best = "Saddar";
  let bestD = Infinity;
  for (const [name, c] of Object.entries(AREA_COORDS)) {
    const d = (c.lat - lat) ** 2 + (c.lng - lng) ** 2;
    if (d < bestD) {
      bestD = d;
      best = name;
    }
  }
  return best;
}

/** Karachi bounding box <-> 0..100 viewBox space (y flipped). */
export function toView(lat: number, lng: number) {
  const x = ((lng - KARACHI_BOUNDS.minLng) / (KARACHI_BOUNDS.maxLng - KARACHI_BOUNDS.minLng)) * 100;
  const y = (1 - (lat - KARACHI_BOUNDS.minLat) / (KARACHI_BOUNDS.maxLat - KARACHI_BOUNDS.minLat)) * 100;
  return { x: Math.max(0, Math.min(100, x)), y: Math.max(0, Math.min(100, y)) };
}

export function fromView(x: number, y: number) {
  const lng = KARACHI_BOUNDS.minLng + (x / 100) * (KARACHI_BOUNDS.maxLng - KARACHI_BOUNDS.minLng);
  const lat = KARACHI_BOUNDS.minLat + (1 - y / 100) * (KARACHI_BOUNDS.maxLat - KARACHI_BOUNDS.minLat);
  return { lat, lng };
}

export function areaFromQuery(query: string) {
  const q = query.trim().toLowerCase();
  if (!q) return null;
  return KARACHI_AREAS.find((area) => area.toLowerCase() === q) ?? null;
}

export function searchAreas(query: string) {
  const q = query.trim().toLowerCase();
  if (!q) return [...KARACHI_AREAS];
  return KARACHI_AREAS.filter((area) => area.toLowerCase().includes(q));
}

export const OUTSIDE_CITY_MESSAGE = "We deliver only in Karachi right now";
