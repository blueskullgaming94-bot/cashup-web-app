"use client";

import { ORDER_STATUSES, STATUS_LABELS, type OrderStatus } from "@/lib/config";
import { formatPkr } from "@/lib/money";
import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";

type OpsOrder = {
  number: string;
  customerName: string;
  phone: string;
  address: { area: string; details: string };
  items: { qty: number; name: string; lineTotal: number }[];
  total: number;
  status: OrderStatus;
  deliverySlot: string;
  note: string;
};

export default function OpsPage() {
  return (
    <Suspense fallback={<p className="p-6">Loading order…</p>}>
      <OpsInner />
    </Suspense>
  );
}

function OpsInner() {
  const token = useSearchParams().get("token") ?? "";
  const [order, setOrder] = useState<OpsOrder | null>(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch(`/api/ops/${token}`)
      .then((r) => r.json())
      .then((data) => {
        if (data.error) setError(data.error);
        else setOrder(data.order);
      })
      .catch(() => setError("Could not load order"));
  }, [token]);

  async function setStatus(status: OrderStatus) {
    setSaving(true);
    const res = await fetch(`/api/ops/${token}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    const data = await res.json();
    setSaving(false);
    if (!res.ok) {
      setError(data.error || "Update failed");
      return;
    }
    setOrder((o) => (o ? { ...o, status } : o));
  }

  if (error && !order) return <p className="p-6">{error}</p>;
  if (!order) return <p className="p-6">Loading order…</p>;

  return (
    <div className="mx-auto max-w-lg space-y-4 p-4">
      <p className="text-xs font-semibold uppercase tracking-wide text-zx-muted">Private store link</p>
      <h1 className="font-heading text-2xl font-bold">{order.number}</h1>
      <p className="text-sm">
        {order.customerName} · {order.phone}
        <br />
        {order.address.area} — {order.address.details}
      </p>
      <ul className="rounded-[16px] bg-zx-card p-4 text-sm">
        {order.items.map((i) => (
          <li key={i.name} className="flex justify-between">
            <span>
              {i.qty}× {i.name}
            </span>
            <span>{formatPkr(i.lineTotal)}</span>
          </li>
        ))}
        <li className="mt-2 flex justify-between font-heading font-bold">
          <span>COD total</span>
          <span>{formatPkr(order.total)}</span>
        </li>
      </ul>
      {order.note && <p className="text-sm">Note: {order.note}</p>}
      <p className="text-sm">Slot: {order.deliverySlot}</p>
      <div className="grid grid-cols-2 gap-2">
        {ORDER_STATUSES.map((s) => (
          <button
            key={s}
            type="button"
            disabled={saving}
            onClick={() => setStatus(s)}
            className={`min-h-11 rounded-xl text-sm font-semibold ${
              order.status === s ? "bg-zx-yellow text-white" : "bg-zx-card"
            }`}
          >
            {STATUS_LABELS[s]}
          </button>
        ))}
      </div>
    </div>
  );
}
