"use client";

import { Icon } from "@/components/Icon";
import { ProductGrid } from "@/components/catalog-ui";
import { useStore } from "@/components/store";
import { PageHeader } from "@/components/ui";
import { unitPrice } from "@/lib/money";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useMemo, useState } from "react";

function SearchInner() {
  const params = useSearchParams();
  const router = useRouter();
  const { catalog, recentSearches, pushSearch } = useStore();
  const initial = params.get("q") ?? "";
  const [q, setQ] = useState(initial);
  const [brand, setBrand] = useState("all");
  const [offers, setOffers] = useState(params.get("offers") === "1");
  const [sort, setSort] = useState(params.get("sort") ?? "popular");
  const [maxPrice, setMaxPrice] = useState(5000);

  const brands = useMemo(
    () => Array.from(new Set(catalog.products.map((p) => p.brand))).sort(),
    [catalog.products],
  );

  const suggestions = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (term.length < 2) return [];
    return catalog.products
      .filter((p) => p.name.toLowerCase().includes(term) || p.brand.toLowerCase().includes(term))
      .slice(0, 6);
  }, [q, catalog.products]);

  const results = useMemo(() => {
    const term = q.trim().toLowerCase();
    let list = catalog.products.filter((p) => p.active);
    if (term) {
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(term) ||
          p.brand.toLowerCase().includes(term) ||
          p.subcategory.toLowerCase().includes(term) ||
          p.category.includes(term),
      );
    }
    if (brand !== "all") list = list.filter((p) => p.brand === brand);
    if (offers) list = list.filter((p) => p.salePrice && p.salePrice < p.price);
    list = list.filter((p) => unitPrice(p.price, p.salePrice) <= maxPrice);
    const by = (a: number, b: number) => a - b;
    if (sort === "price-asc") list = [...list].sort((a, b) => by(unitPrice(a.price, a.salePrice), unitPrice(b.price, b.salePrice)));
    if (sort === "price-desc") list = [...list].sort((a, b) => by(unitPrice(b.price, b.salePrice), unitPrice(a.price, a.salePrice)));
    if (sort === "popular") list = [...list].sort((a, b) => Number(b.tags.includes("popular")) - Number(a.tags.includes("popular")));
    if (sort === "new") list = [...list].sort((a, b) => Number(b.tags.includes("new")) - Number(a.tags.includes("new")));
    return list;
  }, [catalog.products, q, brand, offers, sort, maxPrice]);

  function run(term: string) {
    const value = term.trim();
    if (!value) return;
    pushSearch(value);
    setQ(value);
    router.replace(`/search?q=${encodeURIComponent(value)}`);
  }

  return (
    <div>
      <PageHeader title="Search" back="" onClose={() => router.push("/")} />
      <div className="pt-3">
        <form
          className="mx-4 mb-3 flex items-center gap-2 rounded-full bg-zx-card px-3 shadow-[0_8px_24px_rgba(26,31,44,0.06)]"
          onSubmit={(e) => {
            e.preventDefault();
            run(q);
          }}
        >
          <Icon name="search" size={20} />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search milk, atta, eggs…"
            className="h-12 w-full bg-transparent outline-none"
            autoFocus
            aria-label="Search products"
          />
          {q && (
            <button type="button" onClick={() => setQ("")} aria-label="Clear search">
              <Icon name="close" size={18} className="text-zx-muted" />
            </button>
          )}
        </form>

        {q.length > 1 && (
          <ul className="zx-fade mx-4 mb-3 overflow-hidden rounded-[16px] bg-zx-card">
            {suggestions.map((s) => (
              <li key={s.id}>
                <button
                  type="button"
                  className="zx-row-link flex min-h-11 w-full items-center gap-2 px-3 text-left text-sm"
                  onClick={() => run(s.name)}
                >
                  <Icon name="search" size={16} className="text-zx-muted" /> {s.name}
                  <span className="ml-auto text-xs text-zx-muted">{s.unit}</span>
                </button>
              </li>
            ))}
            {!suggestions.length && <li className="px-3 py-3 text-sm text-zx-muted">No suggestions</li>}
          </ul>
        )}

        {recentSearches.length > 0 && (
          <div className="mb-3 px-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-zx-muted">Recent searches</p>
            <div className="flex flex-wrap gap-2">
              {recentSearches.map((s) => (
                <button key={s} type="button" className="zx-chip" onClick={() => run(s)}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="no-scrollbar mb-3 flex items-center gap-2 overflow-x-auto px-4">
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value)}
            className="zx-chip appearance-none pr-6"
            aria-label="Sort"
          >
            <option value="popular">Popular</option>
            <option value="price-asc">Price: low to high</option>
            <option value="price-desc">Price: high to low</option>
            <option value="new">New</option>
          </select>
          <select
            value={brand}
            onChange={(e) => setBrand(e.target.value)}
            className="zx-chip appearance-none pr-6"
            aria-label="Brand"
          >
            <option value="all">All brands</option>
            {brands.map((b) => (
              <option key={b} value={b}>
                {b}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => setOffers((v) => !v)}
            className={`zx-chip ${offers ? "on" : ""}`}
            aria-pressed={offers}
          >
            Offers
          </button>
          <label className="flex h-10 shrink-0 items-center gap-2 rounded-full bg-zx-card px-3 text-xs font-semibold">
            ≤ Rs.{maxPrice}
            <input
              type="range"
              min={50}
              max={5000}
              step={50}
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="accent-zx-yellow"
            />
          </label>
        </div>

        <p className="mb-2 px-4 text-xs font-semibold text-zx-muted">{results.length} results</p>
        <ProductGrid key={`${q}-${sort}-${brand}-${offers}-${maxPrice}`} products={results} />
      </div>
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="zx-skel mx-4 my-4 h-40" />}>
      <SearchInner />
    </Suspense>
  );
}
