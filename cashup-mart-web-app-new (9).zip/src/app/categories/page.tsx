"use client";

import { CategoryGrid, CategoryIcon3D } from "@/components/catalog-ui";
import { Icon } from "@/components/Icon";
import { useStore } from "@/components/store";
import { PageHeader } from "@/components/ui";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function CategoriesPage() {
  const router = useRouter();
  const { catalog } = useStore();
  return (
    <div>
      <PageHeader title="Categories" back="" onClose={() => router.push("/")} />
      <div className="pt-4">
        <p className="mb-4 px-4 text-sm text-zx-muted">
          Groceries and daily essentials · no cooked or restaurant food
        </p>
        <CategoryGrid categories={catalog.categories} />
        <div className="zx-stagger mt-6 space-y-2 px-4 pb-4">
          {catalog.categories.map((c, i) => {
            const count = catalog.products.filter((p) => p.category === c.slug).length;
            return (
              <Link
                key={c.slug}
                href={`/categories/${c.slug}`}
                className="zx-card zx-row-link flex items-center gap-3 p-3"
                style={{ ["--i" as string]: i }}
              >
                <span className="zx-cat3d-cell grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-gradient-to-b from-white to-zx-bg ring-1 ring-zx-line/30">
                  <CategoryIcon3D slug={c.slug} size={38} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-semibold">{c.name}</span>
                  <span className="block truncate text-xs text-zx-muted">{c.blurb}</span>
                </span>
                <span className="shrink-0 text-xs font-semibold text-zx-muted">{count}</span>
                <Icon name="chevron-right" size={18} className="shrink-0 text-zx-muted" />
              </Link>
            );
          })}
        </div>
      </div>
    </div>
  );
}
