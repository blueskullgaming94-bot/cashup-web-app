import { CategoryBody } from "@/components/category-body";
import { categories, products } from "@/data/catalog";
import type { Metadata } from "next";

export function generateStaticParams() {
  return categories.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const c = categories.find((x) => x.slug === slug);
  const count = products.filter((p) => p.category === slug).length;
  return {
    title: c?.name ?? "Category",
    description: c ? `${c.blurb} · ${count} items delivered in Karachi.` : "Category at CashUp Express.",
  };
}

export default function CategoryPage() {
  return <CategoryBody />;
}
