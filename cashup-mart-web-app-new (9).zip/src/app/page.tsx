"use client";

import { BannerCarousel, CategoryStrip, ProductRow } from "@/components/catalog-ui";
import { FoodpandaHomeServices } from "@/components/FoodpandaHomeServices";
import { InstallPrompt } from "@/components/shell";
import { useStore } from "@/components/store";
import { STORE } from "@/lib/config";
import { formatPkr } from "@/lib/money";
import { Icon } from "@/components/Icon";
import Link from "next/link";

export default function HomePage() {
  const { catalog, lastUpdated, online, orders, address, setLocationModalOpen } = useStore();
  const products = catalog.products.filter((p) => p.active);
  const popular = products.filter((p) => p.tags.includes("popular"));
  const deals = products.filter((p) => p.salePrice && p.salePrice < p.price);
  const fresh = products.filter((p) => p.tags.includes("new"));
  const lastIds = orders.find((o) => !o.pendingSync)?.items.map((i) => i.productId) ?? [];
  const again = products.filter((p) => lastIds.includes(p.id));

  return (
    <div className="pt-2 sm:pt-4">
      <InstallPrompt />

      {/* Hero Sliders (Foodpanda Mart promotional banners) */}
      <BannerCarousel banners={catalog.banners} />

      {/* Foodpanda Mart 2x2 Service Cards (Groceries, Fresh Farm, Dairy, Halal Meat) */}
      <FoodpandaHomeServices />

      {/* Main Category Grid with icons */}
      <section className="mb-4">
        <div className="mb-2 flex items-center justify-between px-3 sm:px-4">
          <h2 className="font-heading text-sm sm:text-base font-bold text-zx-ink">Explore Categories</h2>
          <Link href="/categories" className="flex items-center text-xs font-bold text-zx-ink hover:text-zx-yellow">
            See all <Icon name="chevron-right" size={14} />
          </Link>
        </div>
        <CategoryStrip categories={catalog.categories} />
      </section>

      {/* Value Proposition Highlights Banner */}
      <div className="mx-3 sm:mx-4 mb-5 grid grid-cols-3 gap-2 rounded-2xl bg-zx p-3 text-white shadow-sm">
        <Perk icon="delivery" title={`~${STORE.asapMinutes} min`} text="Fast Karachi Delivery" />
        <Perk icon="offers" title="COD Only" text="Exact Cash at Door" />
        <Perk icon="offline" title="Offline PWA" text="Saved Locally" />
      </div>

      {/* Horizontal Product Rows with responsive cards */}
      <ProductRow title="Popular right now" products={popular} href="/search?sort=popular" />
      <ProductRow title="Today's Hot Deals" products={deals} href="/offers" />
      {again.length > 0 && <ProductRow title="Order again" products={again} href="/orders" />}
      <ProductRow title="New arrivals" products={fresh} href="/search?sort=new" />

      {/* Information Footer block */}
      <section className="mx-3 sm:mx-4 mt-4 mb-6 rounded-2xl bg-zx-card p-4 border border-zx-line/40 shadow-xs">
        <div className="flex items-center gap-2 mb-2">
          <div className="h-6 w-6 rounded-full bg-zx-yellow grid place-items-center text-white">
            <Icon name="check" size={14} />
          </div>
          <h3 className="font-heading font-bold text-sm text-zx-ink">CashUp Express — Karachi Only</h3>
        </div>
        <ul className="space-y-1.5 text-xs text-zx-muted">
          <li className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-zx-yellow" />
            Minimum order {formatPkr(STORE.minOrderPkr)} · Flat delivery {formatPkr(STORE.deliveryFeePkr)} (Free above {formatPkr(STORE.freeDeliveryPkr)})
          </li>
          <li className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-zx-yellow" />
            Cash on Delivery only · Please keep exact change ready for rider
          </li>
          <li className="flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-zx-yellow" />
            Mart & daily essentials delivered across Karachi
          </li>
        </ul>

        <div className="mt-3 pt-3 border-t border-zx-line/40 flex items-center justify-between text-[11px] text-zx-muted">
          <span className="flex items-center gap-1.5">
            <span className={`h-2 w-2 rounded-full ${online ? "bg-zx-success" : "bg-zx-error"}`} />
            {online ? "Live Catalog" : "Offline Storage Mode"}
          </span>
          {lastUpdated && <span>Updated {new Date(lastUpdated).toLocaleTimeString("en-PK", { hour: '2-digit', minute: '2-digit' })}</span>}
        </div>
      </section>
    </div>
  );
}

function Perk({ icon, title, text }: { icon: string; title: string; text: string }) {
  return (
    <div className="flex flex-col items-center text-center p-1">
      <div className="grid h-8 w-8 place-items-center rounded-full bg-zx-yellow text-white mb-1">
        <Icon name={icon} size={16} />
      </div>
      <span className="font-heading text-[11px] font-bold text-white leading-none mb-0.5">{title}</span>
      <span className="text-[9px] text-white/70 leading-tight">{text}</span>
    </div>
  );
}
