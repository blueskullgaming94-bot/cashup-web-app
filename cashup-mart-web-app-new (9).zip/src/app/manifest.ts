import type { MetadataRoute } from "next";

export const dynamic = "force-static";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "CashUp Express",
    short_name: "CashUp",
    description: "Ghar ka Rashan, Dehleez Tak. Groceries delivered in Karachi.",
    start_url: "/",
    display: "standalone",
    background_color: "#1A1F2C",
    theme_color: "#2A4B9B",
    lang: "en",
    icons: [
      { src: "/images/pwa/icon-192.png", sizes: "192x192", type: "image/png" },
      { src: "/images/pwa/icon-512.png", sizes: "512x512", type: "image/png" },
      {
        src: "/images/pwa/maskable-192.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "maskable",
      },
      {
        src: "/images/pwa/maskable-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  };
}
