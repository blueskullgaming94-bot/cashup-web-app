"use client";

import { AuthPanel, AvatarPicker } from "@/components/AuthForms";
import { Icon } from "@/components/Icon";
import { LocationPicker } from "@/components/location";
import { useStore } from "@/components/store";
import { SwipeToDelete } from "@/components/SwipeToDelete";
import { PageHeader, useToast } from "@/components/ui";
import { MIN_PASSWORD } from "@/lib/accounts";
import { displayPhone } from "@/lib/phone";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function AccountPage() {
  const router = useRouter();
  const toast = useToast();
  const { account, savedAddresses, address, profile, removeSavedAddress } = useStore();
  const [showAdd, setShowAdd] = useState(false);
  const others = savedAddresses.filter((a) => !(address && a.area === address.area && a.details === address.details));

  return (
    <div>
      <PageHeader title="Account" back="" onClose={() => router.push("/")} />
      <div className="mx-auto max-w-2xl space-y-3 p-4">
        {account ? <ProfileCard /> : (
          <section className="zx-card p-4">
            <h2 className="font-heading text-lg font-bold">Log in or create an account</h2>
            <p className="mb-4 mt-1 text-xs text-zx-muted">
              Save your photo, contact and addresses so you only log in next time — no need to register again.
            </p>
            <AuthPanel />
          </section>
        )}

        {account && <PasswordCard />}

        <section id="addresses" className="zx-card p-4">
          <div className="flex items-center justify-between">
            <h2 className="font-heading font-bold">Saved addresses</h2>
            <button type="button" className="min-h-9 text-sm font-semibold" onClick={() => setShowAdd((v) => !v)}>
              {showAdd ? "Close" : "Add new"}
            </button>
          </div>
          {!address && savedAddresses.length === 0 && (
            <p className="mt-2 text-sm text-zx-muted">No saved address yet.</p>
          )}
          {others.length > 0 && (
            <p className="mt-1 text-xs text-zx-muted">Swipe an address to the right to delete it.</p>
          )}
          <ul className="mt-2 space-y-2 text-sm">
            {address && (
              <li className="rounded-xl bg-zx-bg p-3">
                <div className="flex items-center gap-2 font-semibold">
                  <Icon name="location" size={16} />
                  <span className="min-w-0 truncate">{address.label} · {address.area}</span>
                  <span className="ml-auto shrink-0 rounded-full bg-zx-yellow px-2 text-[10px] font-bold">DEFAULT</span>
                </div>
                <div className="mt-1 break-words text-zx-muted">{address.details}</div>
                {address.note && <div className="text-xs text-zx-muted">Note: {address.note}</div>}
              </li>
            )}
            {others.map((a) => (
              <li key={`${a.area}-${a.details}`}>
                <SwipeToDelete
                  label={`${a.label}, ${a.area}`}
                  onDelete={() => {
                    if (removeSavedAddress(a)) toast({ kind: "info", title: "Address deleted", body: `${a.label} · ${a.area}` });
                  }}
                >
                  <div className="p-3">
                    <div className="font-semibold">{a.label} · {a.area}</div>
                    <div className="break-words text-zx-muted">{a.details}</div>
                  </div>
                </SwipeToDelete>
              </li>
            ))}
          </ul>
          {showAdd && (
            <div className="mt-4 rounded-xl bg-zx-bg p-2">
              <LocationPicker variant="embed" showContact={!profile} onDone={() => setShowAdd(false)} onClose={() => setShowAdd(false)} />
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

function ProfileCard() {
  const toast = useToast();
  const { account, updateAccountProfile, logout, profile } = useStore();
  const [avatar, setAvatar] = useState<string | null>(account?.avatar ?? null);
  const [name, setName] = useState(account?.name ?? "");
  const [phone, setPhone] = useState(account ? displayPhone(account.phone) : "");
  const [email, setEmail] = useState(account?.email ?? "");
  const [error, setError] = useState("");

  useEffect(() => {
    setAvatar(account?.avatar ?? null);
    setName(account?.name ?? "");
    setPhone(account ? displayPhone(account.phone) : "");
    setEmail(account?.email ?? "");
  }, [account?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!account) return null;

  function save() {
    setError("");
    const result = updateAccountProfile({ name, phone, email, avatar });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    toast({ kind: "success", title: "Profile saved" });
  }

  function changeAvatar(next: string | null) {
    setAvatar(next);
    // Photo changes save immediately so they aren't lost.
    const result = updateAccountProfile({ avatar: next });
    if (!result.ok) setError(result.error);
    else toast({ kind: "success", title: next ? "Profile photo updated" : "Profile photo removed" });
  }

  return (
    <section className="zx-card p-4">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <h2 className="font-heading text-lg font-bold">Your profile</h2>
          <p className="text-xs text-zx-muted">Saved on this device. Log in here anytime.</p>
        </div>
        <button
          type="button"
          className="zx-btn zx-btn-dark h-10 min-h-10 shrink-0 px-4 text-sm"
          onClick={() => {
            logout();
            toast({ kind: "info", title: "Logged out", body: "Your details are safe in your account." });
          }}
        >
          Log out
        </button>
      </div>
      <AvatarPicker value={avatar} onChange={changeAvatar} name={name} />
      <div className="mt-4 space-y-2">
        <div>
          <label htmlFor="acc-name" className="mb-1 block text-xs font-semibold text-zx-muted">Full name</label>
          <input id="acc-name" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" className="zx-input bg-zx-bg" />
        </div>
        <div>
          <label htmlFor="acc-phone" className="mb-1 block text-xs font-semibold text-zx-muted">Mobile number</label>
          <input id="acc-phone" value={phone} onChange={(e) => setPhone(e.target.value)} inputMode="tel" autoComplete="tel" className="zx-input bg-zx-bg" />
        </div>
        <div>
          <label htmlFor="acc-email" className="mb-1 block text-xs font-semibold text-zx-muted">Email</label>
          <input id="acc-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" placeholder="you@email.com" className="zx-input bg-zx-bg" />
        </div>
      </div>
      {profile?.verified && (
        <p className="mt-2 flex items-center gap-1.5 text-sm text-zx-success"><Icon name="check" size={16} /> Phone verified</p>
      )}
      {error && <p role="alert" className="mt-2 rounded-xl bg-zx-error/10 px-3 py-2 text-sm font-semibold text-zx-error">{error}</p>}
      <button type="button" className="zx-btn mt-3 w-full" onClick={save}>Save profile</button>
    </section>
  );
}

function PasswordCard() {
  const toast = useToast();
  const { changeAccountPassword } = useStore();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (next !== confirm) return setError("New passwords don't match.");
    setBusy(true);
    const result = await changeAccountPassword(current, next);
    setBusy(false);
    if (!result.ok) return setError(result.error);
    setCurrent(""); setNext(""); setConfirm("");
    toast({ kind: "success", title: "Password changed" });
  }

  return (
    <section className="zx-card p-4">
      <h2 className="font-heading font-bold">Change password</h2>
      <form onSubmit={submit} className="mt-3 space-y-2" aria-label="Change password">
        {([
          ["Current password", current, setCurrent, "current-password"],
          ["New password", next, setNext, "new-password"],
          ["Confirm new password", confirm, setConfirm, "new-password"],
        ] as const).map(([label, value, set, auto]) => (
          <div key={label}>
            <label className="mb-1 block text-xs font-semibold text-zx-muted" htmlFor={`pw-${label}`}>{label}</label>
            <input id={`pw-${label}`} type="password" value={value} onChange={(e) => set(e.target.value)} autoComplete={auto} className="zx-input bg-zx-bg" />
          </div>
        ))}
        <p className="text-[11px] text-zx-muted">At least {MIN_PASSWORD} characters with a letter and a number.</p>
        {error && <p role="alert" className="rounded-xl bg-zx-error/10 px-3 py-2 text-sm font-semibold text-zx-error">{error}</p>}
        <button type="submit" className="zx-btn zx-btn-dark w-full" disabled={busy}>{busy ? "Saving…" : "Update password"}</button>
      </form>
    </section>
  );
}
