"use client";

import { Icon } from "@/components/Icon";
import { useStore } from "@/components/store";
import { PageHeader, SmartImage, useToast } from "@/components/ui";
import { cancelOrder, ownerWhatsAppLink } from "@/lib/api";
import { STATUS_LABELS, STORE, type OrderStatus } from "@/lib/config";
import { orderEtaText } from "@/lib/eta";
import { loader } from "@/lib/loader";
import { formatPkr } from "@/lib/money";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";

export default function OrderDetailPage() {
  return (
    <Suspense fallback={<div className="zx-skel mx-4 my-4 h-40" />}>
      <OrderInner />
    </Suspense>
  );
}

function OrderInner() {
  const id = useSearchParams().get("id") ?? "";
  const router = useRouter();
  const toast = useToast();
  const { orders, rememberOrder, retryOrder, addToCart, online } = useStore();
  const [error, setError] = useState("");
  const [retrying, setRetrying] = useState(false);
  const found = orders.find((o) => o.id === id);

  if (!found) {
    return (
      <div>
        <PageHeader title="Order" back="" onClose={() => router.push("/orders")} />
        <p className="p-6 text-sm text-zx-muted">
          This order is not saved on this device. Open Orders while online to refresh the list.
        </p>
      </div>
    );
  }

  const order = found;
  const status = order.status as OrderStatus;
  const canCancel = status === "placed" || status === "confirmed";

  const eta = orderEtaText(order);

  async function handleCancel() {
    if (!online) {
      setError("Connect to the internet to cancel — live status cannot change offline.");
      toast({ kind: "offline", title: "Needs internet", body: "Cancel is a live action" });
      return;
    }
    const res = await loader.wrap(cancelOrder(order.id, order.phone));
    if (!res.ok) {
      setError(res.error);
      toast({ kind: res.offline ? "offline" : "error", title: res.error });
      return;
    }
    rememberOrder(res.data.order);
    setError("");
    toast({ kind: "info", title: "Order cancelled", body: "You will not be charged" });
  }

  async function handleRetry() {
    setError("");
    setRetrying(true);
    const res = await loader.wrap(retryOrder(order.id));
    setRetrying(false);
    if (!res.ok) {
      setError(res.error);
      toast({
        kind: res.offline ? "offline" : "error",
        title: res.offline ? "Still offline" : "Could not send",
        body: res.error,
      });
      return;
    }
    toast({ kind: "order", title: `Order ${res.order.number} sent`, body: "The store has your order" });
  }

  function handleReorder() {
    for (const item of order.items) addToCart(item.productId, item.qty);
    toast({ kind: "cart", title: "Items added to cart", body: `${order.items.length} items from ${order.number}` });
    router.push("/cart");
  }

  return (
    <div>
      <PageHeader title={order.number} back="" onClose={() => router.push("/orders")} />
      <div className="mx-auto max-w-2xl space-y-3 p-4">
        <div className="zx-card flex items-center gap-3 p-4">
          <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-zx-yellow text-white">
            <Icon name="clock" size={22} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] font-bold uppercase tracking-wide text-zx-muted">Estimated arrival</p>
            <p className="font-heading text-base font-bold leading-snug">{eta}</p>
            {!online && <p className="text-xs text-zx-muted">(last known — you are offline)</p>}
          </div>
          {!order.pendingSync && (
            <span
              className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-bold ${
                status === "delivered"
                  ? "bg-zx-success/15 text-zx-success"
                  : status === "cancelled"
                    ? "bg-zx-error/15 text-zx-error"
                    : "bg-zx text-white"
              }`}
            >
              {STATUS_LABELS[status]}
            </span>
          )}
        </div>

        {order.pendingSync && (
          <div className="zx-fade rounded-[16px] bg-zx-yellow p-3.5 text-white">
            <p className="flex items-start gap-2 text-sm font-semibold">
              <Icon name="offline" size={18} className="mt-0.5 shrink-0" />
              <span>
                {order.pendingReason === "server"
                  ? "This order is saved on your phone but the store server did not accept it yet."
                  : "Waiting for internet — this order is saved on your phone and is not confirmed until it is sent."}
              </span>
            </p>
            <button
              type="button"
              onClick={handleRetry}
              disabled={retrying}
              className="zx-btn zx-btn-dark mt-3 w-full"
            >
              <Icon name="delivery" size={18} />
              {retrying ? "Sending…" : "Send order now"}
            </button>
          </div>
        )}

        <ul className="zx-card divide-y divide-zx-bg p-1">
          {order.items.map((i) => (
            <li key={i.productId} className="flex items-center gap-3 p-3 text-sm">
              <SmartImage src={i.image} alt="" ratio="1 / 1" className="h-12 w-12 shrink-0 rounded-lg" />
              <span className="min-w-0 flex-1 truncate">
                {i.qty}× {i.name}
                <span className="block text-xs text-zx-muted">{i.unit}</span>
              </span>
              <span className="font-semibold">{formatPkr(i.lineTotal)}</span>
            </li>
          ))}
        </ul>

        <div className="zx-card p-4 text-sm">
          <div className="flex justify-between">
            <span className="text-zx-muted">Items</span>
            <span>{formatPkr(order.subtotal)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-zx-muted">Delivery</span>
            <span>{order.deliveryFee ? formatPkr(order.deliveryFee) : "Free"}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-zx-muted">Discount</span>
            <span>-{formatPkr(order.discount)}</span>
          </div>
          <div className="mt-2 flex justify-between border-t border-zx-bg pt-2 font-heading text-base font-bold">
            <span>Cash to hand over</span>
            <span>{formatPkr(order.total)}</span>
          </div>
        </div>

        <div className="zx-card p-4 text-sm">
          <p className="flex items-center gap-2 font-semibold">
            <Icon name="location" size={16} /> {order.address.label} · {order.address.area}
          </p>
          <p className="mt-1 text-zx-muted">{order.address.details}</p>
          {order.note && <p className="mt-1 text-xs text-zx-muted">Note: {order.note}</p>}
          <p className="mt-2 flex items-center gap-2 text-xs text-zx-muted">
            <Icon name="clock" size={14} /> Express delivery (~{STORE.asapMinutes} mins)
          </p>
        </div>

        {error && (
          <p className="flex items-center gap-2 rounded-xl bg-zx-error/10 px-3 py-2 text-sm font-semibold text-zx-error">
            <Icon name="info" size={16} /> {error}
          </p>
        )}

        <div className="grid gap-2 sm:grid-cols-2">
          <button type="button" className="zx-btn" onClick={handleReorder}>
            <Icon name="cart" size={18} /> Reorder
          </button>
          {canCancel && (
            <button type="button" className="zx-btn zx-btn-dark" onClick={handleCancel}>
              Cancel order
            </button>
          )}
          <a href={`tel:${STORE.supportPhone}`} className="zx-btn zx-btn-ghost">
            <Icon name="phone" size={18} /> Call store
          </a>
          <a href={ownerWhatsAppLink(order)} className="zx-btn zx-btn-ghost">
            <Icon name="whatsapp" size={18} /> WhatsApp
          </a>
        </div>
        <Link href="/orders" className="block pt-1 text-center text-sm font-semibold text-zx-muted">
          ← All orders
        </Link>
      </div>
    </div>
  );
}
