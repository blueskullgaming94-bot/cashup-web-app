import { InfoPage } from "@/components/InfoPage";

export const metadata = { title: "Terms" };

export default function TermsPage() {
  return (
    <InfoPage title="Terms of use">
      <p style={{ ["--i" as string]: 0 }}>
        By placing an order you agree to pay Cash on Delivery for the confirmed total, including the delivery fee.
      </p>
      <p style={{ ["--i" as string]: 1 }}>We deliver only within Karachi. Orders outside the service area are declined.</p>
      <p style={{ ["--i" as string]: 2 }}>
        Prices and stock are re-checked when the order is sent. Substitutions are not made without your consent.
      </p>
      <p style={{ ["--i" as string]: 3 }}>
        You may cancel before packing starts. After packing begins, contact the store on WhatsApp.
      </p>
    </InfoPage>
  );
}
