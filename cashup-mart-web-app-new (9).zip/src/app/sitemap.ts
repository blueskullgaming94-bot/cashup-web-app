import { categories, products } from "@/data/catalog";
import type { MetadataRoute } from "next";

export const dynamic = "force-static";

export default function sitemap(): MetadataRoute.Sitemap {
  const staticPaths = ["", "/categories", "/search", "/offers", "/about", "/help", "/terms", "/privacy"].map(
    (path) => ({
      url: `https://cashupexpress.pk${path || "/"}`,
      changeFrequency: "daily" as const,
      priority: path === "" ? 1 : 0.6,
    }),
  );
  const cats = categories.map((c) => ({
    url: `https://cashupexpress.pk/categories/${c.slug}`,
    changeFrequency: "daily" as const,
    priority: 0.7,
  }));
  const items = products.map((p) => ({
    url: `https://cashupexpress.pk/product/${p.slug}`,
    changeFrequency: "weekly" as const,
    priority: 0.5,
  }));
  return [...staticPaths, ...cats, ...items];
}
