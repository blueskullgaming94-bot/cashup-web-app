"use client";

import { Icon } from "@/components/Icon";
import { OrderPlacedScene } from "@/components/OrderPlacedScene";
import { useStore } from "@/components/store";
import { PageHeader, SmartImage, useCodeNotice, useToast } from "@/components/ui";
import { STORE } from "@/lib/config";
import { loader } from "@/lib/loader";
import { formatPkr, totals, unitPrice } from "@/lib/money";
import { displayPhone, isValidPkMobile } from "@/lib/phone";
import { ownerWhatsAppLink, placeOrder, priceOrder, sendOtp, verifyOtp } from "@/lib/api";
import { createOrderNumber } from "@/lib/order-number";
import type { Order } from "@/lib/types";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";

export default function CheckoutPage() {
  const router = useRouter();
  const toast = useToast();
  const codeNotice = useCodeNotice();
  const {
    cart,
    addToCart,
    productById,
    catalog,
    address,
    profile,
    setProfile,
    clearCart,
    rememberOrder,
    online,
    setLocationModalOpen,
    promptForDelivery,
    hydrated,
  } = useStore();
  const [name, setName] = useState(profile?.name ?? "");
  const [phone, setPhone] = useState(profile?.phone ?? "");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otpTicket, setOtpTicket] = useState("");
  const [resendIn, setResendIn] = useState(0);
  const [sendingCode, setSendingCode] = useState(false);
  const codeInFlight = useRef(false);
  const [verified, setVerified] = useState(profile?.verified ?? false);
  const slot = "asap";
  const [promo, setPromo] = useState("");
  const [note, setNote] = useState(address?.note ?? "");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [placed, setPlaced] = useState<Order | null>(null);
  const requestedDetails = useRef(false);

  useEffect(() => {
    if (!hydrated || requestedDetails.current) return;
    requestedDetails.current = true;
    promptForDelivery("checkout");
  }, [hydrated, promptForDelivery]);

  // Details saved in the shared modal appear here without re-entering them.
  useEffect(() => {
    setName(profile?.name ?? "");
    setPhone(profile?.phone ?? "");
    setVerified(profile?.verified ?? false);
  }, [profile?.name, profile?.phone, profile?.verified]);
  useEffect(() => { setNote(address?.note ?? ""); }, [address?.note]);

  const items = cart
    .map((c) => {
      const p = productById(c.productId);
      return p ? { productId: p.id, qty: c.qty } : null;
    })
    .filter((x): x is { productId: string; qty: number } => Boolean(x));

  const priced = useMemo(() => {
    if (!address) return null;
    return priceOrder(catalog.products, {
      name,
      phone,
      address,
      items,
      promoCode: promo || null,
      deliverySlot: slot,
      note,
    });
  }, [catalog.products, address, items, promo, slot, note, name, phone]);

  const subtotal = priced?.error === null ? priced.subtotal : 0;
  const t = useMemo(() => totals(subtotal, promo), [subtotal, promo]);

  const promoShortfall =
    t.promo && subtotal < t.promo.minSubtotal ? t.promo.minSubtotal - subtotal : 0;

  const promoSuggestions = useMemo(() => {
    if (!promoShortfall || promoShortfall <= 0) return [];
    const available = catalog.products.filter((p) => p.active && p.inStock);

    // 1) Items below or equal to the shortfall (closest to shortfall first, to bridge gap directly)
    const atOrUnder = available
      .filter((p) => unitPrice(p.price, p.salePrice) <= promoShortfall)
      .sort((a, b) => unitPrice(b.price, b.salePrice) - unitPrice(a.price, a.salePrice));

    // 2) Items above the required shortfall amount (giving plenty of attractive choices to unlock the code)
    const above = available
      .filter((p) => unitPrice(p.price, p.salePrice) > promoShortfall)
      .sort((a, b) => {
        const aPop = a.tags.includes("popular") || a.tags.includes("deal") ? 1 : 0;
        const bPop = b.tags.includes("popular") || b.tags.includes("deal") ? 1 : 0;
        if (aPop !== bPop) return bPop - aPop;
        return unitPrice(a.price, a.salePrice) - unitPrice(b.price, b.salePrice);
      });

    // Provide rich variety of options (both below and above required amount)
    return [...atOrUnder, ...above].slice(0, 20);
  }, [promoShortfall, catalog.products]);

  /** Changing the number invalidates any previous verification. */
  function handlePhoneChange(value: string) {
    setPhone(value);
    setError("");
    if (verified && value !== profile?.phone) {
      setVerified(false);
      setOtpSent(false);
      setOtp("");
      rememberOtpTicket("");
      setResendIn(0);
      codeNotice.hide();
    }
  }

  // The signed ticket survives a page refresh so a code requested before a
  // reload still verifies afterwards.
  function rememberOtpTicket(ticket: string) {
    setOtpTicket(ticket);
    try {
      if (ticket) sessionStorage.setItem("cashup-otp-ticket", ticket);
      else sessionStorage.removeItem("cashup-otp-ticket");
    } catch {
      /* private mode: in-memory ticket still works for this visit */
    }
  }

  function currentOtpTicket() {
    if (otpTicket) return otpTicket;
    try {
      return sessionStorage.getItem("cashup-otp-ticket") || "";
    } catch {
      return "";
    }
  }

  // Resend cooldown (matches the server's 45s limit).
  useEffect(() => {
    if (resendIn <= 0) return;
    const timer = setTimeout(() => setResendIn((n) => n - 1), 1000);
    return () => clearTimeout(timer);
  }, [resendIn]);

  async function handleSendOtp() {
    if (codeInFlight.current || resendIn > 0) return;
    setError("");
    if (!isValidPkMobile(phone)) {
      setError("Enter a valid Pakistani mobile number (03xx…)");
      toast({ kind: "error", title: "Invalid mobile number" });
      return;
    }
    codeInFlight.current = true;
    setSendingCode(true);
    codeNotice.hide();
    try {
      const res = await loader.wrap(sendOtp(phone));
      if (!res.ok) {
        if (!res.offline) {
          setError(res.error);
          toast({ kind: "error", title: "Code not sent", body: res.error });
          return;
        }
        // Offline fallback is not a successful send: do not show "Code Sent!".
        setOtpSent(true);
        setResendIn(45);
        codeNotice.show(STORE.demoOtp);
        toast({ kind: "offline", title: "Code ready on this device", body: "Copy it from the code notification." });
        return;
      }
    setOtpSent(true);
    setResendIn(45);
    if (res.data.ticket) rememberOtpTicket(res.data.ticket);
    if (res.data.code) codeNotice.show(res.data.code);
    codeNotice.sent();
    } catch {
      setError("Could not request a code. Please try again.");
    } finally {
      codeInFlight.current = false;
      setSendingCode(false);
    }
  }

  async function handleVerify() {
    setError("");
    if (!isValidPkMobile(phone)) {
      setError("Enter a valid Pakistani mobile number (03xx…)");
      return;
    }
    const res = await loader.wrap(verifyOtp(phone, otp, name.trim() || "Customer", currentOtpTicket()));
    if (!res.ok) {
      // A wrong guess rotates the challenge; keep the fresh ticket so the next
      // attempt (or a resend that fails to arrive) still validates.
      if (res.ticket) rememberOtpTicket(res.ticket);
      setError(res.error);
      toast({ kind: res.offline ? "offline" : "error", title: res.error });
      return;
    }
    rememberOtpTicket("");
    setVerified(true);
    codeNotice.hide();
    setProfile({ name: name.trim() || "Customer", phone, verified: true });
    toast({ kind: "success", title: "Phone verified", body: displayPhone(phone) });
  }

  async function handlePlace() {
    setError("");
    if (!promptForDelivery("checkout") || !address) {
      return setError("Add your contact details and a Karachi delivery address first.");
    }
    if (!name.trim()) return setError("Enter your full name");
    if (!verified) return setError("Verify your phone with the OTP first");
    if (!priced) return setError("Add a delivery address in Karachi first");
    if (priced.error !== null) {
      setError(priced.error);
      toast({ kind: "error", title: priced.error });
      return;
    }
    setBusy(true);
    const payload = {
      name: name.trim(),
      phone,
      address: { ...address, note },
      items,
      promoCode: promo || null,
      deliverySlot: slot,
      note,
    };
    const now = new Date().toISOString();
    const localOrder: Order = {
      id: crypto.randomUUID(),
      number: createOrderNumber(new Date(now)),
      customerName: payload.name,
      phone,
      address: payload.address,
      items: priced.items,
      subtotal: priced.subtotal,
      deliveryFee: priced.deliveryFee,
      discount: priced.discount,
      total: priced.total,
      promoCode: priced.discount ? payload.promoCode : null,
      paymentMethod: "cod",
      status: "placed",
      deliverySlot: slot,
      note,
      createdAt: now,
      updatedAt: now,
      pendingSync: true,
    };

    try {
      const res = await loader.wrap(placeOrder(payload));

      // 1) Server accepted the order — fully confirmed.
      if (res.ok) {
        const order: Order = { ...res.data.order, pendingSync: false, pendingReason: undefined };
        rememberOrder(order);
        clearCart();
        setPlaced(order);
        toast({ kind: "order", title: `Order ${order.number} placed`, body: "Cash on Delivery" });
        return;
      }

      // 2) Genuinely no connection / server unreachable — queue it on the device.
      if (res.offline) {
        const queued: Order = { ...localOrder, pendingSync: true, pendingReason: "offline" };
        rememberOrder(queued);
        clearCart();
        setPlaced(queued);
        toast({
          kind: "offline",
          title: "Saved on this phone",
          body: "Sent automatically when you reconnect",
        });
        return;
      }

      // 3) The server answered — distinguish fixable validation errors from
      // transient store/server hiccups. Transient failures are queued on the
      // device with a "Send order now" retry so the order is never lost.
      const transient = /unavailable|went wrong|try again|saved on your phone|send order now|temporarily|timed out|timeout|network|server|failed/i.test(
        res.error,
      );
      if (transient) {
        const queued: Order = { ...localOrder, pendingSync: true, pendingReason: "server" };
        rememberOrder(queued);
        clearCart();
        setPlaced(queued);
        toast({
          kind: "offline",
          title: "Saved on this phone",
          body: "Tap “Send order now” on the order to retry",
        });
        return;
      }
      setError(res.error);
      toast({ kind: "error", title: "Order not placed", body: res.error });
    } catch {
      const queued: Order = { ...localOrder, pendingSync: true, pendingReason: "offline" };
      rememberOrder(queued);
      clearCart();
      setPlaced(queued);
      toast({ kind: "offline", title: "Saved on this phone", body: "We will send it when you reconnect" });
    } finally {
      setBusy(false);
    }
  }

  if (placed) {
    const wa = ownerWhatsAppLink(placed);
    return (
      <div className="mx-auto max-w-xl px-4 pb-10">
        <div className="overflow-hidden rounded-[16px] bg-zx">
          <OrderPlacedScene />
        </div>
        <div className="zx-pop -mt-4 rounded-[16px] bg-zx-card p-5 text-center shadow-lg">
          <h1 className="font-heading text-2xl font-bold">
            {placed.pendingSync
              ? placed.pendingReason === "server"
                ? "Saved — tap Send order now"
                : "Waiting for internet"
              : "Order placed!"}
          </h1>
          <p className="mt-1 text-sm text-zx-muted">
            {placed.pendingSync
              ? placed.pendingReason === "server"
                ? "The store server hiccupped, so this order is saved on your phone. Open the order and tap “Send order now” to retry — or send it to the store on WhatsApp below."
                : "No connection right now, so this order is saved on your phone. It is not confirmed until it reaches the store — we send it automatically the moment you are back online."
              : `Order ${placed.number} · Cash on Delivery`}
          </p>
          <p className="font-heading mt-3 text-3xl font-bold">{formatPkr(placed.total)}</p>
          <p className="mt-2 flex items-center justify-center gap-2 text-sm text-zx-muted">
            <Icon name="clock" size={16} />
            Arriving in about {STORE.asapMinutes} minutes
          </p>
          <div className="mt-5 grid gap-2">
            <Link href={`/order?id=${placed.id}`} className="zx-btn">
              View order
            </Link>
            <a href={wa} className="zx-btn zx-btn-ghost">
              <Icon name="whatsapp" size={18} /> Send order to store
            </a>
            <button type="button" className="zx-btn zx-btn-dark" onClick={() => router.push("/")}>
              Back to home
            </button>
          </div>
          <p className="mt-4 text-xs text-zx-muted">Keep exact change ready for the rider.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl">
      <PageHeader title="Checkout" back="" onClose={() => router.push("/cart")} />
      <div className="zx-stagger space-y-3 p-4">
        <section className="zx-card p-4" style={{ ["--i" as string]: 0 }}>
          <h2 className="font-heading font-bold">1 · Contact</h2>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Full name"
            className="zx-input mt-2 bg-zx-bg"
          />
          <input
            value={phone}
            onChange={(e) => handlePhoneChange(e.target.value)}
            placeholder="03xx xxxxxxx"
            inputMode="tel"
            className="zx-input mt-2 bg-zx-bg"
          />
          {!verified && (
            <div className="mt-2 space-y-2">
              {!otpSent ? (
                <button type="button" className="zx-btn w-full" disabled={sendingCode} onClick={handleSendOtp}>
                  {sendingCode ? "Sending…" : "Send OTP"}
                </button>
              ) : (
                <>
                  <input
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                    placeholder="6-digit code"
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    aria-label="Verification code"
                    className="zx-input bg-zx-bg"
                  />
                  <button type="button" className="zx-btn w-full" onClick={handleVerify}>
                    Verify phone
                  </button>
                  <button
                    type="button"
                    className="min-h-10 w-full text-sm font-semibold text-zx-muted disabled:opacity-60"
                    disabled={resendIn > 0 || sendingCode}
                    onClick={handleSendOtp}
                  >
                    {sendingCode ? "Sending…" : resendIn > 0 ? `Resend code in ${resendIn}s` : "Resend code"}
                  </button>
                </>
              )}
            </div>
          )}
          {verified && (
            <p className="mt-2 flex items-center gap-1.5 text-sm font-semibold text-zx-success">
              <Icon name="check" size={16} /> Verified {displayPhone(phone)}
            </p>
          )}
        </section>

        <section className="zx-card p-4" style={{ ["--i" as string]: 1 }}>
          <div className="flex items-center justify-between">
            <h2 className="font-heading font-bold">2 · Address</h2>
            <button type="button" className="text-sm font-semibold" onClick={() => setLocationModalOpen(true)}>
              {address ? "Change" : "Add details"}
            </button>
          </div>
          {address ? (
            <p className="mt-2 text-sm">
              <b>{address.label}</b> · {address.area}
              <br />
              <span className="text-zx-muted">{address.details}</span>
            </p>
          ) : (
            <p className="mt-2 text-sm text-zx-muted">A saved Karachi address is required before placing your order.</p>
          )}
        </section>

        <section className="zx-card p-4" style={{ ["--i" as string]: 2 }}>
          <div className="mb-2">
            <h2 className="font-heading font-bold">3 · Promo & note</h2>
          </div>
          <div className="flex gap-2">
            <input
              value={promo}
              onChange={(e) => setPromo(e.target.value.toUpperCase())}
              placeholder="Promo code (CASHUP50)"
              className="zx-input bg-zx-bg"
            />
            {promo && (
              <button
                type="button"
                onClick={() => setPromo("")}
                className="zx-btn zx-btn-ghost px-3 text-xs shrink-0"
              >
                Clear
              </button>
            )}
          </div>
          {t.error && <p className="mt-1.5 text-xs font-semibold text-zx-error">{t.error}</p>}
          {t.discount > 0 && (
            <p className="mt-1.5 text-xs font-semibold text-zx-success">{formatPkr(t.discount)} off applied</p>
          )}

          {/* Promo code shortfall item suggestions (below or above required amount) */}
          {promoShortfall > 0 && promoSuggestions.length > 0 && (
            <div
              className="mt-3 rounded-2xl border border-zx-line/40 bg-zx-card p-3 shadow-xs"
              data-testid="promo-shortfall-suggestions"
            >
              <div className="flex items-center justify-between gap-2 mb-2">
                <div>
                  <p className="text-xs font-bold text-zx-ink">
                    Add {formatPkr(promoShortfall)} more to use {t.promo?.code}
                  </p>
                  <p className="text-[11px] text-zx-muted">
                    Quick-add items below or above this amount to reach {t.promo ? formatPkr(t.promo.minSubtotal) : ""} and unlock {t.promo?.label}
                  </p>
                </div>
                <span className="rounded-full bg-zx-yellow/15 px-2 py-0.5 text-[10px] font-extrabold text-zx-yellow shrink-0">
                  {t.promo?.code}
                </span>
              </div>
              <div className="no-scrollbar flex gap-2.5 overflow-x-auto pb-1">
                {promoSuggestions.map((item) => {
                  const price = unitPrice(item.price, item.salePrice);
                  const inCartQty = cart.find((c) => c.productId === item.id)?.qty ?? 0;
                  const qualifies = price >= promoShortfall;
                  return (
                    <div
                      key={item.id}
                      className="flex w-[130px] shrink-0 flex-col justify-between rounded-xl border border-zx-line/30 bg-zx-bg p-2 text-left shadow-xs"
                    >
                      <div className="relative mb-1 aspect-square w-full overflow-hidden rounded-lg bg-neutral-100">
                        <SmartImage
                          src={item.image}
                          alt={item.name}
                          ratio="1 / 1"
                          className="h-full w-full object-cover"
                        />
                        {qualifies && (
                          <span className="absolute left-1 top-1 rounded-full bg-emerald-600 px-1.5 py-0.2 text-[8.5px] font-extrabold text-white shadow-xs">
                            Unlocks deal!
                          </span>
                        )}
                      </div>
                      <p className="line-clamp-1 text-xs font-bold text-zx-ink" title={item.name}>
                        {item.name}
                      </p>
                      <p className="text-[10px] text-zx-muted truncate">{item.unit}</p>
                      <div className="mt-1.5 flex items-center justify-between gap-1 pt-1 border-t border-zx-line/20">
                        <span className="text-xs font-extrabold text-zx-ink">
                          {formatPkr(price)}
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            addToCart(item.id, 1);
                            toast({ kind: "cart", title: "Added to cart", body: item.name });
                          }}
                          className="flex h-7 items-center justify-center rounded-lg bg-zx-yellow px-2 text-[11px] font-bold text-white shadow-xs active:scale-95 transition-transform shrink-0"
                          aria-label={`Add ${item.name}`}
                        >
                          + Add {inCartQty > 0 ? `(${inCartQty})` : ""}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <input
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Delivery note for the rider"
            className="zx-input mt-2 bg-zx-bg"
          />
        </section>

        <section className="rounded-[16px] bg-zx p-4 text-white" style={{ ["--i" as string]: 4 }}>
          <p className="font-heading flex items-center gap-2 font-bold text-zx-line">
            <Icon name="delivery" size={18} /> Cash on Delivery only
          </p>
          <p className="mt-1 text-sm text-white/75">
            Card, wallet and online payments are not available. Keep exact change ready.
          </p>
          <CodDeliveryClock />
        </section>

        <div className="zx-card p-4 text-sm" style={{ ["--i" as string]: 5 }}>
          <Row label={`Items (${items.reduce((n, i) => n + i.qty, 0)})`} value={formatPkr(subtotal)} />
          <Row label="Delivery" value={t.deliveryFee === 0 ? "Free" : formatPkr(t.deliveryFee)} />
          <Row label="Discount" value={`-${formatPkr(t.discount)}`} />
          <div className="mt-2 flex justify-between border-t border-zx-bg pt-2 font-heading text-lg font-bold">
            <span>Total COD</span>
            <span>{formatPkr(t.total)}</span>
          </div>
        </div>

        {error && (
          <p className="zx-fade flex items-center gap-2 rounded-xl bg-zx-error/10 px-3 py-2 text-sm font-semibold text-zx-error">
            <Icon name="info" size={16} /> {error}
          </p>
        )}
        {!online && (
          <p className="flex items-center gap-2 rounded-xl bg-zx-yellow/30 px-3 py-2 text-xs font-semibold text-zx-ink">
            <Icon name="offline" size={16} /> Offline: the order will be saved and sent when you reconnect.
          </p>
        )}
        <button type="button" className="zx-btn w-full" disabled={busy} onClick={handlePlace}>
          {busy ? "Placing order…" : `Place order · ${formatPkr(t.total)}`}
        </button>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between py-0.5">
      <span className="text-zx-muted">{label}</span>
      <span className="font-semibold">{value}</span>
    </div>
  );
}

/**
 * Live delivery clock — shown ONLY on the Cash on Delivery section.
 * Ticks every real second: analog hands + digital now/ETA, so the shopper sees
 * exactly when an order placed right now would arrive (~45 min).
 */
function CodDeliveryClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const eta = new Date(now.getTime() + STORE.asapMinutes * 60000);
  const etaText = eta.toLocaleTimeString("en-PK", { hour: "numeric", minute: "2-digit" });
  const nowText = now.toLocaleTimeString("en-PK", { hour: "numeric", minute: "2-digit", second: "2-digit" });
  const etaDate = eta.toLocaleDateString("en-PK", { weekday: "short", day: "numeric", month: "short" });

  const secondsDeg = now.getSeconds() * 6;
  const minutesDeg = now.getMinutes() * 6 + now.getSeconds() * 0.1;
  const hoursDeg = (now.getHours() % 12) * 30 + now.getMinutes() * 0.5;

  return (
    <div className="mt-3 flex items-center gap-3 rounded-2xl bg-white/10 p-3 ring-1 ring-white/15">
      {/* Real working analog clock — hands driven by the live time above */}
      <svg viewBox="0 0 48 48" className="h-14 w-14 shrink-0" aria-hidden suppressHydrationWarning>
        <circle cx="24" cy="24" r="22" fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.45)" strokeWidth="2" />
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i * 30 * Math.PI) / 180;
          const x1 = 24 + 17 * Math.sin(a);
          const y1 = 24 - 17 * Math.cos(a);
          const x2 = 24 + 19 * Math.sin(a);
          const y2 = 24 - 19 * Math.cos(a);
          return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="rgba(255,255,255,0.7)" strokeWidth={i % 3 === 0 ? 2.2 : 1.2} strokeLinecap="round" />;
        })}
        <line
          x1="24"
          y1="24"
          x2="24"
          y2="14"
          stroke="#fff"
          strokeWidth="3"
          strokeLinecap="round"
          style={{ transform: `rotate(${hoursDeg}deg)`, transformOrigin: "24px 24px" }}
        />
        <line
          x1="24"
          y1="24"
          x2="24"
          y2="10"
          stroke="#9EC1E8"
          strokeWidth="2.2"
          strokeLinecap="round"
          style={{ transform: `rotate(${minutesDeg}deg)`, transformOrigin: "24px 24px" }}
        />
        <line
          x1="24"
          y1="26"
          x2="24"
          y2="9"
          stroke="#FF5A5A"
          strokeWidth="1.4"
          strokeLinecap="round"
          style={{ transform: `rotate(${secondsDeg}deg)`, transformOrigin: "24px 24px" }}
        />
        <circle cx="24" cy="24" r="2.2" fill="#fff" />
      </svg>
      <div className="min-w-0 flex-1">
        <p className="flex items-center gap-1.5 text-[11px] font-extrabold uppercase tracking-wider text-zx-line">
          <span className="zx-pulse inline-block h-1.5 w-1.5 rounded-full bg-emerald-300" />
          Express delivery · ~{STORE.asapMinutes} min
        </p>
        <p className="font-heading mt-0.5 text-base font-bold leading-tight" suppressHydrationWarning>
          Order now, arriving by {etaText}
        </p>
        <p className="mt-0.5 text-xs text-white/70" suppressHydrationWarning>
          {etaDate} · Right now {nowText}
        </p>
      </div>
    </div>
  );
}
