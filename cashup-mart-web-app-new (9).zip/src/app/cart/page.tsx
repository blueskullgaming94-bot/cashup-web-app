"use client";

import { Icon } from "@/components/Icon";
import { QuantityStepper } from "@/components/catalog-ui";
import { useStore } from "@/components/store";
import { PageHeader, SmartImage, useToast } from "@/components/ui";
import { STORE } from "@/lib/config";
import { formatPkr, freeDeliveryRemaining, totals, unitPrice } from "@/lib/money";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function CartPage() {
  const router = useRouter();
  const toast = useToast();
  const { cart, productById, setQty, online, needsRegistration, promptForDelivery } = useStore();
  const lines = cart
    .map((c) => {
      const p = productById(c.productId);
      if (!p) return null;
      const price = unitPrice(p.price, p.salePrice);
      return { ...c, product: p, price, line: price * c.qty };
    })
    .filter((l): l is NonNullable<typeof l> => Boolean(l));

  const subtotal = lines.reduce((n, l) => n + l.line, 0);
  const t = totals(subtotal);
  const remain = freeDeliveryRemaining(subtotal);
  const progress = Math.min(100, (subtotal / STORE.freeDeliveryPkr) * 100);

  if (!lines.length) {
    return (
      <div>
        <PageHeader title="Cart" back="" onClose={() => router.push("/")} />
        <div className="zx-fade px-6 py-14 text-center">
          <svg viewBox="0 0 120 120" className="zx-bob mx-auto h-28 w-28 text-zx-ink" aria-hidden>
            <circle cx="60" cy="60" r="48" fill="currentColor" opacity="0.06" />
            <g fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round">
              <path d="M28 40h9l7 34h30l6-24H41" />
              <circle cx="48" cy="86" r="4.5" />
              <circle cx="76" cy="86" r="4.5" />
            </g>
            <path d="M60 44v16M52 52h16" stroke="#E52424" strokeWidth="4" strokeLinecap="round" />
          </svg>
          <h1 className="font-heading mt-3 text-xl font-bold">Your cart is empty</h1>
          <p className="mt-1 text-sm text-zx-muted">Add groceries in under two minutes.</p>
          <Link href="/" className="zx-btn mt-5 inline-flex">
            Start shopping
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title={`Cart · ${lines.reduce((n, l) => n + l.qty, 0)} items`} back="" onClose={() => router.push("/")} />
      <div className="mx-auto max-w-2xl space-y-3 p-4">
        <div className="zx-card p-3">
          <div className="mb-1.5 flex justify-between text-xs font-semibold">
            <span>{remain > 0 ? `Add ${formatPkr(remain)} more for free delivery` : "Free delivery unlocked 🎉"}</span>
            <span className="text-zx-muted">{formatPkr(STORE.freeDeliveryPkr)}</span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-zx-bg">
            <div
              className="h-full rounded-full bg-zx-yellow transition-[width] duration-500 ease-out"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <ul className="zx-stagger space-y-2">
          {lines.map((l, i) => (
            <li key={l.productId} className="zx-card flex gap-3 p-3" style={{ ["--i" as string]: i }}>
              <SmartImage src={l.product.image} alt={l.product.name} ratio="1 / 1" className="h-16 w-16 shrink-0 rounded-xl" />
              <div className="min-w-0 flex-1">
                <Link href={`/product/${l.product.slug}`} className="truncate text-sm font-semibold hover:underline">
                  {l.product.name}
                </Link>
                <p className="text-xs text-zx-muted">{l.product.unit}</p>
                <p className="font-heading mt-0.5 text-sm font-bold">{formatPkr(l.price)}</p>
              </div>
              <div className="flex w-[112px] shrink-0 flex-col items-end justify-between">
                <button
                  type="button"
                  className="grid h-8 w-8 place-items-center rounded-full text-zx-muted transition-transform active:scale-90"
                  onClick={() => {
                    setQty(l.productId, 0);
                    toast({ kind: "info", title: "Removed", body: l.product.name });
                  }}
                  aria-label={`Remove ${l.product.name}`}
                >
                  <Icon name="trash" size={18} />
                </button>
                <QuantityStepper productId={l.productId} compact />
              </div>
            </li>
          ))}
        </ul>

        <div className="zx-card space-y-1 p-4 text-sm">
          <Row label="Item total" value={formatPkr(subtotal)} />
          <Row label="Delivery fee" value={t.deliveryFee === 0 ? "Free" : formatPkr(t.deliveryFee)} />
          <Row label="Discount" value={t.discount ? `-${formatPkr(t.discount)}` : formatPkr(0)} />
          <div className="mt-2 flex justify-between border-t border-zx-bg pt-2 font-heading text-base font-bold">
            <span>To pay (COD)</span>
            <span>{formatPkr(t.total)}</span>
          </div>
          {subtotal < STORE.minOrderPkr && (
            <p className="pt-2 text-xs font-semibold text-zx-error">
              Minimum order is {formatPkr(STORE.minOrderPkr)} — add {formatPkr(STORE.minOrderPkr - subtotal)} more.
            </p>
          )}
        </div>

        {!online && (
          <p className="flex items-center gap-2 rounded-xl bg-zx-yellow/30 px-3 py-2 text-xs font-semibold">
            <Icon name="offline" size={16} /> Offline: your cart is safe on this device.
          </p>
        )}

        {needsRegistration && (
          <p className="flex items-start gap-2 rounded-[16px] bg-zx-yellow/35 px-3.5 py-2.5 text-xs font-semibold text-zx-ink">
            <Icon name="info" size={16} className="mt-0.5 shrink-0" />
            Add your contact details and a Karachi delivery address before you order. You can keep
            browsing and building your cart first.
          </p>
        )}
        <button
          type="button"
          disabled={subtotal < STORE.minOrderPkr}
          className="zx-btn w-full"
          onClick={() => {
            if (!promptForDelivery("checkout")) return;
            router.push("/checkout");
          }}
        >
          {needsRegistration ? "Register to order" : `Checkout · ${formatPkr(t.total)}`}
        </button>
        <Link href="/" className="block text-center text-sm font-semibold text-zx-muted">
          Continue shopping
        </Link>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between py-0.5">
      <span className="text-zx-muted">{label}</span>
      <span className="font-semibold">{value}</span>
    </div>
  );
}
