"use client";

import { ProductGrid } from "@/components/catalog-ui";
import { Icon } from "@/components/Icon";
import { useStore } from "@/components/store";
import { PageHeader, useToast } from "@/components/ui";
import { PROMO_CODES } from "@/lib/config";
import { formatPkr, unitPrice } from "@/lib/money";
import { useRouter } from "next/navigation";

export default function OffersPage() {
  const router = useRouter();
  const toast = useToast();
  const { catalog } = useStore();
  const deals = catalog.products.filter((p) => p.salePrice && p.salePrice < p.price);

  return (
    <div>
      <PageHeader title="Offers" back="" onClose={() => router.push("/")} />
      <div className="pt-4">
        <div className="zx-stagger space-y-2 px-4">
          {PROMO_CODES.map((p, i) => (
            <button
              key={p.code}
              type="button"
              className="zx-card zx-row-link flex w-full items-center gap-3 overflow-hidden rounded-[16px] bg-zx p-4 text-left text-white"
              style={{ ["--i" as string]: i }}
              onClick={() => {
                navigator.clipboard?.writeText(p.code).catch(() => undefined);
                toast({ kind: "success", title: "Code copied", body: p.code });
              }}
            >
              <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-zx-yellow text-white">
                <Icon name="offers" size={22} />
              </span>
              <span className="min-w-0 flex-1">
                <span className="font-heading block text-lg font-bold text-white">{p.code}</span>
                <span className="block truncate text-sm text-white/75">{p.label}</span>
                <span className="block text-xs text-white/55">
                  Min order {formatPkr(p.minSubtotal)} · tap to copy
                </span>
              </span>
            </button>
          ))}
        </div>
        <h2 className="font-heading mt-6 px-4 text-lg font-bold">
          Price drops ({deals.length})
        </h2>
        <p className="mb-3 px-4 text-xs text-zx-muted">
          Savings shown against the regular price ·{" "}
          {formatPkr(deals.reduce((n, p) => n + (p.price - (p.salePrice ?? unitPrice(p.price, null))), 0))} total
        </p>
        <ProductGrid products={deals} />
      </div>
    </div>
  );
}
