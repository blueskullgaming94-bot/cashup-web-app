import { InfoPage } from "@/components/InfoPage";

export const metadata = { title: "About" };

export default function AboutPage() {
  return (
    <InfoPage title="About CashUp Express">
      <p style={{ ["--i" as string]: 0 }}>
        CashUp Express is a single mart for groceries and daily essentials in Karachi. Tagline:{" "}
        <b>Ghar ka Rashan, Dehleez Tak</b>.
      </p>
      <p style={{ ["--i" as string]: 1 }}>
        Everything is delivered except cooked or prepared food. There are no restaurants on this platform. Cash on
        Delivery is the only payment method.
      </p>
      <p style={{ ["--i" as string]: 2 }}>
        City coverage is Karachi only for now. The service area is checked on every address and every order.
      </p>
      <p style={{ ["--i" as string]: 3 }}>
        The app is installable and works offline: the catalog, cart and favorites stay on your device, and orders placed
        without a connection are queued and sent automatically when you are back online.
      </p>
    </InfoPage>
  );
}
