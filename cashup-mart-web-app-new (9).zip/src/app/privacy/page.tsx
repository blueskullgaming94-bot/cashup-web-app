import { InfoPage } from "@/components/InfoPage";

export const metadata = { title: "Privacy" };

export default function PrivacyPage() {
  return (
    <InfoPage title="Privacy">
      <p style={{ ["--i" as string]: 0 }}>
        We store your name, phone, delivery address and order history to fulfil Cash on Delivery orders.
      </p>
      <p style={{ ["--i" as string]: 1 }}>
        Your cart, favorites and location pin are stored on your device (IndexedDB / localStorage) so the app works
        offline. They are not sent anywhere except when you place an order.
      </p>
      <p style={{ ["--i" as string]: 2 }}>
        We never collect card numbers — Cash on Delivery is the only payment method.
      </p>
      <p style={{ ["--i" as string]: 3 }}>
        Order alerts are shared with the store owner so they can pack and deliver your rashan.
      </p>
    </InfoPage>
  );
}
