"use client";

import { LocationPicker } from "@/components/location";
import { useRouter } from "next/navigation";

export default function LocationPage() {
  const router = useRouter();
  return <LocationPicker variant="page" onDone={() => router.push("/")} onClose={() => router.push("/")} />;
}
