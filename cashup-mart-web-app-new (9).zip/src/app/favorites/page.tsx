"use client";

import { ProductGrid } from "@/components/catalog-ui";
import { Icon } from "@/components/Icon";
import { useStore } from "@/components/store";
import { PageHeader } from "@/components/ui";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function FavoritesPage() {
  const router = useRouter();
  const { favorites, catalog } = useStore();
  const items = catalog.products.filter((p) => favorites.includes(p.id));
  return (
    <div>
      <PageHeader title="Favorites" back="" onClose={() => router.push("/")} />
      <div className="pt-4">
        {items.length ? (
          <ProductGrid products={items} />
        ) : (
          <div className="zx-fade px-6 py-14 text-center">
            <svg viewBox="0 0 120 120" className="zx-bob mx-auto h-24 w-24 text-zx-ink" aria-hidden>
              <circle cx="60" cy="60" r="46" fill="currentColor" opacity="0.06" />
              <path
                d="M60 88S28 70 28 50a17 17 0 0 1 32-9 17 17 0 0 1 32 9c0 20-32 38-32 38z"
                fill="none"
                stroke="currentColor"
                strokeWidth="4"
                strokeLinejoin="round"
              />
            </svg>
            <h2 className="font-heading mt-3 text-lg font-bold">No favorites yet</h2>
            <p className="mt-1 text-sm text-zx-muted">Tap the heart on any product to save it here.</p>
            <Link href="/" className="zx-btn mt-4 inline-flex">
              Browse products
            </Link>
          </div>
        )}
        <p className="flex items-center justify-center gap-1.5 px-4 py-4 text-xs text-zx-muted">
          <Icon name="offline" size={14} /> Favorites are stored on this device and work offline.
        </p>
      </div>
    </div>
  );
}
