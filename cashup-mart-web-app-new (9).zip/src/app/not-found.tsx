import Link from "next/link";

export default function NotFound() {
  return (
    <div className="px-6 py-16 text-center">
      <h1 className="font-heading text-2xl font-bold">Page not found</h1>
      <p className="mt-2 text-sm text-zx-muted">That aisle does not exist in the mart.</p>
      <Link href="/" className="zx-btn mt-4 inline-flex">
        Go home
      </Link>
    </div>
  );
}
