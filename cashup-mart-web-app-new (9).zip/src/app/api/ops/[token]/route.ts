import { db } from "@/db";
import { orders } from "@/db/schema";
import { ORDER_STATUSES, type OrderStatus } from "@/lib/config";
import { ensureSchema } from "@/lib/schema-init";
import type { Address, OrderItemSnapshot } from "@/lib/types";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, ctx: { params: Promise<{ token: string }> }) {
  const { token } = await ctx.params;
  try {
    await ensureSchema();
  } catch {
    return Response.json({ error: "Store database unavailable" }, { status: 503 });
  }
  const rows = await db.select().from(orders).where(eq(orders.opsToken, token)).limit(1);
  const row = rows[0];
  if (!row) return Response.json({ error: "Invalid link" }, { status: 404 });
  return Response.json({
    order: {
      id: row.id,
      number: row.number,
      customerName: row.customerName,
      phone: row.phone,
      address: row.address as Address,
      items: row.items as OrderItemSnapshot[],
      total: row.total,
      status: row.status,
      deliverySlot: row.deliverySlot,
      note: row.note,
      createdAt: row.createdAt,
    },
  });
}

export async function POST(req: Request, ctx: { params: Promise<{ token: string }> }) {
  const { token } = await ctx.params;
  try {
    await ensureSchema();
  } catch {
    return Response.json({ error: "Store database unavailable" }, { status: 503 });
  }
  const body = await req.json().catch(() => ({}));
  const status = String(body.status || "") as OrderStatus;
  if (!ORDER_STATUSES.includes(status)) {
    return Response.json({ error: "Invalid status" }, { status: 400 });
  }
  const rows = await db.select().from(orders).where(eq(orders.opsToken, token)).limit(1);
  if (!rows[0]) return Response.json({ error: "Invalid link" }, { status: 404 });
  const updatedAt = new Date();
  await db.update(orders).set({ status, updatedAt }).where(eq(orders.opsToken, token));
  return Response.json({ ok: true, status });
}
