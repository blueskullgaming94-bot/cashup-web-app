import { isValidPkMobile, normalizePkPhone } from "@/lib/phone";
import { checkOtpSendLimit, makeOtpChallenge, otpSetCookie, sealOtpChallenge } from "@/lib/otp-challenge";

export const dynamic = "force-dynamic";

/**
 * OTP is database-independent so a normal Vercel deployment does not need
 * DATABASE_URL just to send/verify a phone. Challenge state is signed, short
 * lived and held in an HttpOnly, SameSite cookie.
 *
 * Add OTP_KEY, OTP_EMAIL and OTP_MASK in Vercel for actual Branded SMS delivery.
 * Without them, the application returns the code in its in-app notification
 * (OTP_REVEAL_CODE=false disables that and requires a configured SMS gateway).
 */
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const phone = normalizePkPhone(String(body.phone || ""));
  if (!isValidPkMobile(phone)) {
    return Response.json({ error: "Enter a valid Pakistani mobile number." }, { status: 400 });
  }

  const limit = checkOtpSendLimit(req, phone);
  if (!limit.ok) {
    return Response.json({ error: limit.error }, {
      status: 429,
      headers: { "Retry-After": String(limit.retryAfter), "Cache-Control": "no-store" },
    });
  }

  const code = makeOtpChallenge(phone);
  const otp = code.code;
  const revealInApp = process.env.OTP_REVEAL_CODE !== "false";
  const bspKey = process.env.OTP_KEY;
  const bspEmail = process.env.OTP_EMAIL;
  const bspMask = process.env.OTP_MASK;
  let gatewayStatus: "sent" | "not_configured" | "failed" = "not_configured";
  let gatewayMessage = "";

  if (bspKey && bspEmail && bspMask) {
    try {
      const smsMessage = `Your CashUp Express verification code is: ${otp}. Valid for 5 minutes.`;
      const url = new URL("https://secure.h3techs.com/sms/api/send");
      url.searchParams.set("email", bspEmail);
      url.searchParams.set("key", bspKey);
      url.searchParams.set("mask", bspMask);
      url.searchParams.set("to", phone);
      url.searchParams.set("message", smsMessage);
      const response = await fetch(url, { signal: AbortSignal.timeout(6500), cache: "no-store" });
      const text = (await response.text()).trim();
      if (response.ok && !text.startsWith("ERR:")) {
        gatewayStatus = "sent";
      } else {
        gatewayStatus = "failed";
        gatewayMessage = text.startsWith("ERR:") ? text.slice(0, 240) : `SMS provider returned HTTP ${response.status}.`;
        console.error("[otp] SMS provider rejected a request:", gatewayMessage);
      }
    } catch (error) {
      gatewayStatus = "failed";
      gatewayMessage = error instanceof Error ? error.message.slice(0, 180) : "SMS provider is unreachable.";
      console.error("[otp] SMS provider request failed:", gatewayMessage);
    }
  }

  // If codes must only be sent by SMS, never create a challenge when the gateway
  // is unavailable: the customer could not receive the code.
  if (!revealInApp && gatewayStatus !== "sent") {
    return Response.json({
      error: gatewayMessage || "SMS is not configured. Contact the store administrator.",
    }, { status: 503, headers: { "Cache-Control": "no-store" } });
  }

  const responseBody = {
    ok: true,
    // The signed challenge travels in the body so verification never depends
    // on cookies surviving proxies, serverless instances or cross-origin setups.
    ticket: sealOtpChallenge(code.challenge),
    code: revealInApp ? otp : undefined,
    gatewayStatus,
    message: gatewayStatus === "sent" ? "Verification code sent." : "Verification code ready.",
  };
  return new Response(JSON.stringify(responseBody), {
    status: 200,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "Set-Cookie": otpSetCookie(code.challenge),
    },
  });
}
