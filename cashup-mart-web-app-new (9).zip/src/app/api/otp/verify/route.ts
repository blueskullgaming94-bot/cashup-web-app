import { db } from "@/db";
import { customers } from "@/db/schema";
import { isValidPkMobile, normalizePkPhone } from "@/lib/phone";
import { checkOtpCode, otpClearCookie, otpSetCookie, parseOtpChallenge, readOtpChallenge, sealOtpChallenge } from "@/lib/otp-challenge";
import { makeSessionToken, sessionCookie } from "@/lib/session";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** Verify the signed, short-lived OTP challenge without requiring PostgreSQL. */
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const phone = normalizePkPhone(String(body.phone || ""));
  const name = String(body.name || "Customer").trim() || "Customer";
  const inputCode = String(body.code || "").trim();

  if (!isValidPkMobile(phone)) {
    return Response.json({ error: "Enter a valid Pakistani mobile number." }, { status: 400 });
  }
  if (!/^\d{6}$/.test(inputCode)) {
    return Response.json({ error: "Enter the 6-digit code from your notification or SMS." }, { status: 400 });
  }

  // The signed ticket travels in the request body, so verification works even
  // when cookies are stripped (proxies, serverless instances, cross-origin).
  // The HttpOnly cookie remains as a fallback for older clients.
  const bodyTicket = String(body.ticket || "");
  const challenge = (bodyTicket ? parseOtpChallenge(bodyTicket) : null) ?? readOtpChallenge(req);
  if (!challenge) {
    return Response.json({ error: "Your code has expired. Request a new verification code." }, {
      status: 400,
      headers: { "Set-Cookie": otpClearCookie(), "Cache-Control": "no-store" },
    });
  }
  if (challenge.phone !== phone) {
    return Response.json({ error: "This code belongs to a different mobile number. Request a new code." }, {
      status: 400,
      headers: { "Set-Cookie": otpClearCookie(), "Cache-Control": "no-store" },
    });
  }

  const checked = checkOtpCode(challenge, phone, inputCode);
  if (!checked.ok) {
    const exhausted = checked.challenge.attempts >= 5;
    return Response.json({
      error: exhausted ? "Too many incorrect codes. Request a new code." : "That code is incorrect or expired.",
      // Attempts live inside the stateless ticket, so hand the updated one back.
      ...(exhausted ? {} : { ticket: sealOtpChallenge(checked.challenge) }),
    }, {
      status: 400,
      headers: {
        "Set-Cookie": exhausted ? otpClearCookie() : otpSetCookie(checked.challenge),
        "Cache-Control": "no-store",
      },
    });
  }

  // Customer records enhance the full-stack app but must not gate phone
  // verification; Vercel/static/API-only installs may not have a database.
  try {
    const existing = await db.select().from(customers).where(eq(customers.phone, phone)).limit(1);
    if (!existing[0]) await db.insert(customers).values({ phone, name });
  } catch (error) {
    console.warn("[otp] phone verified; optional customer record was not saved:", error instanceof Error ? error.message : "DB unavailable");
  }

  const token = makeSessionToken(phone, name);
  const headers = new Headers({
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  // Set-Cookie is a multi-valued header; append separately rather than joining
  // with a comma (which some serverless proxies incorrectly parse as one cookie).
  headers.append("Set-Cookie", sessionCookie(token));
  headers.append("Set-Cookie", otpClearCookie());
  return new Response(JSON.stringify({ ok: true, phone, name }), { headers });
}
