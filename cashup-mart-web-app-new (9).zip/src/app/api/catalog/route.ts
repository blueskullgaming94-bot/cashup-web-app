import { banners as bannerSeed, catalogUpdatedAt, categories as categorySeed, products as productSeed } from "@/data/catalog";
import { db } from "@/db";
import { banners, categories, products } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { eq } from "drizzle-orm";
import type { Product } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureSeeded();
    const [dbProducts, dbCategories, dbBanners] = await Promise.all([
      db.select().from(products),
      db.select().from(categories),
      db.select().from(banners).where(eq(banners.active, true)).orderBy(banners.sortOrder),
    ]);
    return Response.json({
      categories: dbCategories.length ? dbCategories : categorySeed,
      products: (dbProducts.length ? dbProducts : productSeed) as Product[],
      banners: dbBanners.length ? dbBanners : bannerSeed,
      updatedAt: new Date().toISOString(),
    });
  } catch {
    return Response.json({
      categories: categorySeed,
      products: productSeed,
      banners: bannerSeed,
      updatedAt: catalogUpdatedAt,
    });
  }
}
