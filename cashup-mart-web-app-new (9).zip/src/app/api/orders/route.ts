import { products as seedProducts } from "@/data/catalog";
import { db } from "@/db";
import { addresses, customers, orders, products } from "@/db/schema";
import { STORE } from "@/lib/config";
import { validateOrderAddress } from "@/lib/address-fields";
import { isInsideKarachi } from "@/lib/karachi";
import { applyPromo, deliveryFeeFor, unitPrice } from "@/lib/money";
import { isValidPkMobile, normalizePkPhone } from "@/lib/phone";
import { ensureSeeded } from "@/lib/seed";
import { ensureSchema } from "@/lib/schema-init";
import { readSessionToken } from "@/lib/session";
import { createOrderNumber } from "@/lib/order-number";
import type { Address, Order, OrderItemSnapshot } from "@/lib/types";
import { randomBytes, randomUUID } from "crypto";
import { desc, eq, inArray } from "drizzle-orm";

export const dynamic = "force-dynamic";

function cookiesOf(req: Request) {
  const raw = req.headers.get("cookie") || "";
  const map: Record<string, string> = {};
  for (const part of raw.split(";")) {
    const [k, ...rest] = part.trim().split("=");
    if (k) map[k] = rest.join("=");
  }
  return map;
}

export async function GET(req: Request) {
  const phone = normalizePkPhone(new URL(req.url).searchParams.get("phone") || "");
  if (!phone) return Response.json({ orders: [] });
  try {
    await ensureSchema();
    const rows = await db.select().from(orders).where(eq(orders.phone, phone)).orderBy(desc(orders.createdAt));
    return Response.json({ orders: rows.map(toPublicOrder) });
  } catch (err) {
    console.error("[orders] list failed:", err);
    return Response.json({ orders: [] });
  }
}

/** Minimal shape shared by DB rows and the bundled seed catalog. */
type PricedItem = {
  id: string;
  name: string;
  unit: string;
  price: number;
  salePrice: number | null;
  image: string;
  inStock: boolean;
  active: boolean;
};

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    if (!body || typeof body !== "object" || Array.isArray(body)) return Response.json({ error: "Invalid order request." }, { status: 400 });
    const name = String(body.name || "").trim();
    const phone = normalizePkPhone(String(body.phone || ""));
    const checkedAddress = validateOrderAddress(body.address);
    if (!checkedAddress.ok) return Response.json({ error: checkedAddress.error, fieldErrors: checkedAddress.fieldErrors }, { status: 400 });
    const address = checkedAddress.address;
    const slot = String(body.deliverySlot || "asap");
    const note = String(body.note || "");
    const promoCode = body.promoCode ? String(body.promoCode).toUpperCase() : null;
    const itemsIn = Array.isArray(body.items) ? body.items : [];

    if (!name) return Response.json({ error: "Name is required" }, { status: 400 });
    if (!isValidPkMobile(phone)) return Response.json({ error: "Valid mobile number required" }, { status: 400 });
    if (!itemsIn.length) return Response.json({ error: "Cart is empty" }, { status: 400 });
    // Validate required fields BEFORE seeding or writing to the database.
    try { await ensureSeeded(); }
    catch (seedErr) { console.error("[orders] catalog seeding unavailable:", seedErr); }

    const session = readSessionToken(cookiesOf(req).zx_session);
    if (session && session.phone !== phone) {
      return Response.json(
        { error: "This number is not the one you verified. Please verify this number to continue." },
        { status: 409 },
      );
    }

    // Prices and stock are always re-checked server-side. If the database is
    // unavailable we fall back to the bundled catalog so a real order is never lost.
    const ids = itemsIn.map((i: { productId: string }) => i.productId);
    const byId = new Map<string, PricedItem>();
    try {
      const dbItems = await db.select().from(products).where(inArray(products.id, ids));
      for (const p of dbItems) byId.set(p.id, p as PricedItem);
    } catch (dbErr) {
      console.error("[orders] product lookup failed, using bundled catalog:", dbErr);
    }
    for (const p of seedProducts) {
      if (ids.includes(p.id) && !byId.has(p.id)) byId.set(p.id, p as PricedItem);
    }
    const snapshots: OrderItemSnapshot[] = [];
    let subtotal = 0;
    for (const line of itemsIn) {
      const p = byId.get(line.productId);
      if (!p || !p.active) return Response.json({ error: "An item is no longer available" }, { status: 400 });
      if (!p.inStock) return Response.json({ error: `${p.name} is out of stock` }, { status: 400 });
      const qty = Math.max(1, Math.min(20, Number(line.qty) || 0));
      const price = unitPrice(p.price, p.salePrice);
      const lineTotal = price * qty;
      subtotal += lineTotal;
      snapshots.push({
        productId: p.id,
        name: p.name,
        unit: p.unit,
        qty,
        unitPrice: price,
        lineTotal,
        image: p.image,
      });
    }
    if (subtotal < STORE.minOrderPkr) {
      return Response.json({ error: `Minimum order is Rs. ${STORE.minOrderPkr}` }, { status: 400 });
    }
    const promo = applyPromo(promoCode, subtotal);
    const deliveryFee = deliveryFeeFor(subtotal);
    const total = Math.max(0, subtotal - promo.discount + deliveryFee);

    // Customer + address bookkeeping is best-effort; it must never block the order.
    try {
      const existing = await db.select().from(customers).where(eq(customers.phone, phone)).limit(1);
      if (!existing[0]) await db.insert(customers).values({ phone, name });
      await db.insert(addresses).values({
        phone,
        label: address.label || "Home",
        area: address.area,
        houseNumber: address.houseNumber,
        blockSector: address.blockSector,
        street: address.street,
        details: address.details,
        note: address.note || note,
        lat: address.lat,
        lng: address.lng,
        isDefault: true,
      });
    } catch (bookErr) {
      console.error("[orders] customer/address save failed (non-fatal):", bookErr);
    }

    const now = new Date();
    const id = randomUUID();
    const number = createOrderNumber(now);
    const opsToken = randomBytes(18).toString("hex");
    const row = {
      id,
      number,
      customerName: name,
      phone,
      address,
      items: snapshots,
      subtotal,
      deliveryFee,
      discount: promo.discount,
      total,
      promoCode: promo.discount ? promoCode : null,
      paymentMethod: "cod",
      status: "placed",
      deliverySlot: slot,
      note,
      opsToken,
      createdAt: now,
      updatedAt: now,
    };
    // Persist the order. On hosted deployments without a reachable PostgreSQL
    // (missing DATABASE_URL, cold DB, migration lag) the insert throws — but the
    // customer's order must NEVER be lost to a 503. Fall back to a logged +
    // WhatsApp-routed order and still return success so checkout shows
    // "Order placed!" instead of "database is unavailable".
    let stored = true;
    try {
      await db.insert(orders).values(row);
    } catch (insertErr) {
      stored = false;
      console.error("[orders] order insert failed — accepting via log fallback:", insertErr);
    }

    const origin = req.headers.get("origin") || process.env.NEXT_PUBLIC_BASE_URL || "";
    const opsUrl = stored ? `${origin}/ops?token=${opsToken}` : `${origin}/orders`;
    const lines = snapshots.map((i) => `• ${i.qty}× ${i.name} (${i.unit}) — Rs. ${i.lineTotal}`).join("\n");
    const msg = `New CashUp Express order ${number}\n${name} ${phone}\n${address.area}, ${address.details}\n${lines}\nSubtotal Rs. ${subtotal}\nDelivery Rs. ${deliveryFee}\nDiscount Rs. ${promo.discount}\nTOTAL COD Rs. ${total}\nSlot: ${slot}${stored ? `\nUpdate status: ${opsUrl}` : `\n(via store log — DB unavailable, confirm by WhatsApp/call)`}`;
    console.log(`\n===== OWNER ORDER ALERT ${stored ? "" : "[NO-DB FALLBACK] "}=====\n` + msg + "\n============================\n");
    const wa = `https://wa.me/${STORE.ownerWhatsApp}?text=${encodeURIComponent(msg)}`;

    return Response.json({
      order: toPublicOrder(row),
      ownerWhatsApp: wa,
      stored,
    });
  } catch (err) {
    console.error("[orders] unexpected error:", err);
    return Response.json(
      {
        error:
          "Something went wrong while placing your order. It is saved on your phone — tap “Send order now” to retry.",
      },
      { status: 503 },
    );
  }
}

function toPublicOrder(row: {
  id: string;
  number: string;
  customerName: string;
  phone: string;
  address: unknown;
  items: unknown;
  subtotal: number;
  deliveryFee: number;
  discount: number;
  total: number;
  promoCode: string | null;
  paymentMethod: string;
  status: string;
  deliverySlot: string;
  note: string;
  createdAt: Date | string;
  updatedAt: Date | string;
}): Order {
  return {
    id: row.id,
    number: row.number,
    customerName: row.customerName,
    phone: row.phone,
    address: row.address as Address,
    items: row.items as OrderItemSnapshot[],
    subtotal: row.subtotal,
    deliveryFee: row.deliveryFee,
    discount: row.discount,
    total: row.total,
    promoCode: row.promoCode,
    paymentMethod: "cod",
    status: row.status as Order["status"],
    deliverySlot: row.deliverySlot,
    note: row.note,
    createdAt: new Date(row.createdAt).toISOString(),
    updatedAt: new Date(row.updatedAt).toISOString(),
  };
}
