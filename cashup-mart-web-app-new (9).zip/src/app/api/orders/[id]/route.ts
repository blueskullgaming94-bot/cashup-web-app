import { db } from "@/db";
import { orders } from "@/db/schema";
import { normalizePkPhone } from "@/lib/phone";
import { ensureSchema } from "@/lib/schema-init";
import type { Address, Order, OrderItemSnapshot } from "@/lib/types";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    await ensureSchema();
  } catch {
    return Response.json({ error: "Store database unavailable" }, { status: 503 });
  }
  const phone = normalizePkPhone(new URL(req.url).searchParams.get("phone") || "");
  const rows = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  const row = rows[0];
  if (!row) return Response.json({ error: "Not found" }, { status: 404 });
  if (phone && row.phone !== phone) return Response.json({ error: "Not found" }, { status: 404 });
  return Response.json({ order: toPublic(row) });
}

export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    await ensureSchema();
  } catch {
    return Response.json({ error: "Store database unavailable" }, { status: 503 });
  }
  const body = await req.json().catch(() => ({}));
  const phone = normalizePkPhone(String(body.phone || ""));
  const rows = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  const row = rows[0];
  if (!row || row.phone !== phone) return Response.json({ error: "Not found" }, { status: 404 });
  if (body.action === "cancel") {
    if (row.status !== "placed" && row.status !== "confirmed") {
      return Response.json({ error: "Too late to cancel — packing has started" }, { status: 400 });
    }
    const updatedAt = new Date();
    await db.update(orders).set({ status: "cancelled", updatedAt }).where(eq(orders.id, id));
    return Response.json({ order: toPublic({ ...row, status: "cancelled", updatedAt }) });
  }
  return Response.json({ error: "Unknown action" }, { status: 400 });
}

function toPublic(row: typeof orders.$inferSelect): Order {
  return {
    id: row.id,
    number: row.number,
    customerName: row.customerName,
    phone: row.phone,
    address: row.address as Address,
    items: row.items as OrderItemSnapshot[],
    subtotal: row.subtotal,
    deliveryFee: row.deliveryFee,
    discount: row.discount,
    total: row.total,
    promoCode: row.promoCode,
    paymentMethod: "cod",
    status: row.status as Order["status"],
    deliverySlot: row.deliverySlot,
    note: row.note,
    createdAt: new Date(row.createdAt).toISOString(),
    updatedAt: new Date(row.updatedAt).toISOString(),
  };
}
