import { formatMapAddress, reverseLookupUrl, type MapAddress, type NominatimAddress } from "@/lib/geocode";
import { isInsideKarachi, KARACHI_AREAS } from "@/lib/karachi";

export const dynamic = "force-dynamic";

// Specific, user-initiated Karachi address lookup. No key or database required.
// Use a self-hosted / contracted Nominatim-compatible endpoint for larger deployments.
const base = process.env.GEOCODER_BASE_URL || "https://nominatim.openstreetmap.org/reverse";
const cache = new Map<string, { value: MapAddress; expires: number }>();
const inFlight = new Map<string, Promise<MapAddress>>();
let queue: Promise<unknown> = Promise.resolve();
let lastRequest = 0;
const headers = { "Cache-Control": "private, no-store" };

async function lookup(lat: number, lng: number, preferredArea: string | null, key: string): Promise<MapAddress> {
  const cached = cache.get(key);
  if (cached && cached.expires > Date.now()) return cached.value;
  const waiting = inFlight.get(key);
  if (waiting) return waiting;

  const task = queue.catch(() => undefined).then(async () => {
    // Nominatim public service: <= 1 request / second, identified + cached.
    const delay = Math.max(0, 1100 - (Date.now() - lastRequest));
    if (delay) await new Promise((resolve) => setTimeout(resolve, delay));
    lastRequest = Date.now();
    const res = await fetch(reverseLookupUrl(base, lat, lng), {
      headers: {
        Accept: "application/json",
        "User-Agent": process.env.GEOCODER_USER_AGENT || "CashUpExpress/1.0 (Karachi grocery delivery address lookup)",
      },
      cache: "no-store",
      signal: AbortSignal.timeout(9000),
    });
    if (!res.ok) throw new Error("Address provider unavailable");
    const raw = await res.json() as NominatimAddress;
    if (raw.error || (!raw.address && !raw.display_name)) throw new Error("No mapped address found");
    const value = formatMapAddress(raw, lat, lng, preferredArea);
    if (!value.details) throw new Error("No mapped address found");
    if (cache.size >= 200) cache.delete(cache.keys().next().value!);
    cache.set(key, { value, expires: Date.now() + 24 * 60 * 60 * 1000 });
    return value;
  });
  queue = task.catch(() => undefined);
  inFlight.set(key, task);
  try { return await task; } finally { inFlight.delete(key); }
}

export async function GET(req: Request) {
  const params = new URL(req.url).searchParams;
  const la = params.get("lat");
  const lo = params.get("lng");
  const requestedArea = params.get("area")?.trim() || null;
  const preferredArea = requestedArea && KARACHI_AREAS.includes(requestedArea as typeof KARACHI_AREAS[number])
    ? requestedArea
    : null;
  const lat = Number(la);
  const lng = Number(lo);
  if (!la?.trim() || !lo?.trim() || !Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
    return Response.json({ error: "Valid latitude and longitude are required." }, { status: 400, headers });
  }
  if (!isInsideKarachi(lat, lng)) {
    return Response.json(formatMapAddress({}, lat, lng), { headers });
  }
  if (inFlight.size >= 8) {
    return Response.json({ error: "Address lookup is busy. Please try again shortly." }, {
      status: 429, headers: { ...headers, "Retry-After": "5" },
    });
  }
  try {
    const key = `${lat.toFixed(6)},${lng.toFixed(6)},${preferredArea ?? ""}`;
    return Response.json(await lookup(lat, lng, preferredArea, key), { headers });
  } catch {
    return Response.json({ error: "The pin is selected, but street details could not be read. Please enter your address or try again." }, {
      status: 503, headers,
    });
  }
}
