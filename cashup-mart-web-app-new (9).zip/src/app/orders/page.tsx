"use client";

import { Icon } from "@/components/Icon";
import { useStore } from "@/components/store";
import { PageHeader, useToast } from "@/components/ui";
import { STATUS_LABELS, type OrderStatus } from "@/lib/config";
import { formatPkr } from "@/lib/money";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function OrdersPage() {
  const router = useRouter();
  const toast = useToast();
  const { orders, profile, refreshOrders, online } = useStore();

  useEffect(() => {
    if (!profile?.phone) return;
    void refreshOrders(profile.phone);
  }, [profile?.phone, refreshOrders, online]);

  return (
    <div>
      <PageHeader title="Orders" back="" onClose={() => router.push("/")} />
      <div className="mx-auto max-w-2xl space-y-3 p-4">
        {!online && (
          <p className="zx-fade flex items-center gap-2 rounded-xl bg-zx-yellow/30 px-3 py-2 text-xs font-semibold">
            <Icon name="offline" size={16} /> Offline · showing orders saved on this device
          </p>
        )}
        {orders.length === 0 ? (
          <div className="zx-fade px-6 py-12 text-center">
            <Icon name="orders" size={40} className="mx-auto text-zx-muted" />
            <h2 className="font-heading mt-3 text-lg font-bold">No orders yet</h2>
            <p className="mt-1 text-sm text-zx-muted">Your rashan history will appear here.</p>
            <Link href="/" className="zx-btn mt-4 inline-flex">
              Shop now
            </Link>
          </div>
        ) : (
          <ul className="zx-stagger space-y-2">
            {orders.map((o, i) => (
              <li key={o.id} style={{ ["--i" as string]: i }}>
                <Link href={`/order?id=${o.id}`} className="zx-card zx-row-link block p-4">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-heading font-bold">{o.number}</p>
                    <span
                      className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-bold ${
                        o.pendingSync
                          ? "bg-zx-yellow text-white"
                          : o.status === "delivered"
                            ? "bg-zx-success/15 text-zx-success"
                            : o.status === "cancelled"
                              ? "bg-zx-error/15 text-zx-error"
                              : "bg-zx text-white"
                      }`}
                    >
                      {o.pendingSync ? "Waiting for internet" : STATUS_LABELS[o.status as OrderStatus] || o.status}
                    </span>
                  </div>
                  <p className="mt-1.5 text-sm text-zx-muted">
                    {o.items.length} items · <b className="text-zx-ink">{formatPkr(o.total)}</b> · Cash on Delivery
                  </p>
                  <p className="text-xs text-zx-muted">{new Date(o.createdAt).toLocaleString("en-PK")}</p>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
