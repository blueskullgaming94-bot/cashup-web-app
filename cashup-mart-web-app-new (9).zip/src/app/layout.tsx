import type { Metadata, Viewport } from "next";
import { Inter, Poppins } from "next/font/google";
import type { ReactNode } from "react";
import { Preloader } from "@/components/Preloader";
import { IntroLogo } from "@/components/IntroLogo";
import { DeliveryDialog } from "@/components/DeliveryDialog";
import { AppShell } from "@/components/shell";
import { StoreProvider } from "@/components/store";
import { ThemeProvider } from "@/components/Theme";
import { CodeNoticeProvider, ToastProvider } from "@/components/ui";
import "./globals.css";

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["500", "600", "700"],
  variable: "--font-heading",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-body",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "CashUp Express — Ghar ka Rashan, Dehleez Tak",
    template: "%s · CashUp Express",
  },
  description:
    "Groceries and daily essentials delivered across Karachi. Cash on Delivery only. Installable PWA that works offline.",
  applicationName: "CashUp Express",
  manifest: "/manifest.webmanifest",
  // Sidebar brand icon doubles as the browser favicon (same CashUp logo bytes).
  icons: {
    icon: [
      { url: "/favicon.ico", sizes: "16x16 32x32 48x48", type: "image/x-icon" },
      { url: "/favicon-32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon-16.png", sizes: "16x16", type: "image/png" },
      { url: "/cashup-logo.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
    shortcut: "/favicon.ico",
  },
  keywords: ["grocery", "Karachi", "delivery", "CashUp Express", "rashan", "mart", "cash on delivery"],
  appleWebApp: {
    capable: true,
    title: "CashUp Express",
    statusBarStyle: "black-translucent",
  },
  formatDetection: { telephone: false },
  openGraph: {
    title: "CashUp Express",
    description: "Ghar ka Rashan, Dehleez Tak — groceries delivered in Karachi.",
    type: "website",
    locale: "en_PK",
  },
};

export const viewport: Viewport = {
  themeColor: "#2A4B9B",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

const THEME_SCRIPT = `(function(){try{var t=localStorage.getItem("cashup-theme");if(t!=="light"&&t!=="dark"){t=matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}document.documentElement.dataset.theme=t}catch(e){}})();`;

/**
 * Runs before first paint so the launch intro is skipped instantly (no flash)
 * when it already played this session. The intro component reads this flag.
 */
const INTRO_SCRIPT = `(function(){try{if(sessionStorage.getItem("cashup-intro-shown-v4")){document.documentElement.dataset.intro="off"}}catch(e){}})();`;

/** Preloaded so the intro logo paints instantly, even on a cold visit. */
const INTRO_LOGO_SRC = "https://imglink.cc/cdn/iidohuM4Z3.png";

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning className={`${poppins.variable} ${inter.variable}`}>
      <head>
        <link rel="preload" as="image" href={INTRO_LOGO_SRC} fetchPriority="high" />
      </head>
      <body className="bg-zx-bg antialiased">
        <script dangerouslySetInnerHTML={{ __html: THEME_SCRIPT }} />
        <script dangerouslySetInnerHTML={{ __html: INTRO_SCRIPT }} />
        <IntroLogo />
        <ToastProvider>
          <ThemeProvider>
          <CodeNoticeProvider>
            <StoreProvider>
              <Preloader />
              <AppShell>{children}</AppShell>
              <DeliveryDialog />
            </StoreProvider>
          </CodeNoticeProvider>
          </ThemeProvider>
        </ToastProvider>
      </body>
    </html>
  );
}
