import { ProductBody } from "@/components/product-body";
import { products } from "@/data/catalog";
import type { Metadata } from "next";

export function generateStaticParams() {
  return products.map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const p = products.find((x) => x.slug === slug);
  return {
    title: p ? `${p.name} (${p.unit})` : "Product",
    description: p?.description ?? "Grocery item at CashUp Express, Karachi.",
  };
}

export default function ProductPage() {
  return <ProductBody />;
}
