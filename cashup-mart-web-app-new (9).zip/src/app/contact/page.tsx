import { HelpBody, InfoPage } from "@/components/InfoPage";

export const metadata = { title: "Contact" };

export default function ContactPage() {
  return (
    <InfoPage title="Contact us">
      <HelpBody />
    </InfoPage>
  );
}
