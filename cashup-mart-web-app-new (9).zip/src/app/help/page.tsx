import { HelpBody, InfoPage } from "@/components/InfoPage";

export const metadata = { title: "Help" };

export default function HelpPage() {
  return (
    <InfoPage title="Help & support">
      <HelpBody />
    </InfoPage>
  );
}
