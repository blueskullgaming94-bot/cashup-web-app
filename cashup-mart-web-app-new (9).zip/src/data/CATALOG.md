# CashUp Express catalog format

Products, categories, banners and promo codes are managed by the developer.
There is no admin panel. Edit `src/data/catalog.ts` (or import a JSON file with the same shape) and restart / redeploy.
On boot the app upserts this catalog into PostgreSQL so checkout always validates live prices and stock.

## Product fields

| Field | Type | Notes |
| --- | --- | --- |
| id | string | Stable primary key, e.g. `p001` |
| slug | string | URL slug, unique |
| name | string | Customer-facing name |
| category | string | Must match a category `slug` |
| subcategory | string | Shown as chips on the category page |
| brand | string | Used in search and filters |
| unit | string | e.g. `1 kg`, `12 pcs`, `1 L` |
| price | integer | PKR, rupees (not paisa) |
| salePrice | integer or null | If set and lower than price, shown as the deal price |
| image | string | Path under `/public`, e.g. `/images/products/apple.jpg` |
| description | string | Product detail copy |
| inStock | boolean | Out of stock items stay visible but greyed out |
| active | boolean | Hidden when false |
| tags | array | `popular`, `deal`, `new` — drive home rows |

## Category fields

`slug`, `name`, `icon` (sprite id), `subcategories[]`, `blurb`

## Banners

`id`, `title`, `subtitle`, `image`, `href`

## Promo codes

Edit `PROMO_CODES` in `src/lib/config.ts`. Types: `flat` or `percent`.

## Store rules

Edit `src/lib/config.ts` for minimum order, delivery fee, free-delivery threshold, COD cap, WhatsApp numbers.

## Bulk JSON import (optional)

Place a file `src/data/import.json`:

```json
{
  "products": [ { "id": "p201", "slug": "example", "name": "Example", "category": "staples", "subcategory": "Daal", "brand": "National", "unit": "1 kg", "price": 300, "salePrice": null, "image": "/images/products/rice.jpg", "description": "...", "inStock": true, "active": true, "tags": [] } ]
}
```

Merge into `catalog.ts` or load it from `ensureSeeded()` if you extend the seeder.

## Order alerts

Every order is stored in Postgres. The owner gets a WhatsApp deep-link message plus a private status URL `/ops/<token>` (also printed in server logs). Set `OWNER_WHATSAPP` and `OWNER_EMAIL` in `.env`.
