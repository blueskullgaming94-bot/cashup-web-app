/**
 * ImgLink CDN asset map.
 * - IMAGE_CDN: permanent hosted URLs (CDN + local-mirror fragment fallback).
 * - FALLBACK_CDN: empty — every product now has a distinct local image under
 *   public/images/..., so unmapped paths serve their same-origin file directly
 *   instead of a shared placeholder. Run scripts/upload-imglink-assets.mjs to
 *   host the remaining locals on ImgLink when quota allows.
 */

export const IMAGE_CDN: Record<string, string> = {
  "/images/banners/fresh-deals.jpg": "https://imglink.cc/cdn/9B7cwMhWJe.jpg",
  "/images/banners/free-delivery.jpg": "https://imglink.cc/cdn/cfBzwY5W_d.jpg",
  "/images/banners/weekly-essentials.jpg": "https://imglink.cc/cdn/QuKFPiE_UD.jpg",
  "/images/banners/household.jpg": "https://imglink.cc/cdn/7lx8HHYQiG.jpg",
  "/images/products/orange.jpg": "https://imglink.cc/cdn/LMhjyJxhSS.jpg",
  "/images/products/kela.jpg": "https://imglink.cc/cdn/S1NZBUXAKs.jpg",
  "/images/products/seb.jpg": "https://imglink.cc/cdn/xzYY1NKZVA.jpg",
  "/images/products/aam.jpg": "https://imglink.cc/cdn/r6sVM0tCV_.jpg",
  "/images/products/angoor.jpg": "https://imglink.cc/cdn/idiAPeW0uZ.jpg",
  "/images/products/tarbooz.jpg": "https://imglink.cc/cdn/fU-qV7Eljo.jpg",
  "/images/products/pomegranate.jpg": "https://imglink.cc/cdn/Qq2MmMdUBm.jpg",
  "/images/products/lemon-pack.jpg": "https://imglink.cc/cdn/_ucxtA3aYS.jpg",
  "/images/products/tamatar.jpg": "https://imglink.cc/cdn/0ko_79Advs.jpg",
  "/images/products/onion.jpg": "https://imglink.cc/cdn/ak0ah5KmRJ.jpg",
  "/images/products/aloo.jpg": "https://imglink.cc/cdn/fn5xr2Pn-W.jpg",
  "/images/products/gajar.jpg": "https://imglink.cc/cdn/SQ1ajqTshP.jpg",
  "/images/products/kheera.jpg": "https://imglink.cc/cdn/e6ZUD6yINJ.jpg",
  "/images/products/palak.jpg": "https://imglink.cc/cdn/c5u6O9at7G.jpg",
  "/images/products/adrak.jpg": "https://imglink.cc/cdn/X8zMbGVb32.jpg",
  "/images/products/lehsun.jpg": "https://imglink.cc/cdn/Vs4GU3V5Zk.jpg",
  "/images/products/olpers.jpg": "https://imglink.cc/cdn/DUfDhGWnRI.jpg",
  "/images/products/milk.jpg": "https://imglink.cc/cdn/DUfDhGWnRI.jpg",
  "/images/products/eggs.jpg": "https://imglink.cc/cdn/MhyIxkXqcF.jpg",
  "/images/products/eggs2.jpg": "https://imglink.cc/cdn/u7gF72fVi7.jpg",
  "/images/products/sweet-yogurt.jpg": "https://imglink.cc/cdn/dOCSBLpXh2.jpg",
  "/images/products/yogurt.jpg": "https://imglink.cc/cdn/dOCSBLpXh2.jpg",
  "/images/products/cheddar.jpg": "https://imglink.cc/cdn/0mUk5dlZ1K.jpg",
  "/images/products/cheese.jpg": "https://imglink.cc/cdn/0mUk5dlZ1K.jpg",
  "/images/products/chicken.jpg": "https://imglink.cc/cdn/VJKzvjeVx5.jpg",
  "/images/products/meat.jpg": "https://imglink.cc/cdn/VJKzvjeVx5.jpg",
  "/images/products/frozen-fish.jpg": "https://imglink.cc/cdn/_HXKSzbYZS.jpg",
  "/images/products/frozen-peas.jpg": "https://imglink.cc/cdn/Pd8PPTVG7h.jpg",
  "/images/products/frozen.jpg": "https://imglink.cc/cdn/aCzEH1tco9.jpg",
  "/images/products/nuggets.jpg": "https://imglink.cc/cdn/aCzEH1tco9.jpg",
  "/images/products/frozen2.jpg": "https://imglink.cc/cdn/Pd8PPTVG7h.jpg",
  "/images/products/atta.jpg": "https://imglink.cc/cdn/WvwZLmQpuE.jpg",
  "/images/products/basmati.jpg": "https://imglink.cc/cdn/PTWRH7WbVf.jpg",
  "/images/products/rice.jpg": "https://imglink.cc/cdn/PTWRH7WbVf.jpg",
  "/images/products/flour.jpg": "https://imglink.cc/cdn/WvwZLmQpuE.jpg",
  "/images/products/oil.jpg": "https://imglink.cc/cdn/Rt8lMEqOye.jpg",
  "/images/products/oil3.jpg": "https://imglink.cc/cdn/Rt8lMEqOye.jpg",
  "/images/products/masala.jpg": "https://imglink.cc/cdn/y4qG-JEEg4.jpg",
  "/images/products/spices.jpg": "https://imglink.cc/cdn/y4qG-JEEg4.jpg",
  "/images/products/white-sugar.jpg": "https://imglink.cc/cdn/TUfpYvTZOh.jpg",
  "/images/products/mineral-water.jpg": "https://imglink.cc/cdn/5NR-hM0rSa.jpg",
  "/images/products/water.jpg": "https://imglink.cc/cdn/5NR-hM0rSa.jpg",
  "/images/products/mango-juice.jpg": "https://imglink.cc/cdn/cp3XKmMFbb.jpg",
  "/images/products/juice.jpg": "https://imglink.cc/cdn/Hpjq5QIDwe.jpg",
  "/images/products/cold-drink.jpg": "https://imglink.cc/cdn/Inwwv7dY8m.jpg",
  "/images/products/cola.jpg": "https://imglink.cc/cdn/Inwwv7dY8m.jpg",
  "/images/products/energy-drink.jpg": "https://imglink.cc/cdn/Lz--K4ZkEV.jpg",
  "/images/products/tapal.jpg": "https://imglink.cc/cdn/QvLM0SDsRn.jpg",
  "/images/products/tea.jpg": "https://imglink.cc/cdn/nfGV9gbIXc.jpg",
  "/images/products/coffee-jar.jpg": "https://imglink.cc/cdn/QvLM0SDsRn.jpg",
  "/images/products/biscuits.jpg": "https://imglink.cc/cdn/4c0yOO-UiG.jpg",
  "/images/products/cookies.jpg": "https://imglink.cc/cdn/XMVaa_52G3.jpg",
  "/images/products/biscuits2.jpg": "https://imglink.cc/cdn/XMVaa_52G3.jpg",
  "/images/products/chips.jpg": "https://imglink.cc/cdn/BLPRR0Z26p.jpg",
  "/images/products/chips2.jpg": "https://imglink.cc/cdn/hpn5_MikCR.jpg",
  "/images/products/nimko.jpg": "https://imglink.cc/cdn/hpn5_MikCR.jpg",
  // Re-hosted distinct product photos (Oct 2026) — each has a matching local
  // mirror under public/images/products/ as an instant fallback.
  "/images/products/chocolate.jpg": "https://imglink.cc/cdn/MkwX6U3iP2.jpg",
  "/images/products/chocolate2.jpg": "https://imglink.cc/cdn/EDWlEIzDoV.jpg",
  "/images/products/bakery.jpg": "https://imglink.cc/cdn/lhcIdnQA8j.jpg",
  "/images/products/milk-bread.jpg": "https://imglink.cc/cdn/dOIVm7Hmd1.jpg",
  "/images/products/bread.jpg": "https://imglink.cc/cdn/j2mEp7esQ-.jpg",
  "/images/products/baguette.jpg": "https://imglink.cc/cdn/VYAEpPaO0p.jpg",
  "/images/products/rusk.jpg": "https://imglink.cc/cdn/T-JjArwRKk.jpg",
  "/images/products/cake.jpg": "https://imglink.cc/cdn/0M2Xvv_fJ6.jpg",
  "/images/products/laundry.jpg": "https://imglink.cc/cdn/WFq37nf4AN.jpg",
  "/images/products/detergent.jpg": "https://imglink.cc/cdn/SR_Leq_tQ6.jpg"
};

/**
 * No shared placeholders anymore. Remaining products (dishsoap → stationery)
 * serve their distinct same-origin files directly until their ImgLink uploads
 * complete; SmartImage still falls back to /images/placeholder.svg if needed.
 */
const FALLBACK_CDN: Record<string, string> = {};

const LOCAL_BY_CDN: Record<string, string> = {
  "https://imglink.cc/cdn/9B7cwMhWJe.jpg": "/images/banners/fresh-deals.jpg",
  "https://imglink.cc/cdn/cfBzwY5W_d.jpg": "/images/banners/free-delivery.jpg",
  "https://imglink.cc/cdn/QuKFPiE_UD.jpg": "/images/banners/weekly-essentials.jpg",
  "https://imglink.cc/cdn/7lx8HHYQiG.jpg": "/images/banners/household.jpg",
  "https://imglink.cc/cdn/LMhjyJxhSS.jpg": "/images/products/orange.jpg",
  "https://imglink.cc/cdn/S1NZBUXAKs.jpg": "/images/products/kela.jpg",
  "https://imglink.cc/cdn/xzYY1NKZVA.jpg": "/images/products/seb.jpg",
  "https://imglink.cc/cdn/r6sVM0tCV_.jpg": "/images/products/aam.jpg",
  "https://imglink.cc/cdn/idiAPeW0uZ.jpg": "/images/products/angoor.jpg",
  "https://imglink.cc/cdn/fU-qV7Eljo.jpg": "/images/products/tarbooz.jpg",
  "https://imglink.cc/cdn/Qq2MmMdUBm.jpg": "/images/products/pomegranate.jpg",
  "https://imglink.cc/cdn/_ucxtA3aYS.jpg": "/images/products/lemon-pack.jpg",
  "https://imglink.cc/cdn/0ko_79Advs.jpg": "/images/products/tamatar.jpg",
  "https://imglink.cc/cdn/ak0ah5KmRJ.jpg": "/images/products/onion.jpg",
  "https://imglink.cc/cdn/fn5xr2Pn-W.jpg": "/images/products/aloo.jpg",
  "https://imglink.cc/cdn/SQ1ajqTshP.jpg": "/images/products/gajar.jpg",
  "https://imglink.cc/cdn/e6ZUD6yINJ.jpg": "/images/products/kheera.jpg",
  "https://imglink.cc/cdn/c5u6O9at7G.jpg": "/images/products/palak.jpg",
  "https://imglink.cc/cdn/X8zMbGVb32.jpg": "/images/products/adrak.jpg",
  "https://imglink.cc/cdn/Vs4GU3V5Zk.jpg": "/images/products/lehsun.jpg",
  "https://imglink.cc/cdn/DUfDhGWnRI.jpg": "/images/products/milk.jpg",
  "https://imglink.cc/cdn/MhyIxkXqcF.jpg": "/images/products/eggs.jpg",
  "https://imglink.cc/cdn/u7gF72fVi7.jpg": "/images/products/eggs2.jpg",
  "https://imglink.cc/cdn/dOCSBLpXh2.jpg": "/images/products/yogurt.jpg",
  "https://imglink.cc/cdn/0mUk5dlZ1K.jpg": "/images/products/cheese.jpg",
  "https://imglink.cc/cdn/VJKzvjeVx5.jpg": "/images/products/meat.jpg",
  "https://imglink.cc/cdn/_HXKSzbYZS.jpg": "/images/products/frozen-fish.jpg",
  "https://imglink.cc/cdn/Pd8PPTVG7h.jpg": "/images/products/frozen2.jpg",
  "https://imglink.cc/cdn/aCzEH1tco9.jpg": "/images/products/nuggets.jpg",
  "https://imglink.cc/cdn/WvwZLmQpuE.jpg": "/images/products/flour.jpg",
  "https://imglink.cc/cdn/PTWRH7WbVf.jpg": "/images/products/rice.jpg",
  "https://imglink.cc/cdn/Rt8lMEqOye.jpg": "/images/products/oil3.jpg",
  "https://imglink.cc/cdn/y4qG-JEEg4.jpg": "/images/products/spices.jpg",
  "https://imglink.cc/cdn/TUfpYvTZOh.jpg": "/images/products/white-sugar.jpg",
  "https://imglink.cc/cdn/5NR-hM0rSa.jpg": "/images/products/water.jpg",
  "https://imglink.cc/cdn/cp3XKmMFbb.jpg": "/images/products/mango-juice.jpg",
  "https://imglink.cc/cdn/Hpjq5QIDwe.jpg": "/images/products/juice.jpg",
  "https://imglink.cc/cdn/Inwwv7dY8m.jpg": "/images/products/cola.jpg",
  "https://imglink.cc/cdn/Lz--K4ZkEV.jpg": "/images/products/energy-drink.jpg",
  "https://imglink.cc/cdn/QvLM0SDsRn.jpg": "/images/products/coffee-jar.jpg",
  "https://imglink.cc/cdn/nfGV9gbIXc.jpg": "/images/products/tea.jpg",
  "https://imglink.cc/cdn/4c0yOO-UiG.jpg": "/images/products/biscuits.jpg",
  "https://imglink.cc/cdn/XMVaa_52G3.jpg": "/images/products/biscuits2.jpg",
  "https://imglink.cc/cdn/BLPRR0Z26p.jpg": "/images/products/chips.jpg",
  "https://imglink.cc/cdn/hpn5_MikCR.jpg": "/images/products/nimko.jpg",
  "https://imglink.cc/cdn/MkwX6U3iP2.jpg": "/images/products/chocolate.jpg",
  "https://imglink.cc/cdn/EDWlEIzDoV.jpg": "/images/products/chocolate2.jpg",
  "https://imglink.cc/cdn/lhcIdnQA8j.jpg": "/images/products/bakery.jpg",
  "https://imglink.cc/cdn/dOIVm7Hmd1.jpg": "/images/products/milk-bread.jpg",
  "https://imglink.cc/cdn/j2mEp7esQ-.jpg": "/images/products/bread.jpg",
  "https://imglink.cc/cdn/VYAEpPaO0p.jpg": "/images/products/baguette.jpg",
  "https://imglink.cc/cdn/T-JjArwRKk.jpg": "/images/products/rusk.jpg",
  "https://imglink.cc/cdn/0M2Xvv_fJ6.jpg": "/images/products/cake.jpg",
  "https://imglink.cc/cdn/WFq37nf4AN.jpg": "/images/products/laundry.jpg",
  "https://imglink.cc/cdn/SR_Leq_tQ6.jpg": "/images/products/detergent.jpg"
};

/**
 * Returns the hosted ImgLink URL for a bundled image path.
 *
 * The original bundled path is appended as a URL fragment (`#/images/...`).
 * Browsers and CDNs never send fragments to the server, so the network request,
 * HTTP cache and service-worker cache key are identical to the plain CDN URL.
 * The fragment only gives the UI a same-origin fallback if the CDN fails.
 */
export function imageUrl(localPath: string) {
  const hosted = IMAGE_CDN[localPath] ?? FALLBACK_CDN[localPath];
  return hosted ? `${hosted}#${localPath}` : localPath;
}

/** Splits `https://…/x.jpg#/images/y.jpg` into the request URL and its fallback path. */
export function splitImageSource(src: string): { url: string; fallback: string | null } {
  const at = src.indexOf("#/");
  if (at === -1) return { url: src, fallback: null };
  return { url: src.slice(0, at), fallback: src.slice(at + 1) };
}

/** Original bundled public path for a hosted image (null when none is known). */
export function localImagePath(src: string): string | null {
  return splitImageSource(src).fallback;
}
