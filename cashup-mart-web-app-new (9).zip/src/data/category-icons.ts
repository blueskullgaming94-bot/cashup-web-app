/**
 * Category art source mapping.
 *
 * The user-supplied ImgLink images are copied locally as optimized WebP files,
 * so the exact selected artwork survives host/CDN outages and works offline.
 * `CATEGORY_ICON_SOURCE_URL` preserves the original image URL for reference.
 */
export const CATEGORY_ICON_SRC: Record<string, string> = {
  "fruits-vegetables": "/images/cats/fruits-vegetables.webp",
  "dairy-eggs": "/images/cats/dairy-eggs.webp",
  "meat-frozen": "/images/cats/meat-frozen.webp",
  staples: "/images/cats/staples.webp",
  beverages: "/images/cats/beverages.webp",
  snacks: "/images/cats/snacks.webp",
  bakery: "/images/cats/bakery.webp",
  household: "/images/cats/household.webp",
  "personal-care": "/images/cats/personal-care.webp",
  baby: "/images/cats/baby.webp",
  pet: "/images/cats/pet.webp",
  stationery: "/images/cats/stationery.webp",
};

export const CATEGORY_ICON_SOURCE_URL: Record<string, string> = {
  "fruits-vegetables": "https://imglink.cc/cdn/SEkFFvE3Y1.png",
  "dairy-eggs": "https://imglink.cc/cdn/yvFxBnlMB1.png",
  "meat-frozen": "https://imglink.cc/cdn/EZ2xuyG8X1.png",
  staples: "https://imglink.cc/cdn/B5Yv2d8S2q.png",
  beverages: "https://imglink.cc/cdn/e86Oka_MNk.png",
  snacks: "https://imglink.cc/cdn/1vJpDUs3yE.png",
  bakery: "https://imglink.cc/cdn/BI34L46uB3.png",
  household: "https://imglink.cc/cdn/KaYtCeKrC0.png",
  "personal-care": "https://imglink.cc/cdn/7fkGr4inmT.png",
  baby: "https://imglink.cc/cdn/JMTVBsU9-4.png",
  pet: "https://imglink.cc/cdn/7ZYfTcEIY5.png",
  stationery: "https://imglink.cc/cdn/QazIDNiu2b.png",
};
