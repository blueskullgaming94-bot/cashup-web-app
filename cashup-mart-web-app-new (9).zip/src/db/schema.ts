import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/pg-core";

export const categories = pgTable("categories", {
  slug: varchar("slug", { length: 80 }).primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  icon: varchar("icon", { length: 80 }).notNull(),
  subcategories: jsonb("subcategories").$type<string[]>().notNull(),
  blurb: text("blurb").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const products = pgTable("products", {
  id: varchar("id", { length: 40 }).primaryKey(),
  slug: varchar("slug", { length: 160 }).notNull(),
  name: varchar("name", { length: 200 }).notNull(),
  category: varchar("category", { length: 80 }).notNull(),
  subcategory: varchar("subcategory", { length: 80 }).notNull(),
  brand: varchar("brand", { length: 120 }).notNull(),
  unit: varchar("unit", { length: 60 }).notNull(),
  price: integer("price").notNull(),
  salePrice: integer("sale_price"),
  image: text("image").notNull(),
  description: text("description").notNull(),
  inStock: boolean("in_stock").notNull().default(true),
  active: boolean("active").notNull().default(true),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
});

export const banners = pgTable("banners", {
  id: varchar("id", { length: 40 }).primaryKey(),
  title: varchar("title", { length: 160 }).notNull(),
  subtitle: varchar("subtitle", { length: 200 }).notNull(),
  image: text("image").notNull(),
  href: varchar("href", { length: 200 }).notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
  active: boolean("active").notNull().default(true),
});

export const customers = pgTable(
  "customers",
  {
    id: serial("id").primaryKey(),
    phone: varchar("phone", { length: 20 }).notNull(),
    name: varchar("name", { length: 120 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("customers_phone_idx").on(t.phone)],
);

export const addresses = pgTable("addresses", {
  id: serial("id").primaryKey(),
  phone: varchar("phone", { length: 20 }).notNull(),
  label: varchar("label", { length: 80 }).notNull(),
  area: varchar("area", { length: 120 }).notNull(),
  houseNumber: varchar("house_number", { length: 100 }).notNull().default(""),
  blockSector: varchar("block_sector", { length: 100 }).notNull().default(""),
  street: varchar("street", { length: 180 }).notNull().default(""),
  details: text("details").notNull(),
  note: text("note").notNull().default(""),
  lat: real("lat").notNull(),
  lng: real("lng").notNull(),
  isDefault: boolean("is_default").notNull().default(false),
});

export const otpCodes = pgTable(
  "otp_codes",
  {
    id: serial("id").primaryKey(),
    phone: varchar("phone", { length: 20 }).notNull(),
    codeHash: varchar("code_hash", { length: 128 }).notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    attempts: integer("attempts").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("otp_codes_phone_idx").on(t.phone)],
);

export const orders = pgTable(
  "orders",
  {
    id: varchar("id", { length: 40 }).primaryKey(),
    number: varchar("number", { length: 32 }).notNull(),
    customerName: varchar("customer_name", { length: 120 }).notNull(),
    phone: varchar("phone", { length: 20 }).notNull(),
    address: jsonb("address").notNull(),
    items: jsonb("items").notNull(),
    subtotal: integer("subtotal").notNull(),
    deliveryFee: integer("delivery_fee").notNull(),
    discount: integer("discount").notNull().default(0),
    total: integer("total").notNull(),
    promoCode: varchar("promo_code", { length: 40 }),
    paymentMethod: varchar("payment_method", { length: 20 }).notNull().default("cod"),
    status: varchar("status", { length: 32 }).notNull().default("placed"),
    deliverySlot: varchar("delivery_slot", { length: 40 }).notNull(),
    note: text("note").notNull().default(""),
    opsToken: varchar("ops_token", { length: 64 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("orders_number_idx").on(t.number),
    uniqueIndex("orders_ops_token_idx").on(t.opsToken),
    index("orders_phone_idx").on(t.phone),
  ],
);

export const schema = {
  categories,
  products,
  banners,
  customers,
  addresses,
  otpCodes,
  orders,
};
