import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "./schema";

type DrizzleDb = ReturnType<typeof drizzle<typeof schema>>;

/**
 * Lazy database client.
 *
 * `DATABASE_URL` is OPTIONAL at build/import time: the client is created on
 * first use, so `next build` (including static exports on EdgeOne/Edgio Pages
 * or CI without a database) succeeds. When the URL is missing at runtime, the
 * first query throws a clear error — every API route already catches that and
 * falls back to the bundled catalog / local adapter.
 */
let _db: DrizzleDb | null = null;
let _pool: Pool | null = null;

function getDb(): DrizzleDb {
  if (_db) return _db;
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error(
      "DATABASE_URL is not configured. The app runs offline-first without it, but live orders/OTP need a database.",
    );
  }
  _pool = new Pool({ connectionString: databaseUrl });
  _db = drizzle(_pool, { schema });
  return _db;
}

export const db: DrizzleDb = new Proxy({} as DrizzleDb, {
  get(_target, prop) {
    const client = getDb();
    const value = Reflect.get(client, prop, client);
    return typeof value === "function" ? value.bind(client) : value;
  },
});

export const pool: Pool = new Proxy({} as Pool, {
  get(_target, prop) {
    const client = getDbPool();
    const value = Reflect.get(client, prop, client);
    // In particular, pool.end() must read/write the real pool's shutdown state.
    return typeof value === "function" ? value.bind(client) : value;
  },
});

function getDbPool(): Pool {
  getDb();
  if (!_pool) throw new Error("Pool not initialised");
  return _pool;
}
