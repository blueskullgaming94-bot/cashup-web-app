# Required address fields and OTP feedback

## Current delivery form

Three fields are compulsory for every newly saved delivery address and every order:

- **House Number** — e.g. L933 or Flat 4B
- **Block/Sector** — e.g. Sector 5A1 or Block 4
- **Area** — e.g. North Karachi

Street / landmark, address label and delivery note are separate optional fields. A selected Karachi map pin remains required. The customer must confirm the address: GPS and reverse-geocoding data are not proof of an exact door/flat match.

The map response populates each field independently. Missing map values stay empty, each field displays an autofill-failure message asking for manual entry, and saving/checkout stays blocked until all three fields are filled. The area is not auto-filled from an approximate nearest-area guess. A street or building name is never used as the required house number. A mapped street can fill the optional Street / landmark field.

User-entered values are preserved when a delayed map response arrives. The **Use mapped fields** button deliberately replaces fields for which the map has values, but never erases a manually supplied field just because the map omitted it. Pin movement clears only auto-generated values, not user edits. Offline/provider failures retain the pin and allow manual entry.

Recognizable house and block/sector values in older saved free-text addresses are prefilled conservatively. Missing components must be completed before ordering; no values are invented. Completed fields are stored separately in localStorage/IndexedDB, the device account and the order's address JSON. PostgreSQL's `addresses` table also has `house_number`, `block_sector` and `street` columns. Display summaries are derived from the structured fields. The order API validates the three fields before database writes, so free-text `details` alone cannot bypass the requirement.

## OTP notifications

- After a successful code request, a small **Code Sent!** acknowledgement appears at the centre of the viewport for about 2.4 seconds.
- The separate verification-code card slides in from the bottom-right on phones and desktops. It has **Copy** and **Dismiss**, respects safe areas, and remains for up to 45 seconds.
- On phones the card clears the bottom navigation; desktop uses a wider card with more explanation.
- Failed requests never show **Code Sent!**. In-app/offline fallback codes are not described as SMS delivery. If `OTP_REVEAL_CODE=false`, successful SMS requests show the confirmation without exposing the code in the app.
- Clipboard, keyboard focus and reduced-motion support are retained. The acknowledgment does not block interaction.

## Validation commands

- `node --import tsx --test tests/required-address.test.ts tests/delivery.test.ts tests/accounts.test.ts tests/otp-api.test.ts`
- With the production preview running: `node tests/address-notifications-browser.mjs`
- Existing browser regression suites: `node tests/delivery-browser.mjs` and `node tests/account-browser.mjs`

Browser tests mock GPS, map responses and SMS/code sends; they never send real customer messages.
