const { Router } = require('@edgio/core/router');

// Static-only edge routing for the dropped `out/` build.
module.exports = new Router()
  .match('/:path*', ({ serveStatic, cache }) => {
    cache({
      edge: { maxAgeSeconds: 60 * 60 * 24, staleWhileRevalidateSeconds: 60 * 60 },
      browser: { maxAgeSeconds: 60 * 60, serviceWorkerSeconds: 60 * 60 * 24 },
    });
    serveStatic('out');
  });
