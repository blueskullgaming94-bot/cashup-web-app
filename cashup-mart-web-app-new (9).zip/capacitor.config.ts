import type { CapacitorConfig } from "@capacitor/cli";

/**
 * Capacitor config — wraps the static web export (./out) into a native Android
 * app so it can be built into an installable APK.
 *
 * Flow (see ANDROID.md):
 *   1. node scripts/build-native.mjs      -> produces ./out (static index.html + assets)
 *   2. npx cap add android                -> creates ./android (one time)
 *   3. npx cap sync android               -> copies ./out into the Android project
 *   4. open ./android in Android Studio   -> Build > Build APK(s)
 *
 * The app is offline-first, so the APK works with no server. To talk to a live
 * ordering backend, set NEXT_PUBLIC_API_BASE before step 1.
 */
const config: CapacitorConfig = {
  appId: "pk.cashupexpress.app",
  appName: "CashUp Express",
  webDir: "out",
  backgroundColor: "#1A1F2C",
  android: {
    backgroundColor: "#1A1F2C",
    allowMixedContent: false,
  },
  server: {
    androidScheme: "https",
  },
};

export default config;
