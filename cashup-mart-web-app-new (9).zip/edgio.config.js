/**
 * Edgio configuration.
 *
 * Two supported paths:
 *  1) Static drop (recommended for Edgio Pages): `node scripts/edgio-static-build.mjs`
 *     then drag & drop the generated `out/` folder into Edgio Pages.
 *  2) Edgio Next connector (`@edgio/next`) for SSR — note the connector supports
 *     Next.js up to 14.x, this project is on Next 16, so use path 1.
 */
module.exports = {
  // Static drop needs no router; keep an empty config so `edgio build` does not fail.
  routes: './edgio.router.js',
};
