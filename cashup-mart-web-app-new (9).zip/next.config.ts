import type { NextConfig } from "next";
import { existsSync } from "node:fs";
import { join } from "node:path";

/**
 * Two build modes:
 *  - default: fullstack (API routes + PostgreSQL) for local/preview hosting.
 *  - NEXT_STATIC=1: pure static export into ./out for Edgio Pages drop
 *    (see scripts/edgio-static-build.mjs and EDGIO.md). The API folder is
 *    temporarily moved aside by that script; the app then runs entirely from
 *    the bundled catalog + IndexedDB.
 */
const staticRequested = process.env.NEXT_STATIC === "1";
const hasApiRoutes = existsSync(join(process.cwd(), "src", "app", "api"));
// A static export cannot contain route handlers. The supported static build
// scripts move src/app/api away first; if a host merely sets NEXT_STATIC=1
// while running `npm run build`, retain the full-stack build instead of failing
// during page-data collection with "force-dynamic cannot be used with output export".
const isStatic = staticRequested && !hasApiRoutes;
if (staticRequested && hasApiRoutes) {
  console.warn("[next.config] NEXT_STATIC=1 ignored because src/app/api still exists. Use scripts/build-native.mjs or scripts/edgio-static-build.mjs for static export.");
}

const nextConfig: NextConfig = isStatic
  ? {
      output: "export",
      trailingSlash: true,
      images: { unoptimized: true },
      reactStrictMode: true,
    }
  : {
      reactStrictMode: true,
      poweredByHeader: false,
      async headers() {
        return [
          {
            source: "/sw.js",
            headers: [
              { key: "Cache-Control", value: "no-cache, no-store, must-revalidate" },
              { key: "Service-Worker-Allowed", value: "/" },
            ],
          },
          {
            source: "/(.*)",
            headers: [{ key: "X-Content-Type-Options", value: "nosniff" }],
          },
        ];
      },
    };

export default nextConfig;
